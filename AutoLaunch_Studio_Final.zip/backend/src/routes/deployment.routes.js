const express = require('express');
const router = express.Router();
const deploymentController = require('../controllers/deployment.controller');
const authMiddleware = require('../middleware/auth.middleware');

// Apply auth middleware to all deployment routes
router.use(authMiddleware.verifyToken);

// Deployment routes
router.post('/cursor', deploymentController.deployCursor);
router.get('/status/:id', deploymentController.getDeploymentStatus);
router.post('/:id/rollback', deploymentController.rollbackDeployment);
router.get('/logs/:id', deploymentController.getDeploymentLogs);
router.get('/history/:appId', deploymentController.getDeploymentHistory);

module.exports = router;

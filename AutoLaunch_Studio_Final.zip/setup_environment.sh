#!/bin/bash
# AutoLaunch Studio Environment Configuration Script
# This script sets up the environment configuration for AutoLaunch Studio

set -e

# Color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Log functions
log_info() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

# Configuration
PROJECT_DIR="/home/ubuntu/autolaunch_studio"
CONFIG_DIR="${PROJECT_DIR}/config"
FRONTEND_DIR="${PROJECT_DIR}/frontend"
BACKEND_DIR="${PROJECT_DIR}/backend"
DEPLOYMENT_DIR="${PROJECT_DIR}/deployment"

# Display banner
echo "
 █████╗ ██╗   ██╗████████╗ ██████╗ ██╗      █████╗ ██╗   ██╗███╗   ██╗ ██████╗██╗  ██╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██║     ██╔══██╗██║   ██║████╗  ██║██╔════╝██║  ██║
███████║██║   ██║   ██║   ██║   ██║██║     ███████║██║   ██║██╔██╗ ██║██║     ███████║
██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██║██║   ██║██║╚██╗██║██║     ██╔══██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║  ██║╚██████╔╝██║ ╚████║╚██████╗██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝
                                                                                       
███████╗███╗   ██╗██╗   ██╗                                                            
██╔════╝████╗  ██║██║   ██║                                                            
█████╗  ██╔██╗ ██║██║   ██║                                                            
██╔══╝  ██║╚██╗██║╚██╗ ██╔╝                                                            
███████╗██║ ╚████║ ╚████╔╝                                                             
╚══════╝╚═╝  ╚═══╝  ╚═══╝                                                              
"
echo "Environment Configuration Script for AutoLaunch Studio"
echo "----------------------------------------------------"

# Check if config directory exists
if [ ! -d "${CONFIG_DIR}" ]; then
  log_error "Config directory not found: ${CONFIG_DIR}"
  exit 1
fi

# Check if .env.example exists
if [ ! -f "${CONFIG_DIR}/.env.example" ]; then
  log_error ".env.example file not found in ${CONFIG_DIR}"
  exit 1
fi

# Create .env files for different components
log_info "Creating environment configuration files..."

# Create .env file for backend
log_info "Creating backend .env file..."
cp "${CONFIG_DIR}/.env.example" "${BACKEND_DIR}/.env"
log_info "Backend .env file created at ${BACKEND_DIR}/.env"

# Create .env file for frontend
log_info "Creating frontend .env file..."
cat > "${FRONTEND_DIR}/.env" << EOL
# Frontend Environment Configuration
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_BLOOP_URL=http://localhost:7878
REACT_APP_POSTHOG_KEY=your_posthog_key
REACT_APP_POSTHOG_HOST=http://localhost:8000
REACT_APP_AGENT_ORCHESTRATION_ENABLED=true
REACT_APP_AGENT_SHARED_CONTEXT=true
REACT_APP_RAG_MEMORY_ENABLED=true
REACT_APP_ENABLE_ANALYTICS=true
REACT_APP_ENABLE_ROLE_MANAGEMENT=true
REACT_APP_ENABLE_MONETIZATION=true
REACT_APP_ENABLE_TEMPLATES=true
REACT_APP_ENABLE_AGENT_SYSTEM=true
EOL
log_info "Frontend .env file created at ${FRONTEND_DIR}/.env"

# Create .env file for Docker deployment
log_info "Creating Docker deployment .env file..."
cat > "${DEPLOYMENT_DIR}/docker/.env" << EOL
# Docker Environment Configuration
OLLAMA_PORT=11434
BLOOP_PORT=7878
FLOWISE_PORT=3003
N8N_PORT=5678
POSTGRES_PORT=5432
BACKEND_PORT=3001
FRONTEND_PORT=3000
UPTIME_KUMA_PORT=3002
POSTHOG_PORT=8000
EOL
log_info "Docker deployment .env file created at ${DEPLOYMENT_DIR}/docker/.env"

# Create environment configuration utility script
log_info "Creating environment configuration utility script..."

cat > "${CONFIG_DIR}/env_config.js" << 'EOL'
#!/usr/bin/env node

/**
 * AutoLaunch Studio Environment Configuration Utility
 * 
 * This script helps manage environment configuration for AutoLaunch Studio.
 */

const fs = require('fs');
const path = require('path');
const readline = require('readline');

// Configuration
const config = {
  projectRoot: '/home/ubuntu/autolaunch_studio',
  configDir: '/home/ubuntu/autolaunch_studio/config',
  frontendDir: '/home/ubuntu/autolaunch_studio/frontend',
  backendDir: '/home/ubuntu/autolaunch_studio/backend',
  deploymentDir: '/home/ubuntu/autolaunch_studio/deployment'
};

// Create readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

/**
 * Display ASCII art banner
 */
function displayBanner() {
  console.log(`
 █████╗ ██╗   ██╗████████╗ ██████╗ ██╗      █████╗ ██╗   ██╗███╗   ██╗ ██████╗██╗  ██╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██║     ██╔══██╗██║   ██║████╗  ██║██╔════╝██║  ██║
███████║██║   ██║   ██║   ██║   ██║██║     ███████║██║   ██║██╔██╗ ██║██║     ███████║
██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██║██║   ██║██║╚██╗██║██║     ██╔══██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║  ██║╚██████╔╝██║ ╚████║╚██████╗██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝
                                                                                       
███████╗███╗   ██╗██╗   ██╗                                                            
██╔════╝████╗  ██║██║   ██║                                                            
█████╗  ██╔██╗ ██║██║   ██║                                                            
██╔══╝  ██║╚██╗██║╚██╗ ██╔╝                                                            
███████╗██║ ╚████║ ╚████╔╝                                                             
╚══════╝╚═╝  ╚═══╝  ╚═══╝                                                              
  `);
  console.log('Environment Configuration Utility for AutoLaunch Studio');
  console.log('-----------------------------------------------------');
}

/**
 * Display main menu
 */
function displayMainMenu() {
  console.log('\nMain Menu:');
  console.log('1. View Current Environment Configuration');
  console.log('2. Update Environment Variables');
  console.log('3. Reset to Default Configuration');
  console.log('4. Generate New Configuration Files');
  console.log('5. Exit');
  
  rl.question('\nEnter your choice (1-5): ', (choice) => {
    switch (choice) {
      case '1':
        viewConfiguration();
        break;
      case '2':
        updateEnvironmentVariables();
        break;
      case '3':
        resetConfiguration();
        break;
      case '4':
        generateConfigurationFiles();
        break;
      case '5':
        console.log('Exiting...');
        rl.close();
        break;
      default:
        console.log('Invalid choice. Please try again.');
        displayMainMenu();
        break;
    }
  });
}

/**
 * View current environment configuration
 */
function viewConfiguration() {
  console.log('\nCurrent Environment Configuration:');
  
  rl.question('Which component? (backend/frontend/docker): ', (component) => {
    let envFile = '';
    
    switch (component) {
      case 'backend':
        envFile = path.join(config.backendDir, '.env');
        break;
      case 'frontend':
        envFile = path.join(config.frontendDir, '.env');
        break;
      case 'docker':
        envFile = path.join(config.deploymentDir, 'docker', '.env');
        break;
      default:
        console.log('Invalid component. Please try again.');
        viewConfiguration();
        return;
    }
    
    try {
      if (fs.existsSync(envFile)) {
        const envContent = fs.readFileSync(envFile, 'utf8');
        console.log(`\n${envFile} content:`);
        console.log('-------------------------------------------');
        console.log(envContent);
        console.log('-------------------------------------------');
      } else {
        console.log(`Environment file not found: ${envFile}`);
      }
    } catch (error) {
      console.error('Error reading environment file:', error.message);
    }
    
    rl.question('\nPress Enter to return to the main menu...', () => {
      displayMainMenu();
    });
  });
}

/**
 * Update environment variables
 */
function updateEnvironmentVariables() {
  console.log('\nUpdate Environment Variables:');
  
  rl.question('Which component? (backend/frontend/docker): ', (component) => {
    let envFile = '';
    
    switch (component) {
      case 'backend':
        envFile = path.join(config.backendDir, '.env');
        break;
      case 'frontend':
        envFile = path.join(config.frontendDir, '.env');
        break;
      case 'docker':
        envFile = path.join(config.deploymentDir, 'docker', '.env');
        break;
      default:
        console.log('Invalid component. Please try again.');
        updateEnvironmentVariables();
        return;
    }
    
    try {
      if (fs.existsSync(envFile)) {
        const envContent = fs.readFileSync(envFile, 'utf8');
        const envVars = envContent.split('\n').filter(line => line.trim() && !line.startsWith('#'));
        
        console.log(`\nCurrent environment variables for ${component}:`);
        envVars.forEach((line, index) => {
          console.log(`${index + 1}. ${line}`);
        });
        
        rl.question('\nEnter the number of the variable to update (or 0 to add new): ', (varIndex) => {
          const index = parseInt(varIndex);
          
          if (index === 0) {
            rl.question('Enter new variable (KEY=VALUE): ', (newVar) => {
              if (newVar.includes('=')) {
                const updatedContent = envContent + '\n' + newVar;
                fs.writeFileSync(envFile, updatedContent);
                console.log('New variable added successfully!');
              } else {
                console.log('Invalid format. Please use KEY=VALUE format.');
              }
              
              rl.question('\nPress Enter to return to the main menu...', () => {
                displayMainMenu();
              });
            });
          } else if (index > 0 && index <= envVars.length) {
            const selectedVar = envVars[index - 1];
            const varName = selectedVar.split('=')[0];
            
            rl.question(`Enter new value for ${varName}: `, (newValue) => {
              const updatedVar = `${varName}=${newValue}`;
              const updatedContent = envContent.replace(selectedVar, updatedVar);
              fs.writeFileSync(envFile, updatedContent);
              console.log('Variable updated successfully!');
              
              rl.question('\nPress Enter to return to the main menu...', () => {
                displayMainMenu();
              });
            });
          } else {
            console.log('Invalid number. Please try again.');
            updateEnvironmentVariables();
          }
        });
      } else {
        console.log(`Environment file not found: ${envFile}`);
        rl.question('\nPress Enter to return to the main menu...', () => {
          displayMainMenu();
        });
      }
    } catch (error) {
      console.error('Error updating environment variables:', error.message);
      rl.question('\nPress Enter to return to the main menu...', () => {
        displayMainMenu();
      });
    }
  });
}

/**
 * Reset configuration to default
 */
function resetConfiguration() {
  console.log('\nReset Configuration to Default:');
  
  rl.question('Are you sure you want to reset all configuration files to default? (y/n): ', (confirm) => {
    if (confirm.toLowerCase() === 'y') {
      try {
        // Copy example file to actual .env files
        const exampleFile = path.join(config.configDir, '.env.example');
        
        if (fs.existsSync(exampleFile)) {
          // Backend .env
          fs.copyFileSync(exampleFile, path.join(config.backendDir, '.env'));
          
          // Frontend .env
          const frontendEnv = fs.readFileSync(exampleFile, 'utf8')
            .split('\n')
            .filter(line => line.startsWith('REACT_APP_') || line.startsWith('# Frontend'))
            .join('\n');
          fs.writeFileSync(path.join(config.frontendDir, '.env'), frontendEnv);
          
          // Docker .env
          const dockerEnv = fs.readFileSync(exampleFile, 'utf8')
            .split('\n')
            .filter(line => line.includes('_PORT=') || line.startsWith('# Docker'))
            .join('\n');
          fs.writeFileSync(path.join(config.deploymentDir, 'docker', '.env'), dockerEnv);
          
          console.log('All configuration files have been reset to default!');
        } else {
          console.log(`Example environment file not found: ${exampleFile}`);
        }
      } catch (error) {
        console.error('Error resetting configuration:', error.message);
      }
    } else {
      console.log('Reset cancelled.');
    }
    
    rl.question('\nPress Enter to return to the main menu...', () => {
      displayMainMenu();
    });
  });
}

/**
 * Generate new configuration files
 */
function generateConfigurationFiles() {
  console.log('\nGenerate New Configuration Files:');
  
  try {
    // Create backend .env
    const backendEnv = `# Backend Environment Configuration
PORT=3001
NODE_ENV=production
DATABASE_URL=postgres://autolaunch_user:autolaunch_password@postgres:5432/autolaunch
JWT_SECRET=${generateRandomString(32)}
JWT_EXPIRATION=7d
CORS_ORIGIN=http://localhost:3000
OLLAMA_API_URL=http://ollama:11434
FLOWISE_API_URL=http://flowise:3000/api
N8N_API_URL=http://n8n:5678/api
AGENT_ORCHESTRATION_ENABLED=true
AGENT_SHARED_CONTEXT=true
RAG_MEMORY_ENABLED=true
`;
    fs.writeFileSync(path.join(config.backendDir, '.env'), backendEnv);
    
    // Create frontend .env
    const frontendEnv = `# Frontend Environment Configuration
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_BLOOP_URL=http://localhost:7878
REACT_APP_POSTHOG_KEY=${generateRandomString(16)}
REACT_APP_POSTHOG_HOST=http://localhost:8000
REACT_APP_AGENT_ORCHESTRATION_ENABLED=true
REACT_APP_AGENT_SHARED_CONTEXT=true
REACT_APP_RAG_MEMORY_ENABLED=true
REACT_APP_ENABLE_ANALYTICS=true
REACT_APP_ENABLE_ROLE_MANAGEMENT=true
REACT_APP_ENABLE_MONETIZATION=true
REACT_APP_ENABLE_TEMPLATES=true
REACT_APP_ENABLE_AGENT_SYSTEM=true
`;
    fs.writeFileSync(path.join(config.frontendDir, '.env'), frontendEnv);
    
    // Create Docker .env
    const dockerEnv = `# Docker Environment Configuration
OLLAMA_PORT=11434
BLOOP_PORT=7878
FLOWISE_PORT=3003
N8N_PORT=5678
POSTGRES_PORT=5432
BACKEND_PORT=3001
FRONTEND_PORT=3000
UPTIME_KUMA_PORT=3002
POSTHOG_PORT=8000
`;
    fs.writeFileSync(path.join(config.deploymentDir, 'docker', '.env'), dockerEnv);
    
    console.log('New configuration files generated successfully!');
  } catch (error) {
    console.error('Error generating configuration files:', error.message);
  }
  
  rl.question('\nPress Enter to return to the main menu...', () => {
    displayMainMenu();
  });
}

/**
 * Generate random string
 */
function generateRandomString(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

/**
 * Main function
 */
function main() {
  displayBanner();
  displayMainMenu();
}

// Start the application
main();
EOL

chmod +x "${CONFIG_DIR}/env_config.js"
log_info "Environment configuration utility script created at ${CONFIG_DIR}/env_config.js"

# Create environment validation script
log_info "Creating environment validation script..."

cat > "${CONFIG_DIR}/validate_env.js" << 'EOL'
#!/usr/bin/env node

/**
 * AutoLaunch Studio Environment Validation Script
 * 
 * This script validates the environment configuration for AutoLaunch Studio.
 */

const fs = require('fs');
const path = require('path');

// Configuration
const config = {
  projectRoot: '/home/ubuntu/autolaunch_studio',
  configDir: '/home/ubuntu/autolaunch_studio/config',
  frontendDir: '/home/ubuntu/autolaunch_studio/frontend',
  backendDir: '/home/ubuntu/autolaunch_studio/backend
(Content truncated due to size limit. Use line ranges to read in chunks)
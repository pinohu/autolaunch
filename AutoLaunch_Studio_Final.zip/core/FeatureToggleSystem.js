// Feature Toggle System for AutoLaunch Studio
// This file provides the core functionality for the feature toggle system

const fs = require('fs');
const path = require('path');

class FeatureToggleSystem {
  constructor(configPath) {
    this.configPath = configPath;
    this.features = {};
    this.loadFeatures();
  }

  // Load features from configuration file
  loadFeatures() {
    try {
      if (fs.existsSync(this.configPath)) {
        const rawData = fs.readFileSync(this.configPath, 'utf8');
        this.features = JSON.parse(rawData);
        console.log('Feature toggles loaded successfully');
      } else {
        console.warn('Feature toggle configuration file not found, using defaults');
        this.initializeDefaultFeatures();
        this.saveFeatures();
      }
    } catch (error) {
      console.error('Error loading feature toggles:', error);
      this.initializeDefaultFeatures();
    }
  }

  // Initialize default features
  initializeDefaultFeatures() {
    this.features = {
      analytics: {
        enabled: true,
        description: 'Enable analytics dashboard and tracking',
        category: 'core',
        dependencies: []
      },
      roleManagement: {
        enabled: true,
        description: 'Enable role-based access control',
        category: 'security',
        dependencies: []
      },
      monetization: {
        enabled: true,
        description: 'Enable monetization features',
        category: 'business',
        dependencies: []
      },
      templates: {
        enabled: true,
        description: 'Enable template system for code reuse',
        category: 'development',
        dependencies: []
      },
      agentSystem: {
        enabled: true,
        description: 'Enable multi-agent architecture',
        category: 'ai',
        dependencies: []
      },
      improvementLoop: {
        enabled: true,
        description: 'Enable automated improvement suggestions',
        category: 'ai',
        dependencies: ['agentSystem']
      },
      codeSearch: {
        enabled: true,
        description: 'Enable code search with Bloop',
        category: 'development',
        dependencies: []
      },
      workflowAutomation: {
        enabled: true,
        description: 'Enable workflow automation with n8n',
        category: 'automation',
        dependencies: []
      },
      visualFlows: {
        enabled: true,
        description: 'Enable visual flows with Flowise',
        category: 'automation',
        dependencies: []
      }
    };
  }

  // Save features to configuration file
  saveFeatures() {
    try {
      const dirPath = path.dirname(this.configPath);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
      fs.writeFileSync(this.configPath, JSON.stringify(this.features, null, 2));
      console.log('Feature toggles saved successfully');
    } catch (error) {
      console.error('Error saving feature toggles:', error);
    }
  }

  // Check if a feature is enabled
  isEnabled(featureName) {
    if (!this.features[featureName]) {
      console.warn(`Feature "${featureName}" not found`);
      return false;
    }
    
    // Check dependencies
    if (this.features[featureName].dependencies) {
      for (const dependency of this.features[featureName].dependencies) {
        if (!this.isEnabled(dependency)) {
          console.warn(`Feature "${featureName}" depends on "${dependency}" which is disabled`);
          return false;
        }
      }
    }
    
    return this.features[featureName].enabled;
  }

  // Enable a feature
  enableFeature(featureName) {
    if (!this.features[featureName]) {
      console.warn(`Feature "${featureName}" not found`);
      return false;
    }
    
    this.features[featureName].enabled = true;
    this.saveFeatures();
    return true;
  }

  // Disable a feature
  disableFeature(featureName) {
    if (!this.features[featureName]) {
      console.warn(`Feature "${featureName}" not found`);
      return false;
    }
    
    // Check if other features depend on this one
    const dependents = this.findDependents(featureName);
    if (dependents.length > 0) {
      console.warn(`Cannot disable "${featureName}" because these features depend on it: ${dependents.join(', ')}`);
      return false;
    }
    
    this.features[featureName].enabled = false;
    this.saveFeatures();
    return true;
  }

  // Find features that depend on a given feature
  findDependents(featureName) {
    const dependents = [];
    for (const [name, feature] of Object.entries(this.features)) {
      if (feature.dependencies && feature.dependencies.includes(featureName) && feature.enabled) {
        dependents.push(name);
      }
    }
    return dependents;
  }

  // Get all features
  getAllFeatures() {
    return this.features;
  }

  // Get features by category
  getFeaturesByCategory(category) {
    const result = {};
    for (const [name, feature] of Object.entries(this.features)) {
      if (feature.category === category) {
        result[name] = feature;
      }
    }
    return result;
  }

  // Add a new feature
  addFeature(name, description, category, dependencies = [], enabled = true) {
    if (this.features[name]) {
      console.warn(`Feature "${name}" already exists`);
      return false;
    }
    
    this.features[name] = {
      enabled,
      description,
      category,
      dependencies
    };
    
    this.saveFeatures();
    return true;
  }

  // Update a feature
  updateFeature(name, updates) {
    if (!this.features[name]) {
      console.warn(`Feature "${name}" not found`);
      return false;
    }
    
    this.features[name] = { ...this.features[name], ...updates };
    this.saveFeatures();
    return true;
  }

  // Delete a feature
  deleteFeature(name) {
    if (!this.features[name]) {
      console.warn(`Feature "${name}" not found`);
      return false;
    }
    
    // Check if other features depend on this one
    const dependents = this.findDependents(name);
    if (dependents.length > 0) {
      console.warn(`Cannot delete "${name}" because these features depend on it: ${dependents.join(', ')}`);
      return false;
    }
    
    delete this.features[name];
    this.saveFeatures();
    return true;
  }

  // Import features from CSV
  importFromCSV(csvPath) {
    try {
      const csv = fs.readFileSync(csvPath, 'utf8');
      const lines = csv.split('\n');
      
      // Skip header row
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        const columns = line.split(',');
        if (columns.length < 4) continue;
        
        const name = columns[0].trim();
        const enabled = columns[1].trim().toLowerCase() === 'true';
        const description = columns[2].trim();
        const category = columns[3].trim();
        const dependencies = columns.length > 4 ? columns[4].split(';').map(d => d.trim()) : [];
        
        if (name) {
          if (this.features[name]) {
            this.updateFeature(name, { enabled, description, category, dependencies });
          } else {
            this.addFeature(name, description, category, dependencies, enabled);
          }
        }
      }
      
      console.log('Features imported successfully from CSV');
      return true;
    } catch (error) {
      console.error('Error importing features from CSV:', error);
      return false;
    }
  }

  // Export features to CSV
  exportToCSV(csvPath) {
    try {
      let csv = 'name,enabled,description,category,dependencies\n';
      
      for (const [name, feature] of Object.entries(this.features)) {
        const dependencies = feature.dependencies ? feature.dependencies.join(';') : '';
        csv += `${name},${feature.enabled},${feature.description},${feature.category},${dependencies}\n`;
      }
      
      fs.writeFileSync(csvPath, csv);
      console.log('Features exported successfully to CSV');
      return true;
    } catch (error) {
      console.error('Error exporting features to CSV:', error);
      return false;
    }
  }
}

module.exports = FeatureToggleSystem;

// Architect Agent for AutoLaunch Studio
// This agent plans the overall structure of the application

const BaseAgent = require('../BaseAgent');

class ArchitectAgent extends BaseAgent {
  constructor(spec, orchestrator) {
    super(spec.id, spec, orchestrator);
  }

  // Process inputs specific to the Architect Agent
  processInputs(inputs) {
    // Extract relevant information from user prompt and requirements
    const processedInputs = { ...inputs };
    
    // Add any architect-specific processing here
    if (processedInputs.user_prompt) {
      processedInputs.parsed_requirements = this.parseRequirementsFromPrompt(processedInputs.user_prompt);
    }
    
    return processedInputs;
  }

  // Parse requirements from user prompt
  parseRequirementsFromPrompt(prompt) {
    // This would be implemented with more sophisticated parsing
    // For now, we'll do a simple extraction of key elements
    const requirements = {
      appType: this.extractAppType(prompt),
      features: this.extractFeatures(prompt),
      dataModels: this.extractDataModels(prompt),
      technicalStack: this.extractTechnicalStack(prompt)
    };
    
    return requirements;
  }

  // Extract app type from prompt
  extractAppType(prompt) {
    const appTypes = ['web app', 'mobile app', 'desktop app', 'api', 'dashboard'];
    for (const type of appTypes) {
      if (prompt.toLowerCase().includes(type)) {
        return type;
      }
    }
    return 'web app'; // Default to web app
  }

  // Extract features from prompt
  extractFeatures(prompt) {
    const features = [];
    const featureIndicators = [
      'feature', 'functionality', 'should have', 
      'must have', 'needs to', 'capability'
    ];
    
    // Simple extraction based on indicators
    // In a real implementation, this would use more sophisticated NLP
    const sentences = prompt.split(/[.!?]+/);
    for (const sentence of sentences) {
      for (const indicator of featureIndicators) {
        if (sentence.toLowerCase().includes(indicator)) {
          features.push(sentence.trim());
          break;
        }
      }
    }
    
    return features;
  }

  // Extract data models from prompt
  extractDataModels(prompt) {
    const dataModels = [];
    const dataModelIndicators = [
      'data model', 'entity', 'table', 'schema', 
      'object', 'store', 'record'
    ];
    
    // Simple extraction based on indicators
    const sentences = prompt.split(/[.!?]+/);
    for (const sentence of sentences) {
      for (const indicator of dataModelIndicators) {
        if (sentence.toLowerCase().includes(indicator)) {
          dataModels.push(sentence.trim());
          break;
        }
      }
    }
    
    return dataModels;
  }

  // Extract technical stack from prompt
  extractTechnicalStack(prompt) {
    const techStack = {
      frontend: this.extractFrontendTech(prompt),
      backend: this.extractBackendTech(prompt),
      database: this.extractDatabaseTech(prompt)
    };
    
    return techStack;
  }

  // Extract frontend technology from prompt
  extractFrontendTech(prompt) {
    const frontendTechs = {
      'react': 'React',
      'next.js': 'Next.js',
      'vue': 'Vue.js',
      'angular': 'Angular',
      'svelte': 'Svelte'
    };
    
    for (const [key, value] of Object.entries(frontendTechs)) {
      if (prompt.toLowerCase().includes(key)) {
        return value;
      }
    }
    
    return 'React'; // Default to React
  }

  // Extract backend technology from prompt
  extractBackendTech(prompt) {
    const backendTechs = {
      'node': 'Node.js',
      'express': 'Express.js',
      'python': 'Python',
      'django': 'Django',
      'flask': 'Flask',
      'java': 'Java',
      'spring': 'Spring Boot',
      'go': 'Go',
      'php': 'PHP',
      'laravel': 'Laravel'
    };
    
    for (const [key, value] of Object.entries(backendTechs)) {
      if (prompt.toLowerCase().includes(key)) {
        return value;
      }
    }
    
    return 'Node.js'; // Default to Node.js
  }

  // Extract database technology from prompt
  extractDatabaseTech(prompt) {
    const databaseTechs = {
      'postgres': 'PostgreSQL',
      'mysql': 'MySQL',
      'mongodb': 'MongoDB',
      'sqlite': 'SQLite',
      'sql server': 'SQL Server',
      'oracle': 'Oracle',
      'dynamodb': 'DynamoDB',
      'firestore': 'Firestore'
    };
    
    for (const [key, value] of Object.entries(databaseTechs)) {
      if (prompt.toLowerCase().includes(key)) {
        return value;
      }
    }
    
    return 'PostgreSQL'; // Default to PostgreSQL
  }

  // Internal execution method for the Architect Agent
  async executeInternal(inputs) {
    console.log(`ArchitectAgent executing with inputs:`, Object.keys(inputs));
    
    // In a real implementation, this would call an LLM or other AI service
    // For now, we'll simulate the architecture planning process
    
    // Generate architecture plan
    const architecturePlan = this.generateArchitecturePlan(inputs);
    
    // Generate component list
    const componentList = this.generateComponentList(inputs, architecturePlan);
    
    // Generate data models
    const dataModels = this.generateDataModels(inputs, architecturePlan);
    
    // Return outputs
    return {
      architecture_plan: architecturePlan,
      component_list: componentList,
      data_models: dataModels
    };
  }

  // Generate architecture plan
  generateArchitecturePlan(inputs) {
    const { parsed_requirements } = inputs;
    
    // In a real implementation, this would be generated by an LLM
    // For now, we'll create a simple architecture plan
    const architecturePlan = {
      appType: parsed_requirements?.appType || 'web app',
      architecture: 'client-server',
      frontendFramework: parsed_requirements?.technicalStack?.frontend || 'React',
      backendFramework: parsed_requirements?.technicalStack?.backend || 'Node.js',
      database: parsed_requirements?.technicalStack?.database || 'PostgreSQL',
      authentication: 'JWT',
      deployment: 'Docker',
      apiStyle: 'REST',
      layers: [
        {
          name: 'Presentation Layer',
          components: ['UI Components', 'State Management', 'API Client']
        },
        {
          name: 'Business Logic Layer',
          components: ['API Routes', 'Controllers', 'Services']
        },
        {
          name: 'Data Access Layer',
          components: ['Models', 'Repositories', 'Database']
        }
      ]
    };
    
    return architecturePlan;
  }

  // Generate component list
  generateComponentList(inputs, architecturePlan) {
    // In a real implementation, this would be generated by an LLM
    // For now, we'll create a simple component list
    const componentList = {
      frontend: [
        {
          name: 'App',
          type: 'Container',
          children: ['Header', 'Main', 'Footer']
        },
        {
          name: 'Header',
          type: 'Component',
          props: ['title', 'user']
        },
        {
          name: 'Main',
          type: 'Container',
          children: ['Dashboard', 'UserProfile', 'Settings']
        },
        {
          name: 'Footer',
          type: 'Component',
          props: ['links', 'copyright']
        },
        {
          name: 'Dashboard',
          type: 'Page',
          children: ['DataTable', 'Chart', 'StatusCard']
        },
        {
          name: 'UserProfile',
          type: 'Page',
          children: ['ProfileForm', 'Avatar']
        },
        {
          name: 'Settings',
          type: 'Page',
          children: ['SettingsForm']
        }
      ],
      backend: [
        {
          name: 'Server',
          type: 'Container',
          children: ['Routes', 'Controllers', 'Services', 'Models']
        },
        {
          name: 'Routes',
          type: 'Module',
          endpoints: ['/api/users', '/api/auth', '/api/data']
        },
        {
          name: 'Controllers',
          type: 'Module',
          handlers: ['UserController', 'AuthController', 'DataController']
        },
        {
          name: 'Services',
          type: 'Module',
          services: ['UserService', 'AuthService', 'DataService']
        },
        {
          name: 'Models',
          type: 'Module',
          models: ['User', 'Data']
        }
      ]
    };
    
    return componentList;
  }

  // Generate data models
  generateDataModels(inputs, architecturePlan) {
    // In a real implementation, this would be generated by an LLM
    // For now, we'll create simple data models
    const dataModels = [
      {
        name: 'User',
        fields: [
          { name: 'id', type: 'UUID', primaryKey: true },
          { name: 'username', type: 'String', required: true },
          { name: 'email', type: 'String', required: true },
          { name: 'password', type: 'String', required: true },
          { name: 'createdAt', type: 'DateTime', required: true },
          { name: 'updatedAt', type: 'DateTime', required: true }
        ],
        relationships: [
          { name: 'data', type: 'hasMany', target: 'Data' }
        ]
      },
      {
        name: 'Data',
        fields: [
          { name: 'id', type: 'UUID', primaryKey: true },
          { name: 'userId', type: 'UUID', required: true, foreignKey: true },
          { name: 'title', type: 'String', required: true },
          { name: 'content', type: 'Text', required: true },
          { name: 'createdAt', type: 'DateTime', required: true },
          { name: 'updatedAt', type: 'DateTime', required: true }
        ],
        relationships: [
          { name: 'user', type: 'belongsTo', target: 'User' }
        ]
      }
    ];
    
    return dataModels;
  }
}

module.exports = ArchitectAgent;

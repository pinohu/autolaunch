// Prompt Template System for AutoLaunch Studio
// This file provides the core functionality for the prompt template system

const fs = require('fs');
const path = require('path');
const marked = require('marked');

class PromptTemplateSystem {
  constructor(templatesDir) {
    this.templatesDir = templatesDir;
    this.templates = {};
    this.loadTemplates();
  }

  // Load all templates from the templates directory
  loadTemplates() {
    try {
      if (!fs.existsSync(this.templatesDir)) {
        fs.mkdirSync(this.templatesDir, { recursive: true });
        console.log(`Created templates directory: ${this.templatesDir}`);
      }

      const files = fs.readdirSync(this.templatesDir);
      const templateFiles = files.filter(file => file.endsWith('.md'));
      
      templateFiles.forEach(file => {
        const templateName = path.basename(file, '.md');
        const templatePath = path.join(this.templatesDir, file);
        const templateContent = fs.readFileSync(templatePath, 'utf8');
        
        this.templates[templateName] = {
          name: templateName,
          path: templatePath,
          content: templateContent,
          parsed: this.parseTemplate(templateContent)
        };
      });
      
      console.log(`Loaded ${Object.keys(this.templates).length} templates`);
    } catch (error) {
      console.error('Error loading templates:', error);
    }
  }

  // Parse a template to extract sections and fields
  parseTemplate(content) {
    const sections = {};
    let currentSection = null;
    
    // Split content into lines
    const lines = content.split('\n');
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // Check for section headers (## Section)
      if (line.startsWith('## ')) {
        currentSection = line.substring(3).trim();
        sections[currentSection] = { content: '', fields: [] };
        continue;
      }
      
      // Check for subsection headers (### Subsection)
      if (line.startsWith('### ')) {
        const subsection = line.substring(4).trim();
        if (currentSection) {
          sections[currentSection].content += `### ${subsection}\n`;
        }
        continue;
      }
      
      // Check for fields with placeholders [Field]
      if (line.includes('[') && line.includes(']') && currentSection) {
        const regex = /\[(.*?)\]/g;
        let match;
        
        while ((match = regex.exec(line)) !== null) {
          const field = match[1];
          if (!sections[currentSection].fields.includes(field)) {
            sections[currentSection].fields.push(field);
          }
        }
      }
      
      // Add line to current section content
      if (currentSection) {
        sections[currentSection].content += line + '\n';
      }
    }
    
    return sections;
  }

  // Get all available templates
  getAllTemplates() {
    return Object.keys(this.templates).map(name => ({
      name,
      path: this.templates[name].path
    }));
  }

  // Get a specific template by name
  getTemplate(name) {
    return this.templates[name];
  }

  // Create a new template
  createTemplate(name, content) {
    if (this.templates[name]) {
      console.warn(`Template "${name}" already exists`);
      return false;
    }
    
    try {
      const templatePath = path.join(this.templatesDir, `${name}.md`);
      fs.writeFileSync(templatePath, content);
      
      this.templates[name] = {
        name,
        path: templatePath,
        content,
        parsed: this.parseTemplate(content)
      };
      
      console.log(`Created template: ${name}`);
      return true;
    } catch (error) {
      console.error(`Error creating template "${name}":`, error);
      return false;
    }
  }

  // Update an existing template
  updateTemplate(name, content) {
    if (!this.templates[name]) {
      console.warn(`Template "${name}" not found`);
      return false;
    }
    
    try {
      const templatePath = path.join(this.templatesDir, `${name}.md`);
      fs.writeFileSync(templatePath, content);
      
      this.templates[name] = {
        name,
        path: templatePath,
        content,
        parsed: this.parseTemplate(content)
      };
      
      console.log(`Updated template: ${name}`);
      return true;
    } catch (error) {
      console.error(`Error updating template "${name}":`, error);
      return false;
    }
  }

  // Delete a template
  deleteTemplate(name) {
    if (!this.templates[name]) {
      console.warn(`Template "${name}" not found`);
      return false;
    }
    
    try {
      const templatePath = path.join(this.templatesDir, `${name}.md`);
      fs.unlinkSync(templatePath);
      
      delete this.templates[name];
      
      console.log(`Deleted template: ${name}`);
      return true;
    } catch (error) {
      console.error(`Error deleting template "${name}":`, error);
      return false;
    }
  }

  // Fill a template with values
  fillTemplate(templateName, values) {
    if (!this.templates[templateName]) {
      console.warn(`Template "${templateName}" not found`);
      return null;
    }
    
    let filledContent = this.templates[templateName].content;
    
    // Replace all placeholders with values
    Object.entries(values).forEach(([key, value]) => {
      const placeholder = `[${key}]`;
      filledContent = filledContent.replace(new RegExp(placeholder, 'g'), value);
    });
    
    return filledContent;
  }

  // Convert a filled template to HTML
  templateToHtml(filledContent) {
    return marked.parse(filledContent);
  }

  // Extract fields from a template
  getTemplateFields(templateName) {
    if (!this.templates[templateName]) {
      console.warn(`Template "${templateName}" not found`);
      return [];
    }
    
    const fields = [];
    const sections = this.templates[templateName].parsed;
    
    Object.values(sections).forEach(section => {
      fields.push(...section.fields);
    });
    
    return [...new Set(fields)]; // Remove duplicates
  }

  // Get template sections
  getTemplateSections(templateName) {
    if (!this.templates[templateName]) {
      console.warn(`Template "${templateName}" not found`);
      return {};
    }
    
    return this.templates[templateName].parsed;
  }

  // Import a template from a file
  importTemplate(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const name = path.basename(filePath, '.md');
      
      return this.createTemplate(name, content);
    } catch (error) {
      console.error(`Error importing template from "${filePath}":`, error);
      return false;
    }
  }

  // Export a template to a file
  exportTemplate(templateName, outputPath) {
    if (!this.templates[templateName]) {
      console.warn(`Template "${templateName}" not found`);
      return false;
    }
    
    try {
      fs.writeFileSync(outputPath, this.templates[templateName].content);
      console.log(`Exported template "${templateName}" to ${outputPath}`);
      return true;
    } catch (error) {
      console.error(`Error exporting template "${templateName}":`, error);
      return false;
    }
  }
}

module.exports = PromptTemplateSystem;

import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Stepper,
  Step,
  StepLabel,
  Paper,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Switch,
  Grid,
  CircularProgress,
  Alert,
  Divider,
  InputAdornment,
  IconButton,
  Tabs,
  Tab
} from '@mui/material';
import {
  Visibility,
  VisibilityOff,
  CheckCircle,
  Settings,
  Storage,
  Security,
  Code,
  CloudDone,
  Extension,
  PhoneAndroid,
  Web,
  WordPress
} from '@mui/icons-material';
import { toast } from 'react-toastify';

// Configuration wizard steps
const steps = [
  'Welcome',
  'Admin Account',
  'System Settings',
  'Database Setup',
  'Platform Support',
  'Deployment Settings',
  'Integrations',
  'Confirmation'
];

function ConfigWizard() {
  const [activeStep, setActiveStep] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [platformTabValue, setPlatformTabValue] = useState(0);
  const [formData, setFormData] = useState({
    // Admin account
    adminName: '',
    adminEmail: '',
    adminPassword: '',
    adminPasswordConfirm: '',
    
    // System settings
    siteName: 'AutoLaunch Studio',
    siteUrl: 'https://apps.autolaunchstudio.com',
    frontendPort: 3000,
    backendPort: 3001,
    
    // Database settings
    databaseType: 'mongodb',
    databaseHost: 'localhost',
    databasePort: 27017,
    databaseName: 'autolaunch',
    databaseUser: '',
    databasePassword: '',
    
    // Platform support
    wordpressSupport: true,
    wordpressPort: 8080,
    wordpressAdminUser: 'admin',
    wordpressAdminPassword: '',
    
    browserExtensionSupport: true,
    browserExtensionTypes: ['chrome', 'firefox'],
    
    mobileAppSupport: true,
    mobileAppPlatforms: ['android', 'ios'],
    mobileAppBuildTools: true,
    
    // Deployment settings
    defaultEnvironment: 'staging',
    deploymentMethod: 'docker',
    autoDeployEnabled: true,
    requireApproval: true,
    notifyOnDeployment: true,
    
    // Integrations
    cursorAiEnabled: true,
    githubEnabled: false,
    githubToken: '',
    analyticsEnabled: true
  });
  
  const [errors, setErrors] = useState({});
  const [setupComplete, setSetupComplete] = useState(false);
  
  // Handle platform tab change
  const handlePlatformTabChange = (event, newValue) => {
    setPlatformTabValue(newValue);
  };
  
  // Check if setup has already been completed
  useEffect(() => {
    const checkSetupStatus = async () => {
      try {
        setIsLoading(true);
        
        // Simulate API call to check setup status
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // For demo purposes, assume setup is not completed
        setSetupComplete(false);
      } catch (error) {
        console.error('Error checking setup status:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    checkSetupStatus();
  }, []);
  
  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    
    // Clear error for this field if it exists
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };
  
  // Handle array input changes (for multi-select)
  const handleArrayInputChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error for this field if it exists
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };
  
  // Toggle password visibility
  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  
  // Validate current step
  const validateStep = () => {
    const newErrors = {};
    
    switch (activeStep) {
      case 1: // Admin Account
        if (!formData.adminName.trim()) {
          newErrors.adminName = 'Admin name is required';
        }
        
        if (!formData.adminEmail.trim()) {
          newErrors.adminEmail = 'Admin email is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.adminEmail)) {
          newErrors.adminEmail = 'Invalid email format';
        }
        
        if (!formData.adminPassword) {
          newErrors.adminPassword = 'Password is required';
        } else if (formData.adminPassword.length < 8) {
          newErrors.adminPassword = 'Password must be at least 8 characters';
        }
        
        if (formData.adminPassword !== formData.adminPasswordConfirm) {
          newErrors.adminPasswordConfirm = 'Passwords do not match';
        }
        break;
        
      case 2: // System Settings
        if (!formData.siteName.trim()) {
          newErrors.siteName = 'Site name is required';
        }
        
        if (!formData.siteUrl.trim()) {
          newErrors.siteUrl = 'Site URL is required';
        } else if (!/^https?:\/\/\S+/.test(formData.siteUrl)) {
          newErrors.siteUrl = 'Invalid URL format';
        }
        break;
        
      case 3: // Database Setup
        if (!formData.databaseHost.trim()) {
          newErrors.databaseHost = 'Database host is required';
        }
        
        if (!formData.databaseName.trim()) {
          newErrors.databaseName = 'Database name is required';
        }
        
        if (formData.databaseType !== 'mongodb' && !formData.databaseUser.trim()) {
          newErrors.databaseUser = 'Database user is required';
        }
        break;
        
      case 4: // Platform Support
        if (formData.wordpressSupport && !formData.wordpressAdminPassword) {
          newErrors.wordpressAdminPassword = 'WordPress admin password is required when WordPress support is enabled';
        }
        
        if (formData.browserExtensionSupport && formData.browserExtensionTypes.length === 0) {
          newErrors.browserExtensionTypes = 'Select at least one browser extension type';
        }
        
        if (formData.mobileAppSupport && formData.mobileAppPlatforms.length === 0) {
          newErrors.mobileAppPlatforms = 'Select at least one mobile app platform';
        }
        break;
        
      case 6: // Integrations
        if (formData.githubEnabled && !formData.githubToken.trim()) {
          newErrors.githubToken = 'GitHub token is required when GitHub integration is enabled';
        }
        break;
        
      default:
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle next button click
  const handleNext = () => {
    if (activeStep === 0 || validateStep()) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    }
  };
  
  // Handle back button click
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  
  // Handle form submission
  const handleSubmit = async () => {
    try {
      setIsLoading(true);
      
      // Simulate API call to save configuration
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Success
      toast.success('Configuration completed successfully!');
      setSetupComplete(true);
    } catch (error) {
      toast.error('Configuration failed: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Render step content
  const getStepContent = (step) => {
    switch (step) {
      case 0: // Welcome
        return (
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <Typography variant="h4" gutterBottom>
              Welcome to AutoLaunch Studio!
            </Typography>
            <Typography variant="body1" paragraph>
              This wizard will guide you through the initial setup of your AutoLaunch Studio installation.
            </Typography>
            <Typography variant="body1" paragraph>
              AutoLaunch Studio is a comprehensive platform for creating, deploying, and managing various types of web applications, mobile apps, WordPress themes/plugins, browser extensions, and more.
            </Typography>
            <Typography variant="body1">
              Click "Next" to begin the setup process.
            </Typography>
          </Box>
        );
        
      case 1: // Admin Account
        return (
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom>
              Create Admin Account
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              This account will have full administrative privileges.
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Name"
                  name="adminName"
                  value={formData.adminName}
                  onChange={handleInputChange}
                  error={!!errors.adminName}
                  helperText={errors.adminName}
                  required
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  name="adminEmail"
                  type="email"
                  value={formData.adminEmail}
                  onChange={handleInputChange}
                  error={!!errors.adminEmail}
                  helperText={errors.adminEmail}
                  required
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Password"
                  name="adminPassword"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.adminPassword}
                  onChange={handleInputChange}
                  error={!!errors.adminPassword}
                  helperText={errors.adminPassword}
                  required
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          onClick={handleTogglePasswordVisibility}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Confirm Password"
                  name="adminPasswordConfirm"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.adminPasswordConfirm}
                  onChange={handleInputChange}
                  error={!!errors.adminPasswordConfirm}
                  helperText={errors.adminPasswordConfirm}
                  required
                />
              </Grid>
            </Grid>
          </Box>
        );
        
      case 2: // System Settings
        return (
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom>
              System Settings
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Configure basic system settings for your AutoLaunch Studio installation.
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Site Name"
                  name="siteName"
                  value={formData.siteName}
                  onChange={handleInputChange}
                  error={!!errors.siteName}
                  helperText={errors.siteName}
                  required
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Site URL"
                  name="siteUrl"
                  value={formData.siteUrl}
                  onChange={handleInputChange}
                  error={!!errors.siteUrl}
                  helperText={errors.siteUrl}
                  required
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Frontend Port"
                  name="frontendPort"
                  type="number"
                  value={formData.frontendPort}
                  onChange={handleInputChange}
                  error={!!errors.frontendPort}
                  helperText={errors.frontendPort}
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Backend Port"
                  name="backendPort"
                  type="number"
                  value={formData.backendPort}
                  onChange={handleInputChange}
                  error={!!errors.backendPort}
                  helperText={errors.backendPort}
                />
              </Grid>
            </Grid>
          </Box>
        );
        
      case 3: // Database Setup
        return (
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom>
              Database Setup
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Configure the database connection for your AutoLaunch Studio installation.
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Database Type</InputLabel>
                  <Select
                    name="databaseType"
                    value={formData.databaseType}
                    onChange={handleInputChange}
                    label="Database Type"
                  >
                    <MenuItem value="mongodb">MongoDB</MenuItem>
                    <MenuItem value="postgres">PostgreSQL</MenuItem>
                    <MenuItem value="mysql">MySQL</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12} sm={8}>
                <TextField
                  fullWidth
                  label="Database Host"
                  name="databaseHost"
                  value={formData.databaseHost}
                  onChange={handleInputChange}
                  error={!!errors.databaseHost}
                  helperText={errors.databaseHost}
                  required
                />
              </Grid>
              
              <Grid item xs={12} sm={4}>
                <TextField
                  fullWidth
                  label="Database Port"
                  name="databasePort"
                  type="number"
                  value={formData.databasePort}
                  onChange={handleInputChange}
                  error={!!errors.databasePort}
                  helperText={errors.databasePort}
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Database Name"
                  name="databaseName"
                  value={formData.databaseName}
                  onChange={handleInputChange}
                  error={!!errors.databaseName}
                  helperText={errors.databaseName}
                  required
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Database User"
                  name="databaseUser"
                  value={formData.databaseUser}
                  onChange={handleInputChange}
                  error={!!errors.databaseUser}
                  helperText={errors.databaseUser}
                  required={formData.databaseType !== 'mongodb'}
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Database Password"
                  name="databasePassword"
                  type="password"
                  value={formData.databasePassword}
                  onChange={handleInputChange}
                  error={!!errors.databasePassword}
                  helperText={errors.databasePassword}
                />
              </Grid>
              
              <Grid item xs={12}>
                <Alert severity="info">
                  For MongoDB, you can leave the username and password fields empty if authentication is not enabled.
                </Alert>
              </Grid>
            </Grid>
          </Box>
        );
        
      case 4: // Platform Support
        return (
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom>
              Platform Support
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Configure which platforms you want to support in your AutoLaunch Studio installation.
            </Typography>
            
            <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
              <Tabs value={platformTabValue} onChange={handlePlatformTabChange} aria-label="platform tabs">
                <Tab icon={<WordPress />} label="WordPress" />
                <Tab icon={<Extension />} label="Browser Extensions" />
                <Tab icon={<PhoneAndroid />} label="Mobile Apps" />
                <Tab icon={<Web />} label="Web Apps" />
              </Tabs>
            </Box>
            
            {platformTabValue === 0 && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Switch
                        name="wordpressSupport"
                        checked={formData.wordpressSupport}
                        onChange={handleInputChange}
                        color="primary"
                      />
                    }
                    label="Enable WordPress Support"
                  />
                </Grid>
                
                {formData.wordpressSupport && (
                  <>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="WordPress Port"
                        name="wordpressPort"
                        type="number"
                        value={formData.wordpressPort}
                        onChange={handleInputChange}
                        error={!!errors.wordpressPort}
                        helperText={errors.wordpressPort}
                      />
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="WordPress Admin Username"
                        name="wordpressAdminUser"
                        value={formData.wordpressAdminUser}
                        onChange={handleInputChange}
                        error={!!errors.wordpressAdminUser}
                        helperText={errors.wordpressAdminUser}
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="WordPress Admin Password"
                        name="wordpressAdminPassword"
                        type="password"
                        value={formData.wordpressAdminPassword}
                        onChange={handleInputChange}
                        error={!!errors.wordpressAdminPassword}
                        helperText={errors.wordpressAdminPassword}
                        required
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Alert severity="info">
                        WordPress support includes a local WordPress installation for theme and plugin development and testing.
                      </Alert>
                    </Grid>
                  </>
                )}
              </Grid>
            )}
            
            {platformTabValue === 1 && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Switch
                        name="browserExtensionSupport"
                        checked={formData.browserExtensionSupport}
                        onChange={handleInputChange}
                        color="primary"
                      />
                    }
                    label="Enable Browser Extension Support"
                  />
                </Grid>
                
                {formData.browserExtensionSupport && (
                  <>
                    <Grid item xs={12}>
                      <FormControl fullWidth error={!!errors.browserExtensionTypes}>
                        <InputLabel>Browser Extension Types</InputLabel>
                        <Select
                          multiple
                          value={formData.browserExtensionTypes}
                          onChange={(e) => handleArrayInputChange('browserExtensionTypes', e.target.value)}
                          label="Browser Extension Types"
                        >
                          <MenuItem value="chrome">Chrome</MenuItem>
                          <MenuItem value="firefox">Firefox</MenuItem>
                          <MenuItem value="edge">Edge</MenuItem>
                          <MenuItem value="safari">Safari</MenuItem>
                          <MenuItem value="opera">Opera</MenuItem>
                        </Select>
                        {errors.browserExtensionTypes && (
                          <Typography variant="caption" color="error">
                            {errors.browserExtensionTypes}
                          </Typography>
                        )}
                      </FormControl>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Alert severity="info">
                        Browser extension support includes tools for developing, testing, and packaging extensions for various browsers.
                      </Alert>
                    </Grid>
                  </>
                )}
              </Grid>
            )}
            
            {platformTabValue === 2 && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Switch
                        name="mobileAppSupport"
                        checked={formData.mobileAppSupport}
                        onChange={handleInputChange}
                        color="primary"
                      />
                    }
                    label="Enable Mobile App Support"
                  />
                </Grid>
                
                {formData.mobileAppSupport && (
                  <>
                    <Grid item xs={12}>
                      <FormControl fullWidth error={!!errors.mobileAppPlatforms}>
                        <InputLabel>Mobile App Platforms</InputLabel>
                        <Select
                          multiple
                          value={formData.mobileAppPlatforms}
                          onChange={(e) => handleArrayInputChange('mobileAppPlatforms', e.target.value)}
                          label="Mobile App Platforms"
                        >
                          <MenuItem value="android">Android</MenuItem>
                          <MenuItem value="ios">iOS</MenuItem>
                          <MenuItem value="pwa">Progressive Web App</MenuItem>
                        </Select>
                        {errors.mobileAppPlatforms && (
                          <Typography variant="caption" color="error">
                            {errors.mobileAppPlatforms}
                          </Typography>
                        )}
                      </FormControl>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            name="mobileAppBuildTools"
                            checked={formData.mobileAppBuildTools}
                            onChange={handleInputChange}
                            color="primary"
                          />
                        }
                        label="Install Mobile App Build Tools (Android SDK, React Native CLI, etc.)"
                      />
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Alert severity="info">
                        Mobile app support includes tools for developing, testing, and building mobile applications for various platforms.
                      </Alert>
                    </Grid>
                  </>
                )}
              </Grid>
            )}
            
            {platformTabValue === 3 && (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Alert severity="info">
                    Web app support is enabled by default and includes tools for developing and deploying various types of web applications.
                  </Alert>
                </Grid>
              </Grid>
            )}
          </Box>
        );
        
      case 5: // Deployment Settings
        return (
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom>
              Deployment Settings
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Configure how applications are deployed in your AutoLaunch Studio installation.
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Default Environment</InputLabel>
                  <Select
                    name="defaultEnvironment"
                    value={formData.defaultEnvironment}
                    onChange={handleInputChange}
                    label="Default Environment"
                  >
                    <MenuItem value="development">Development</MenuItem>
                    <MenuItem value="staging">Staging</MenuItem>
                    <MenuItem value="production">Production</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Deployment Method</InputLabel>
                  <Select
                    name="deploymentMethod"
                    value={formData.deploymentMethod}
                    onChange={handleInputChange}
                    label="Deployment Method"
                  >
                    <MenuItem value="docker">Docker</MenuItem>
                    <MenuItem value="github">GitHub Actions</MenuItem>
                    <MenuItem value="vercel">Vercel</MenuItem>
                    <MenuItem value="netlify">Netlify</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Switch
                      name="autoDeployEnabled"
                      checked={formData.autoDeployEnabled}
                      onChange={handleInputChange}
                      color="primary"
                    />
                  }
                  label="Enable Auto-Deploy (automatically deploy apps when created)"
                />
              </Grid>
              
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Switch
                      name="requireApproval"
                      checked={formData.requireApproval}
                      onChange={handleInputChange}
                      color="primary"
                    />
                  }
                  label="Require Admin Approval for Production Deployments"
                />
              </Grid>
              
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Switch
                      name="notifyOnDeployment"
                      checked={formData.notifyOnDeployment}
                      onChange={handleInputChange}
                      color="primary"
                    />
                  }
                  label="Send Email Notifications for Deployments"
                />
              </Grid>
            </Grid>
          </Box>
        );
        
      case 6: // Integrations
        return (
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom>
              Integrations
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Configure integrations with external services.
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Cursor AI Integration
                </Typography>
                <FormControlLabel
                  control={
                    <Switch
                      name="cursorAiEnabled"
                      checked={formData.cursorAiEnabled}
                      onChange={handleInputChange}
                      color="primary"
                    />
                  }
                  label="Enable Cursor AI Integration"
                />
              </Grid>
              
              {formData.cursorAiEnabled && (
                <Grid item xs={12}>
                  <Alert severity="info">
                    Cursor AI is a coding assistant integrated with VS Code/Visual Studio that helps with code generation, refactoring, and more. This integration will set up the development environment for using Cursor AI with AutoLaunch Studio.
                  </Alert>
                </Grid>
              )}
              
              <Grid item xs={12}>
                <Divider sx={{ my: 2 }} />
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  GitHub Integration
                </Typography>
                <FormControlLabel
                  control={
                    <Switch
                      name="githubEnabled"
                      checked={formData.githubEnabled}
                      onChange={handleInputChange}
                      color="primary"
                    />
                  }
                  label="Enable GitHub Integration"
                />
              </Grid>
              
              {formData.githubEnabled && (
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="GitHub Personal Access Token"
                    name="githubToken"
                    value={formData.githubToken}
                    onChange={handleInputChange}
                    error={!!errors.githubToken}
                    helperText={errors.githubToken}
                    required
                  />
                </Grid>
              )}
              
              <Grid item xs={12}>
                <Divider sx={{ my: 2 }} />
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Analytics Integration
                </Typography>
                <FormControlLabel
                  control={
                    <Switch
                      name="analyticsEnabled"
                      checked={formData.analyticsEnabled}
                      onChange={handleInputChange}
                      color="primary"
                    />
                  }
                  label="Enable Analytics (PostHog)"
                />
              </Grid>
            </Grid>
          </Box>
        );
        
      case 7: // Confirmation
        return (
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom>
              Configuration Summary
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              Please review your configuration before finalizing the setup.
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    <Settings fontSize="small" sx={{ mr: 1, verticalAlign: 'middle' }} />
                    System Settings
                  </Typography>
                  <Typography variant="body2">Site Name: {formData.siteName}</Typography>
                  <Typography variant="body2">Site URL: {formData.siteUrl}</Typography>
                  <Typography variant="body2">Frontend Port: {formData.frontendPort}</Typography>
                  <Typography variant="body2">Backend Port: {formData.backendPort}</Typography>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    <Security fontSize="small" sx={{ mr: 1, verticalAlign: 'middle' }} />
                    Admin Account
                  </Typography>
                  <Typography variant="body2">Name: {formData.adminName}</Typography>
                  <Typography variant="body2">Email: {formData.adminEmail}</Typography>
                  <Typography variant="body2">Password: ••••••••</Typography>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    <Storage fontSize="small" sx={{ mr: 1, verticalAlign: 'middle' }} />
                    Database Configuration
                  </Typography>
                  <Typography variant="body2">Type: {formData.databaseType}</Typography>
                  <Typography variant="body2">Host: {formData.databaseHost}</Typography>
                  <Typography variant="body2">Port: {formData.databasePort}</Typography>
                  <Typography variant="body2">Database: {formData.databaseName}</Typography>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    <CloudDone fontSize="small" sx={{ mr: 1, verticalAlign: 'middle' }} />
                    Deployment Settings
                  </Typography>
                  <Typography variant="body2">Default Environment: {formData.defaultEnvironment}</Typography>
                  <Typography variant="body2">Deployment Method: {formData.deploymentMethod}</Typography>
                  <Typography variant="body2">Auto-Deploy: {formData.autoDeployEnabled ? 'Enabled' : 'Disabled'}</Typography>
                  <Typography variant="body2">Require Approval: {formData.requireApproval ? 'Yes' : 'No'}</Typography>
                </Paper>
              </Grid>
              
              <Grid item xs={12}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    <Extension fontSize="small" sx={{ mr: 1, verticalAlign: 'middle' }} />
                    Platform Support
                  </Typography>
                  <Typography variant="body2">WordPress: {formData.wordpressSupport ? 'Enabled' : 'Disabled'}</Typography>
                  <Typography variant="body2">Browser Extensions: {formData.browserExtensionSupport ? 'Enabled' : 'Disabled'}</Typography>
                  <Typography variant="body2">Mobile Apps: {formData.mobileAppSupport ? 'Enabled' : 'Disabled'}</Typography>
                  <Typography variant="body2">Web Apps: Enabled</Typography>
                </Paper>
              </Grid>
              
              <Grid item xs={12}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    <Code fontSize="small" sx={{ mr: 1, verticalAlign: 'middle' }} />
                    Integrations
                  </Typography>
                  <Typography variant="body2">Cursor AI: {formData.cursorAiEnabled ? 'Enabled' : 'Disabled'}</Typography>
                  <Typography variant="body2">GitHub: {formData.githubEnabled ? 'Enabled' : 'Disabled'}</Typography>
                  <Typography variant="body2">Analytics: {formData.analyticsEnabled ? 'Enabled' : 'Disabled'}</Typography>
                </Paper>
              </Grid>
            </Grid>
          </Box>
        );
        
      default:
        return 'Unknown step';
    }
  };
  
  // If already set up, show completion message
  if (setupComplete) {
    return (
      <Container maxWidth="md">
        <Paper sx={{ p: 4, mt: 4, mb: 4, textAlign: 'center' }}>
          <CheckCircle color="success" sx={{ fontSize: 60, mb: 2 }} />
          <Typography variant="h4" gutterBottom>
            Setup Complete!
          </Typography>
          <Typography variant="body1" paragraph>
            Your AutoLaunch Studio has been successfully configured.
          </Typography>
          <Button
            variant="contained"
            color="primary"
            href="/dashboard"
            size="large"
          >
            Go to Dashboard
          </Button>
        </Paper>
      </Container>
    );
  }
  
  // Show loading state
  if (isLoading && activeStep === 0) {
    return (
      <Container maxWidth="md">
        <Paper sx={{ p: 4, mt: 4, mb: 4, textAlign: 'center' }}>
          <CircularProgress sx={{ mb: 2 }} />
          <Typography variant="h6">
            Checking setup status...
          </Typography>
        </Paper>
      </Container>
    );
  }
  
  return (
    <Container maxWidth="md">
      <Paper sx={{ p: 4, mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          AutoLaunch Studio Setup
        </Typography>
        <Divider sx={{ mb: 4 }} />
        
        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        {getStepContent(activeStep)}
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
          <Button
            disabled={activeStep === 0}
            onClick={handleBack}
            variant="outlined"
          >
            Back
          </Button>
          
          {activeStep === steps.length - 1 ? (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <CircularProgress size={24} sx={{ mr: 1 }} />
                  Finalizing...
                </>
              ) : (
                'Complete Setup'
              )}
            </Button>
          ) : (
            <Button
              variant="contained"
              color="primary"
              onClick={handleNext}
            >
              Next
            </Button>
          )}
        </Box>
      </Paper>
    </Container>
  );
}

export default ConfigWizard;

const App = require('../models/app.model');
const Deployment = require('../models/deployment.model');
const Log = require('../models/log.model');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const util = require('util');
const execPromise = util.promisify(exec);

/**
 * Deploy application using Cursor AI
 */
exports.deployCursor = async (req, res, next) => {
  try {
    const { appId, environment = 'production' } = req.body;
    
    // Find app
    const app = await App.findById(appId);
    if (!app) {
      return res.status(404).json({ message: 'App not found' });
    }
    
    // Create deployment record
    const version = app.currentVersion 
      ? incrementVersion(app.currentVersion) 
      : '1.0.0';
    
    const deployment = new Deployment({
      app: app._id,
      version,
      environment,
      status: 'pending',
      deployedBy: req.user._id
    });
    
    await deployment.save();
    
    // Log deployment initiation
    const log = new Log({
      level: 'info',
      message: `Deployment of ${app.name} v${version} to ${environment} initiated by ${req.user.name}`,
      source: 'deployment',
      user: req.user._id,
      app: app._id,
      deployment: deployment._id
    });
    await log.save();
    
    // Update app status
    app.status = 'building';
    await app.save();
    
    // Start deployment process in background
    startCursorDeployment(deployment._id, app, req.user);
    
    res.status(200).json({ 
      message: 'Deployment initiated successfully', 
      deployment 
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Get deployment status
 */
exports.getDeploymentStatus = async (req, res, next) => {
  try {
    const deployment = await Deployment.findById(req.params.id)
      .populate('app', 'name slug')
      .populate('deployedBy', 'name email');
    
    if (!deployment) {
      return res.status(404).json({ message: 'Deployment not found' });
    }
    
    res.status(200).json(deployment);
  } catch (error) {
    next(error);
  }
};

/**
 * Rollback deployment
 */
exports.rollbackDeployment = async (req, res, next) => {
  try {
    const deployment = await Deployment.findById(req.params.id)
      .populate('app', 'name slug')
      .populate('deployedBy', 'name email');
    
    if (!deployment) {
      return res.status(404).json({ message: 'Deployment not found' });
    }
    
    if (deployment.status !== 'success') {
      return res.status(400).json({ message: 'Only successful deployments can be rolled back' });
    }
    
    // Find previous successful deployment
    const previousDeployment = await Deployment.findOne({
      app: deployment.app,
      status: 'success',
      createdAt: { $lt: deployment.createdAt }
    }).sort({ createdAt: -1 });
    
    if (!previousDeployment) {
      return res.status(400).json({ message: 'No previous deployment found to rollback to' });
    }
    
    // Create rollback deployment
    const rollbackDeployment = new Deployment({
      app: deployment.app._id,
      version: previousDeployment.version,
      environment: deployment.environment,
      status: 'pending',
      deployedBy: req.user._id,
      isRollback: true,
      rollbackFrom: deployment._id
    });
    
    await rollbackDeployment.save();
    
    // Update app status
    const app = await App.findById(deployment.app._id);
    app.status = 'building';
    await app.save();
    
    // Log rollback initiation
    const log = new Log({
      level: 'warning',
      message: `Rollback of ${app.name} from v${deployment.version} to v${previousDeployment.version} initiated by ${req.user.name}`,
      source: 'deployment',
      user: req.user._id,
      app: app._id,
      deployment: rollbackDeployment._id
    });
    await log.save();
    
    // Start rollback process in background
    startCursorRollback(rollbackDeployment._id, app, req.user, previousDeployment);
    
    res.status(200).json({ 
      message: 'Rollback initiated successfully', 
      deployment: rollbackDeployment 
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Get deployment logs
 */
exports.getDeploymentLogs = async (req, res, next) => {
  try {
    const logs = await Log.find({ 
      deployment: req.params.id 
    }).sort({ createdAt: 1 });
    
    res.status(200).json(logs);
  } catch (error) {
    next(error);
  }
};

/**
 * Get deployment history for an app
 */
exports.getDeploymentHistory = async (req, res, next) => {
  try {
    const deployments = await Deployment.find({ 
      app: req.params.appId 
    })
      .populate('deployedBy', 'name email')
      .populate('approvedBy', 'name email')
      .sort({ createdAt: -1 });
    
    res.status(200).json(deployments);
  } catch (error) {
    next(error);
  }
};

/**
 * Helper function to increment version number
 */
function incrementVersion(version) {
  const parts = version.split('.');
  if (parts.length !== 3) return '1.0.0';
  
  // Increment patch version
  parts[2] = (parseInt(parts[2]) + 1).toString();
  return parts.join('.');
}

/**
 * Start Cursor AI deployment process
 */
async function startCursorDeployment(deploymentId, app, user) {
  try {
    // Get deployment record
    const deployment = await Deployment.findById(deploymentId);
    if (!deployment) return;
    
    // Log deployment start
    const startLog = new Log({
      level: 'info',
      message: `Starting deployment process for ${app.name} v${deployment.version}`,
      source: 'deployment',
      deployment: deployment._id,
      app: app._id,
      user: user._id
    });
    await startLog.save();
    
    // Prepare deployment directory
    const deployDir = path.join(__dirname, '../../../deploy', app._id.toString());
    if (!fs.existsSync(deployDir)) {
      fs.mkdirSync(deployDir, { recursive: true });
    }
    
    // Create .env.cursor file with deployment settings
    const envContent = `CURSOR_API_KEY=${process.env.CURSOR_API_KEY}
CURSOR_WORKSPACE_ID=${process.env.CURSOR_WORKSPACE_ID}
APP_NAME=${app.name}
APP_SLUG=${app.slug || app.name.toLowerCase().replace(/\s+/g, '-')}
FRONTEND_PORT=3000
BACKEND_PORT=3001`;
    
    fs.writeFileSync(path.join(deployDir, '.env.cursor'), envContent);
    
    // Copy deployment script to deployment directory
    const scriptPath = path.join(__dirname, '../../../scripts/cursor-ai/deploy_to_cursor.js');
    const targetScriptPath = path.join(deployDir, 'deploy_to_cursor.js');
    fs.copyFileSync(scriptPath, targetScriptPath);
    
    // Make script executable
    await execPromise(`chmod +x ${targetScriptPath}`);
    
    // Run deployment script
    const deploymentProcess = exec(`cd ${deployDir} && node deploy_to_cursor.js`, 
      async (error, stdout, stderr) => {
        try {
          // Update deployment status based on result
          if (error) {
            deployment.status = 'failed';
            deployment.error = error.message;
            await deployment.save();
            
            // Update app status
            app.status = 'failed';
            await app.save();
            
            // Log deployment failure
            const failLog = new Log({
              level: 'error',
              message: `Deployment of ${app.name} v${deployment.version} failed: ${error.message}`,
              source: 'deployment',
              deployment: deployment._id,
              app: app._id,
              user: user._id
            });
            await failLog.save();
            
            return;
          }
          
          // Extract deployment URL from output
          const urlMatch = stdout.match(/Your application is now available at: (https:\/\/[^\s]+)/);
          const deploymentUrl = urlMatch ? urlMatch[1] : null;
          
          // Update deployment record
          deployment.status = 'success';
          deployment.completedAt = Date.now();
          deployment.liveUrl = deploymentUrl;
          await deployment.save();
          
          // Update app record
          app.status = 'deployed';
          app.currentVersion = deployment.version;
          app.deployedAt = Date.now();
          app.liveUrl = deploymentUrl;
          await app.save();
          
          // Log deployment success
          const successLog = new Log({
            level: 'success',
            message: `Deployment of ${app.name} v${deployment.version} completed successfully`,
            source: 'deployment',
            deployment: deployment._id,
            app: app._id,
            user: user._id
          });
          await successLog.save();
        } catch (err) {
          console.error('Error in deployment callback:', err);
        }
      }
    );
    
    // Log deployment output
    deploymentProcess.stdout.on('data', async (data) => {
      const outputLog = new Log({
        level: 'info',
        message: `[Deployment Output] ${data.toString().trim()}`,
        source: 'deployment',
        deployment: deployment._id,
        app: app._id,
        user: user._id
      });
      await outputLog.save();
    });
    
    deploymentProcess.stderr.on('data', async (data) => {
      const errorLog = new Log({
        level: 'warning',
        message: `[Deployment Error] ${data.toString().trim()}`,
        source: 'deployment',
        deployment: deployment._id,
        app: app._id,
        user: user._id
      });
      await errorLog.save();
    });
    
  } catch (error) {
    console.error('Error in deployment process:', error);
    
    // Update deployment status
    const deployment = await Deployment.findById(deploymentId);
    if (deployment) {
      deployment.status = 'failed';
      deployment.error = error.message;
      await deployment.save();
      
      // Update app status
      const app = await App.findById(deployment.app);
      if (app) {
        app.status = 'failed';
        await app.save();
      }
      
      // Log error
      const errorLog = new Log({
        level: 'error',
        message: `Deployment process error: ${error.message}`,
        source: 'deployment',
        deployment: deployment._id,
        app: deployment.app,
        user: deployment.deployedBy
      });
      await errorLog.save();
    }
  }
}

/**
 * Start Cursor AI rollback process
 */
async function startCursorRollback(rollbackId, app, user, previousDeployment) {
  try {
    // Get rollback record
    const rollback = await Deployment.findById(rollbackId);
    if (!rollback) return;
    
    // Log rollback start
    const startLog = new Log({
      level: 'info',
      message: `Starting rollback process for ${app.name} to v${previousDeployment.version}`,
      source: 'deployment',
      deployment: rollback._id,
      app: app._id,
      user: user._id
    });
    await startLog.save();
    
    // Simulate rollback process (in a real implementation, this would use the actual rollback mechanism)
    setTimeout(async () => {
      try {
        // Update rollback record
        rollback.status = 'success';
        rollback.completedAt = Date.now();
        rollback.liveUrl = previousDeployment.liveUrl;
        await rollback.save();
        
        // Update app record
        app.status = 'deployed';
        app.currentVersion = previousDeployment.version;
        app.deployedAt = Date.now();
        app.liveUrl = previousDeployment.liveUrl;
        await app.save();
        
        // Log rollback success
        const successLog = new Log({
          level: 'success',
          message: `Rollback of ${app.name} to v${previousDeployment.version} completed successfully`,
          source: 'deployment',
          deployment: rollback._id,
          app: app._id,
          user: user._id
        });
        await successLog.save();
      } catch (error) {
        console.error('Error in rollback completion:', error);
      }
    }, 5000); // Simulate 5-second rollback process
    
  } catch (error) {
    console.error('Error in rollback process:', error);
    
    // Update rollback status
    const rollback = await Deployment.findById(rollbackId);
    if (rollback) {
      rollback.status = 'failed';
      rollback.error = error.message;
      await rollback.save();
      
      // Update app status
      const app = await App.findById(rollback.app);
      if (app) {
        app.status = 'failed';
        await app.save();
      }
      
      // Log error
      const errorLog = new Log({
        level: 'error',
        message: `Rollback process error: ${error.message}`,
        source: 'deployment',
        deployment: rollback._id,
        app: rollback.app,
        user: rollback.deployedBy
      });
      await errorLog.save();
    }
  }
}

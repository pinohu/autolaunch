const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');

// Apply auth middleware to all admin routes
router.use(authMiddleware.verifyToken);
router.use(roleMiddleware.isAdmin);

// User management routes
router.get('/users', adminController.getAllUsers);
router.post('/users', adminController.createUser);
router.get('/users/:id', adminController.getUserById);
router.put('/users/:id', adminController.updateUser);
router.delete('/users/:id', adminController.deleteUser);

// Deployment management routes
router.get('/deployments', adminController.getAllDeployments);
router.get('/deployments/:id', adminController.getDeploymentById);
router.post('/deployments/:id/approve', adminController.approveDeployment);
router.post('/deployments/:id/rollback', adminController.rollbackDeployment);

// Logs routes
router.get('/logs', adminController.getLogs);
router.delete('/logs', adminController.clearLogs);

// System settings routes
router.get('/settings', adminController.getSettings);
router.put('/settings', adminController.updateSettings);

// Analytics routes
router.get('/analytics/users', adminController.getUserAnalytics);
router.get('/analytics/apps', adminController.getAppAnalytics);
router.get('/analytics/deployments', adminController.getDeploymentAnalytics);

module.exports = router;

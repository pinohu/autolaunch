const mongoose = require('mongoose');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const axios = require('axios');

/**
 * AutoLaunch Service
 * Handles automatic deployment of applications upon creation
 */
class AutoLaunchService {
  constructor() {
    this.deploymentMethods = {
      docker: this.deployWithDocker,
      github: this.deployWithGitHub,
      vercel: this.deployWithVercel,
      netlify: this.deployWithNetlify
    };
    
    // Default configuration
    this.config = {
      autoDeployEnabled: true,
      defaultEnvironment: 'staging',
      deploymentMethod: 'docker',
      requireApproval: true,
      notifyOnDeployment: true,
      baseUrl: 'https://apps.autolaunchstudio.com'
    };
    
    // Load configuration
    this.loadConfig();
  }
  
  /**
   * Load configuration from database or environment variables
   */
  async loadConfig() {
    try {
      // Try to load from database if available
      if (mongoose.connection.readyState === 1) {
        const Config = mongoose.model('Config');
        const config = await Config.findOne({ configType: 'deployment' });
        
        if (config) {
          this.config = {
            ...this.config,
            ...config.settings
          };
        }
      }
      
      // Override with environment variables if present
      if (process.env.AUTO_DEPLOY_ENABLED) {
        this.config.autoDeployEnabled = process.env.AUTO_DEPLOY_ENABLED === 'true';
      }
      
      if (process.env.DEFAULT_ENVIRONMENT) {
        this.config.defaultEnvironment = process.env.DEFAULT_ENVIRONMENT;
      }
      
      if (process.env.DEPLOYMENT_METHOD) {
        this.config.deploymentMethod = process.env.DEPLOYMENT_METHOD;
      }
      
      if (process.env.REQUIRE_APPROVAL) {
        this.config.requireApproval = process.env.REQUIRE_APPROVAL === 'true';
      }
      
      if (process.env.NOTIFY_ON_DEPLOYMENT) {
        this.config.notifyOnDeployment = process.env.NOTIFY_ON_DEPLOYMENT === 'true';
      }
      
      if (process.env.BASE_URL) {
        this.config.baseUrl = process.env.BASE_URL;
      }
      
      console.log('AutoLaunch configuration loaded:', this.config);
    } catch (error) {
      console.error('Error loading AutoLaunch configuration:', error);
    }
  }
  
  /**
   * Auto-launch an application
   * @param {Object} app - Application object
   * @param {String} appType - Type of application (website, wordpress-theme, wordpress-plugin, browser-extension, mobile-app)
   * @param {String} environment - Deployment environment (development, staging, production)
   * @returns {Promise<Object>} - Deployment result
   */
  async launchApp(app, appType, environment = null) {
    try {
      // Check if auto-deploy is enabled
      if (!this.config.autoDeployEnabled) {
        return {
          success: false,
          message: 'Auto-deploy is disabled in configuration',
          app
        };
      }
      
      // Use default environment if not specified
      const deployEnv = environment || this.config.defaultEnvironment;
      
      // Check if approval is required for production deployments
      if (deployEnv === 'production' && this.config.requireApproval && !app.approved) {
        return {
          success: false,
          message: 'Production deployment requires approval',
          status: 'pending_approval',
          app
        };
      }
      
      console.log(`Starting auto-launch for ${appType}: ${app.name} to ${deployEnv} environment`);
      
      // Create deployment record
      const deployment = await this.createDeploymentRecord(app, appType, deployEnv);
      
      // Prepare app files
      const appDir = await this.prepareAppFiles(app, appType);
      
      // Deploy using the configured method
      const deployMethod = this.deploymentMethods[this.config.deploymentMethod];
      
      if (!deployMethod) {
        throw new Error(`Unsupported deployment method: ${this.config.deploymentMethod}`);
      }
      
      // Execute deployment
      const result = await deployMethod.call(this, app, appType, deployEnv, appDir);
      
      // Update deployment record
      await this.updateDeploymentRecord(deployment._id, {
        status: result.success ? 'deployed' : 'failed',
        deployedUrl: result.url,
        logs: result.logs
      });
      
      // Send notification if enabled
      if (this.config.notifyOnDeployment) {
        await this.sendDeploymentNotification(app, result);
      }
      
      return {
        success: result.success,
        message: result.message,
        url: result.url,
        logs: result.logs,
        deployment: deployment._id,
        app
      };
    } catch (error) {
      console.error(`Error in auto-launch for ${app.name}:`, error);
      
      return {
        success: false,
        message: `Deployment failed: ${error.message}`,
        error: error.toString(),
        app
      };
    }
  }
  
  /**
   * Create a deployment record in the database
   * @param {Object} app - Application object
   * @param {String} appType - Type of application
   * @param {String} environment - Deployment environment
   * @returns {Promise<Object>} - Created deployment record
   */
  async createDeploymentRecord(app, appType, environment) {
    try {
      const Deployment = mongoose.model('Deployment');
      
      const deployment = new Deployment({
        app: app._id,
        appType,
        environment,
        deploymentMethod: this.config.deploymentMethod,
        status: 'in_progress',
        startTime: new Date(),
        createdBy: app.createdBy
      });
      
      await deployment.save();
      return deployment;
    } catch (error) {
      console.error('Error creating deployment record:', error);
      throw error;
    }
  }
  
  /**
   * Update a deployment record in the database
   * @param {String} deploymentId - Deployment ID
   * @param {Object} updates - Fields to update
   * @returns {Promise<Object>} - Updated deployment record
   */
  async updateDeploymentRecord(deploymentId, updates) {
    try {
      const Deployment = mongoose.model('Deployment');
      
      const deployment = await Deployment.findByIdAndUpdate(
        deploymentId,
        {
          ...updates,
          endTime: new Date()
        },
        { new: true }
      );
      
      return deployment;
    } catch (error) {
      console.error('Error updating deployment record:', error);
      throw error;
    }
  }
  
  /**
   * Prepare application files for deployment
   * @param {Object} app - Application object
   * @param {String} appType - Type of application
   * @returns {Promise<String>} - Path to prepared app directory
   */
  async prepareAppFiles(app, appType) {
    try {
      // Create base directory for app files
      const baseDir = path.join(process.cwd(), 'deploy', appType, app.slug);
      
      // Ensure directory exists
      if (!fs.existsSync(baseDir)) {
        fs.mkdirSync(baseDir, { recursive: true });
      }
      
      // Different preparation logic based on app type
      switch (appType) {
        case 'website':
          await this.prepareWebsiteFiles(app, baseDir);
          break;
          
        case 'wordpress-theme':
          await this.prepareWordPressThemeFiles(app, baseDir);
          break;
          
        case 'wordpress-plugin':
          await this.prepareWordPressPluginFiles(app, baseDir);
          break;
          
        case 'browser-extension':
          await this.prepareBrowserExtensionFiles(app, baseDir);
          break;
          
        case 'mobile-app':
          await this.prepareMobileAppFiles(app, baseDir);
          break;
          
        default:
          throw new Error(`Unsupported app type: ${appType}`);
      }
      
      return baseDir;
    } catch (error) {
      console.error('Error preparing app files:', error);
      throw error;
    }
  }
  
  /**
   * Prepare website files for deployment
   * @param {Object} app - Website object
   * @param {String} baseDir - Base directory for app files
   * @returns {Promise<void>}
   */
  async prepareWebsiteFiles(app, baseDir) {
    // Create necessary directories
    const srcDir = path.join(baseDir, 'src');
    const buildDir = path.join(baseDir, 'build');
    
    if (!fs.existsSync(srcDir)) {
      fs.mkdirSync(srcDir, { recursive: true });
    }
    
    if (!fs.existsSync(buildDir)) {
      fs.mkdirSync(buildDir, { recursive: true });
    }
    
    // Write files from app.files to src directory
    if (app.files) {
      for (const fileType in app.files) {
        for (const filePath of app.files[fileType]) {
          const fileContent = await this.getFileContent(app._id, filePath);
          const destPath = path.join(srcDir, filePath);
          const destDir = path.dirname(destPath);
          
          if (!fs.existsSync(destDir)) {
            fs.mkdirSync(destDir, { recursive: true });
          }
          
          fs.writeFileSync(destPath, fileContent);
        }
      }
    }
    
    // Build the website
    await this.buildWebsite(app, srcDir, buildDir);
  }
  
  /**
   * Prepare WordPress theme files for deployment
   * @param {Object} app - WordPress theme object
   * @param {String} baseDir - Base directory for app files
   * @returns {Promise<void>}
   */
  async prepareWordPressThemeFiles(app, baseDir) {
    // Create theme directory
    const themeDir = path.join(baseDir, app.slug);
    
    if (!fs.existsSync(themeDir)) {
      fs.mkdirSync(themeDir, { recursive: true });
    }
    
    // Create style.css with theme information
    const styleCss = `/*
Theme Name: ${app.name}
Theme URI: ${app.previewUrl || ''}
Author: ${app.author ? app.author.name : 'AutoLaunch Studio'}
Author URI: ${app.author && app.author.url ? app.author.url : ''}
Description: ${app.description}
Version: ${app.version}
Requires at least: ${app.requires}
Tested up to: ${app.tested}
Requires PHP: 7.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: ${app.slug}
*/`;
    
    fs.writeFileSync(path.join(themeDir, 'style.css'), styleCss);
    
    // Write files from app.files to theme directory
    if (app.files) {
      for (const fileType in app.files) {
        for (const filePath of app.files[fileType]) {
          const fileContent = await this.getFileContent(app._id, filePath);
          const destPath = path.join(themeDir, filePath);
          const destDir = path.dirname(destPath);
          
          if (!fs.existsSync(destDir)) {
            fs.mkdirSync(destDir, { recursive: true });
          }
          
          fs.writeFileSync(destPath, fileContent);
        }
      }
    }
    
    // Create screenshot.png if it doesn't exist
    if (app.screenshot && !fs.existsSync(path.join(themeDir, 'screenshot.png'))) {
      const screenshotContent = await this.getFileContent(app._id, app.screenshot);
      fs.writeFileSync(path.join(themeDir, 'screenshot.png'), screenshotContent);
    }
    
    // Create zip file for theme
    const zipPath = path.join(baseDir, `${app.slug}.zip`);
    await this.createZipFile(themeDir, zipPath);
  }
  
  /**
   * Prepare WordPress plugin files for deployment
   * @param {Object} app - WordPress plugin object
   * @param {String} baseDir - Base directory for app files
   * @returns {Promise<void>}
   */
  async prepareWordPressPluginFiles(app, baseDir) {
    // Create plugin directory
    const pluginDir = path.join(baseDir, app.slug);
    
    if (!fs.existsSync(pluginDir)) {
      fs.mkdirSync(pluginDir, { recursive: true });
    }
    
    // Create main plugin file with plugin information
    const mainPluginFile = `<?php
/*
Plugin Name: ${app.name}
Plugin URI: ${app.previewUrl || ''}
Description: ${app.description}
Version: ${app.version}
Author: ${app.author ? app.author.name : 'AutoLaunch Studio'}
Author URI: ${app.author && app.author.url ? app.author.url : ''}
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: ${app.slug}
Domain Path: /languages
*/

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('${app.slug.toUpperCase()}_VERSION', '${app.version}');
define('${app.slug.toUpperCase()}_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('${app.slug.toUpperCase()}_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include the core plugin class
require plugin_dir_path(__FILE__) . 'includes/class-${app.slug}.php';

/**
 * Begins execution of the plugin.
 */
function run_${app.slug.replace(/-/g, '_')}() {
    $plugin = new ${app.slug.replace(/-/g, '_').replace(/(?:^|\s)\S/g, function(a) { return a.toUpperCase(); }).replace(/\s+/g, '_')}();
    $plugin->run();
}
run_${app.slug.replace(/-/g, '_')}();
`;
    
    fs.writeFileSync(path.join(pluginDir, `${app.slug}.php`), mainPluginFile);
    
    // Create readme.txt
    const readmeTxt = `=== ${app.name} ===
Contributors: ${app.author ? app.author.name.toLowerCase().replace(/\s+/g, '') : 'autolaunchstudio'}
Tags: ${app.category || 'plugin'}
Requires at least: ${app.requires}
Tested up to: ${app.tested}
Requires PHP: ${app.requiresPhp || '7.0'}
Stable tag: ${app.version}
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

${app.description}

== Description ==

${app.description}

== Installation ==

1. Upload the plugin files to the \`/wp-content/plugins/${app.slug}\` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure the plugin settings

== Frequently Asked Questions ==

= Is this plugin free? =

Yes, this plugin is completely free to use.

== Screenshots ==

1. Plugin in action

== Changelog ==

= ${app.version} =
* Initial release

== Upgrade Notice ==

= ${app.version} =
Initial release
`;
    
    fs.writeFileSync(path.join(pluginDir, 'readme.txt'), readmeTxt);
    
    // Create basic directory structure
    const directories = ['admin', 'includes', 'public', 'languages'];
    
    for (const dir of directories) {
      const dirPath = path.join(pluginDir, dir);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
    }
    
    // Write files from app.files to plugin directory
    if (app.files) {
      for (const fileType in app.files) {
        for (const filePath of app.files[fileType]) {
          const fileContent = await this.getFileContent(app._id, filePath);
          const destPath = path.join(pluginDir, filePath);
          const destDir = path.dirname(destPath);
          
          if (!fs.existsSync(destDir)) {
            fs.mkdirSync(destDir, { recursive: true });
          }
          
          fs.writeFileSync(destPath, fileContent);
        }
      }
    }
    
    // Create zip file for plugin
    const zipPath = path.join(baseDir, `${app.slug}.zip`);
    await this.createZipFile(pluginDir, zipPath);
  }
  
  /**
   * Prepare browser extension files for deployment
   * @param {Object} app - Browser extension object
   * @param {String} baseDir - Base directory for app files
   * @returns {Promise<void>}
   */
  async prepareBrowserExtensionFiles(app, baseDir) {
    // Create extension directory
    const extensionDir = path.join(baseDir, app.slug);
    
    if (!fs.existsSync(extensionDir)) {
      fs.mkdirSync(extensionDir, { recursive: true });
    }
    
    // Create manifest.json
    const manifest = {
      manifest_version: app.manifestVersion || 3,
      name: app.name,
      version: app.version,
      description: app.description,
      author: app.author ? app.author.name : undefined,
      icons: app.action && app.action.defaultIcon ? app.action.defaultIcon : undefined,
      action: app.action ? {
        default_icon: app.action.defaultIcon,
        default_title: app.action.defaultTitle,
        default_popup: app.action.defaultPopup
      } : undefined,
      background: app.backgroundScripts ? {
        service_worker: app.backgroundScripts.serviceWorker ? app.backgroundScripts.scripts[0] : undefined,
        scripts: !app.backgroundScripts.serviceWorker ? app.backgroundScripts.scripts : undefined,
        persistent: app.backgroundScripts.persistent
      } : undefined,
      content_scripts: app.contentScripts,
      permissions: app.permissions ? app.permissions.map(p => p.name) : [],
      host_permissions: app.hostPermissions ? app.hostPermissions.map(p => p.pattern) : [],
      web_accessible_resources: app.webAccessibleResources,
      options_page: app.optionsPage ? app.optionsPage.page : undefined,
      options_ui: app.optionsPage ? {
        page: app.optionsPage.page,
        open_in_tab: app.optionsPage.openInTab
      } : undefined
    };
    
    // Remove undefined properties
    Object.keys(manifest).forEach(key => {
      if (manifest[key] === undefined) {
        delete manifest[key];
      }
    });
    
    fs.writeFileSync(
      path.join(extensionDir, 'manifest.json'),
      JSON.stringify(manifest, null, 2)
    );
    
    // Write files from app.files to extension directory
    if (app.files) {
      for (const fileType in app.files) {
        for (const filePath of app.files[fileType]) {
          const fileContent = await this.getFileContent(app._id, filePath);
          const destPath = path.join(extensionDir, filePath);
          const destDir = path.dirname(destPath);
          
          if (!fs.existsSync(destDir)) {
            fs.mkdirSync(destDir, { recursive: true });
          }
          
          fs.writeFileSync(destPath, fileContent);
        }
      }
    }
    
    // Create zip files for each supported browser
    for (const browser of app.browserCompatibility || [{ browser: 'chrome' }]) {
      const zipPath = path.join(baseDir, `${app.slug}-${browser.browser}.zip`);
      await this.createZipFile(extensionDir, zipPath);
    }
  }
  
  /**
   * Prepare mobile app files for deployment
   * @param {Object} app - Mobile app object
   * @param {String} baseDir - Base directory for app files
   * @returns {Promise<void>}
   */
  async prepareMobileAppFiles(app, baseDir) {
    // Create app directory
    const appDir = path.join(baseDir, app.slug);
    
    if (!fs.existsSync(appDir)) {
      fs.mkdirSync(appDir, { recursive: true });
    }
    
    // Create app.json with app information
    const appJson = {
      expo: {
        name: app.name,
        slug: app.slug,
        version: app.version,
        orientation: 'portrait',
        icon: app.icon || './assets/icon.png',
        splash: {
          image: './assets/splash.png',
          resizeMode: 'contain',
          backgroundColor: '#ffffff'
        },
        updates: {
          fallbackToCacheTimeout: 0
        },
        assetBundlePatterns: [
          '**/*'
        ],
        ios: {
          supportsTablet: true,
          bundleIdentifier: `com.autolaunchstudio.${app.slug}`
        },
        android: {
          adaptiveIcon: {
            foregroundImage: './assets/adaptive-icon.png',
            backgroundColor: '#FFFFFF'
          },
          package: `com.autolaunchstudio.${app.slug}`
        },
        web: {
          favicon: './assets/favicon.png'
        },
        description: app.description
      }
    };
    
    fs.writeFileSync(
      path.join(appDir, 'app.json'),
      JSON.stringify(appJson, null, 2)
    );
    
    // Create package.json
    const packageJson = {
      name: app.slug,
      version: app.version,
      main: 'node_modules/expo/AppEntry.js',
      scripts: {
        start: 'expo start',
        android: 'expo start --android',
        ios: 'expo start --ios',
        web: 'expo start --web',
        eject: 'expo eject',
        build: 'expo build'
      },
      dependencies: {
        expo: '^45.0.0',
        'react': '17.0.2',
        'react-dom': '17.0.2',
        'react-native': 'https://github.com/expo/react-native/archive/sdk-45.0.0.tar.gz',
        'react-native-web': '0.17.7',
        '@react-navigation/native': '^6.0.10',
        '@react-navigation/stack': '^6.2.1'
      },
      devDependencies: {
        '@babel/core': '^7.12.9'
      },
      private: true
    };
    
    // Add state management dependencies
    if (app.stateManagement) {
      switch (app.stateManagement.type) {
        case 'redux':
          packageJson.dependencies['redux'] = '^4.2.0';
          packageJson.dependencies['react-redux'] = '^8.0.2';
          packageJson.dependencies['redux-thunk'] = '^2.4.1';
          break;
        case 'mobx':
          packageJson.dependencies['mobx'] = '^6.6.0';
          packageJson.dependencies['mobx-react'] = '^7.5.0';
          break;
        case 'context':
          // React Context API is built-in
          break;
        case 'recoil':
          packageJson.dependencies['recoil'] = '^0.7.3';
          break;
        case 'zustand':
          packageJson.dependencies['zustand'] = '^4.0.0-rc.1';
          break;
      }
    }
    
    fs.writeFileSync(
      path.join(appDir, 'package.json'),
      JSON.stringify(packageJson, null, 2)
    );
    
    // Create assets directory
    const assetsDir = path.join(appDir, 'assets');
    if (!fs.existsSync(assetsDir)) {
      fs.mkdirSync(assetsDir, { recursive: true });
    }
    
    // Write files from app.files to app directory
    if (app.files) {
      for (const fileType in app.files) {
        for (const filePath of app.files[fileType]) {
          const fileContent = await this.getFileContent(app._id, filePath);
          const destPath = path.join(appDir, filePath);
          const destDir = path.dirname(destPath);
          
          if (!fs.existsSync(destDir)) {
            fs.mkdirSync(destDir, { recursive: true });
          }
          
          fs.writeFileSync(destPath, fileContent);
        }
      }
    }
    
    // Create zip file for app source
    const zipPath = path.join(baseDir, `${app.slug}-source.zip`);
    await this.createZipFile(appDir, zipPath);
    
    // Build the app if mobile app build tools are available
    if (process.env.MOBILE_APP_BUILD_TOOLS_AVAILABLE === 'true') {
      await this.buildMobileApp(app, appDir, baseDir);
    }
  }
  
  /**
   * Get file content from database or file system
   * @param {String} appId - Application ID
   * @param {String} filePath - File path
   * @returns {Promise<Buffer|String>} - File content
   */
  async getFileContent(appId, filePath) {
    try {
      // Try to get from database first
      const File = mongoose.model('File');
      const file = await File.findOne({
        appId,
        path: filePath
      });
      
      if (file && file.content) {
        return file.content;
      }
      
      // If not in database, try to get from file system
      const fullPath = path.join(process.cwd(), 'files', appId.toString(), filePath);
      
      if (fs.existsSync(fullPath)) {
        return fs.readFileSync(fullPath);
      }
      
      // If file not found, return empty string
      console.warn(`File not found: ${filePath} for app ${appId}`);
      return '';
    } catch (error) {
      console.error('Error getting file content:', error);
      throw error;
    }
  }
  
  /**
   * Create a zip file from a directory
   * @param {String} sourceDir - Source directory
   * @param {String} destPath - Destination zip file path
   * @returns {Promise<void>}
   */
  createZipFile(sourceDir, destPath) {
    return new Promise((resolve, reject) => {
      const command = `cd "${sourceDir}" && zip -r "${destPath}" .`;
      
      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error creating zip file: ${error.message}`);
          return reject(error);
        }
        
        if (stderr) {
          console.warn(`Zip stderr: ${stderr}`);
        }
        
        console.log(`Zip file created: ${destPath}`);
        resolve();
      });
    });
  }
  
  /**
   * Build a website
   * @param {Object} app - Website object
   * @param {String} srcDir - Source directory
   * @param {String} buildDir - Build directory
   * @returns {Promise<void>}
   */
  async buildWebsite(app, srcDir, buildDir) {
    return new Promise((resolve, reject) => {
      // Check if package.json exists
      const packageJsonPath = path.join(srcDir, 'package.json');
      
      if (fs.existsSync(packageJsonPath)) {
        // If package.json exists, use npm build
        const command = `cd "${srcDir}" && npm install && npm run build`;
        
        exec(command, (error, stdout, stderr) => {
          if (error) {
            console.error(`Error building website: ${error.message}`);
            return reject(error);
          }
          
          if (stderr) {
            console.warn(`Build stderr: ${stderr}`);
          }
          
          console.log(`Website built: ${stdout}`);
          resolve();
        });
      } else {
        // If no package.json, just copy files to build directory
        const command = `cp -r "${srcDir}"/* "${buildDir}"/`;
        
        exec(command, (error, stdout, stderr) => {
          if (error) {
            console.error(`Error copying website files: ${error.message}`);
            return reject(error);
          }
          
          if (stderr) {
            console.warn(`Copy stderr: ${stderr}`);
          }
          
          console.log(`Website files copied to build directory`);
          resolve();
        });
      }
    });
  }
  
  /**
   * Build a mobile app
   * @param {Object} app - Mobile app object
   * @param {String} appDir - App directory
   * @param {String} outputDir - Output directory
   * @returns {Promise<void>}
   */
  async buildMobileApp(app, appDir, outputDir) {
    return new Promise((resolve, reject) => {
      // Build for each platform
      const platforms = app.platforms || ['android'];
      const buildCommands = [];
      
      for (const platform of platforms) {
        if (platform === 'android' || platform === 'ios') {
          buildCommands.push(`cd "${appDir}" && npm install && expo build:${platform} -t apk --non-interactive`);
        }
      }
      
      if (buildCommands.length === 0) {
        console.log('No platforms to build for');
        return resolve();
      }
      
      // Execute build commands sequentially
      const executeBuildCommands = async () => {
        for (const command of buildCommands) {
          await new Promise((resolveCommand, rejectCommand) => {
            exec(command, (error, stdout, stderr) => {
              if (error) {
                console.error(`Error building mobile app: ${error.message}`);
                return rejectCommand(error);
              }
              
              if (stderr) {
                console.warn(`Build stderr: ${stderr}`);
              }
              
              console.log(`Mobile app build output: ${stdout}`);
              resolveCommand();
            });
          });
        }
      };
      
      executeBuildCommands()
        .then(resolve)
        .catch(reject);
    });
  }
  
  /**
   * Deploy an application using Docker
   * @param {Object} app - Application object
   * @param {String} appType - Type of application
   * @param {String} environment - Deployment environment
   * @param {String} appDir - App directory
   * @returns {Promise<Object>} - Deployment result
   */
  async deployWithDocker(app, appType, environment, appDir) {
    try {
      console.log(`Deploying ${app.name} with Docker to ${environment} environment`);
      
      // Generate a unique container name
      const containerName = `autolaunch-${appType}-${app.slug}-${environment}`;
      
      // Determine port based on app type and environment
      let port;
      let internalPort;
      
      switch (appType) {
        case 'website':
          internalPort = 80;
          port = environment === 'production' ? 80 : (environment === 'staging' ? 8080 : 8081);
          break;
          
        case 'wordpress-theme':
        case 'wordpress-plugin':
          internalPort = 80;
          port = environment === 'production' ? 8080 : (environment === 'staging' ? 8081 : 8082);
          break;
          
        case 'browser-extension':
          // Browser extensions don't need a container
          return {
            success: true,
            message: 'Browser extension deployed successfully',
            url: `${this.config.baseUrl}/downloads/extensions/${app.slug}`,
            logs: 'Browser extensions are packaged as zip files and don\'t require a container'
          };
          
        case 'mobile-app':
          // Mobile apps don't need a container
          return {
            success: true,
            message: 'Mobile app deployed successfully',
            url: `${this.config.baseUrl}/downloads/mobile/${app.slug}`,
            logs: 'Mobile apps are packaged as APK/IPA files and don\'t require a container'
          };
          
        default:
          internalPort = 80;
          port = 8080;
      }
      
      // Determine Docker image based on app type
      let dockerImage;
      let dockerCommand;
      
      switch (appType) {
        case 'website':
          dockerImage = 'nginx:alpine';
          dockerCommand = `docker run -d --name ${containerName} -p ${port}:${internalPort} -v ${appDir}/build:/usr/share/nginx/html:ro ${dockerImage}`;
          break;
          
        case 'wordpress-theme':
        case 'wordpress-plugin':
          dockerImage = 'wordpress:latest';
          
          // For WordPress themes/plugins, we need to copy the files to the WordPress container
          const wpContainerName = 'autolaunch-wordpress';
          const wpCommand = `docker cp ${appDir}/${app.slug} ${wpContainerName}:/var/www/html/wp-content/${appType === 'wordpress-theme' ? 'themes' : 'plugins'}/`;
          
          await new Promise((resolve, reject) => {
            exec(wpCommand, (error, stdout, stderr) => {
              if (error) {
                console.error(`Error copying WordPress files: ${error.message}`);
                return reject(error);
              }
              
              resolve();
            });
          });
          
          return {
            success: true,
            message: `WordPress ${appType === 'wordpress-theme' ? 'theme' : 'plugin'} deployed successfully`,
            url: `${this.config.baseUrl}/wordpress/wp-admin/`,
            logs: `Files copied to WordPress container: ${wpContainerName}`
          };
          
        default:
          throw new Error(`Unsupported app type for Docker deployment: ${appType}`);
      }
      
      // Stop and remove existing container if it exists
      await new Promise((resolve) => {
        exec(`docker stop ${containerName} && docker rm ${containerName}`, () => {
          resolve();
        });
      });
      
      // Start new container
      const deployResult = await new Promise((resolve, reject) => {
        exec(dockerCommand, (error, stdout, stderr) => {
          if (error) {
            console.error(`Error deploying with Docker: ${error.message}`);
            return reject(error);
          }
          
          resolve({
            containerId: stdout.trim(),
            logs: stderr || 'Container started successfully'
          });
        });
      });
      
      // Generate URL based on environment and port
      const host = environment === 'production' ? this.config.baseUrl : `${this.config.baseUrl}:${port}`;
      const url = `${host}/${app.slug}`;
      
      return {
        success: true,
        message: 'Deployed successfully with Docker',
        url,
        logs: deployResult.logs,
        containerId: deployResult.containerId
      };
    } catch (error) {
      console.error('Error in Docker deployment:', error);
      
      return {
        success: false,
        message: `Docker deployment failed: ${error.message}`,
        logs: error.toString()
      };
    }
  }
  
  /**
   * Deploy an application using GitHub Actions
   * @param {Object} app - Application object
   * @param {String} appType - Type of application
   * @param {String} environment - Deployment environment
   * @param {String} appDir - App directory
   * @returns {Promise<Object>} - Deployment result
   */
  async deployWithGitHub(app, appType, environment, appDir) {
    try {
      console.log(`Deploying ${app.name} with GitHub Actions to ${environment} environment`);
      
      // For now, just return success with a message
      // In a real implementation, this would push to a GitHub repository and trigger a workflow
      
      return {
        success: true,
        message: 'GitHub Actions deployment not fully implemented',
        url: `${this.config.baseUrl}/${app.slug}`,
        logs: 'GitHub Actions deployment would require pushing to a repository and triggering a workflow'
      };
    } catch (error) {
      console.error('Error in GitHub deployment:', error);
      
      return {
        success: false,
        message: `GitHub deployment failed: ${error.message}`,
        logs: error.toString()
      };
    }
  }
  
  /**
   * Deploy an application using Vercel
   * @param {Object} app - Application object
   * @param {String} appType - Type of application
   * @param {String} environment - Deployment environment
   * @param {String} appDir - App directory
   * @returns {Promise<Object>} - Deployment result
   */
  async deployWithVercel(app, appType, environment, appDir) {
    try {
      console.log(`Deploying ${app.name} with Vercel to ${environment} environment`);
      
      // For now, just return success with a message
      // In a real implementation, this would use the Vercel API or CLI
      
      return {
        success: true,
        message: 'Vercel deployment not fully implemented',
        url: `https://${app.slug}.vercel.app`,
        logs: 'Vercel deployment would require using the Vercel API or CLI'
      };
    } catch (error) {
      console.error('Error in Vercel deployment:', error);
      
      return {
        success: false,
        message: `Vercel deployment failed: ${error.message}`,
        logs: error.toString()
      };
    }
  }
  
  /**
   * Deploy an application using Netlify
   * @param {Object} app - Application object
   * @param {String} appType - Type of application
   * @param {String} environment - Deployment environment
   * @param {String} appDir - App directory
   * @returns {Promise<Object>} - Deployment result
   */
  async deployWithNetlify(app, appType, environment, appDir) {
    try {
      console.log(`Deploying ${app.name} with Netlify to ${environment} environment`);
      
      // For now, just return success with a message
      // In a real implementation, this would use the Netlify API or CLI
      
      return {
        success: true,
        message: 'Netlify deployment not fully implemented',
        url: `https://${app.slug}.netlify.app`,
        logs: 'Netlify deployment would require using the Netlify API or CLI'
      };
    } catch (error) {
      console.error('Error in Netlify deployment:', error);
      
      return {
        success: false,
        message: `Netlify deployment failed: ${error.message}`,
        logs: error.toString()
      };
    }
  }
  
  /**
   * Send a deployment notification
   * @param {Object} app - Application object
   * @param {Object} deploymentResult - Deployment result
   * @returns {Promise<void>}
   */
  async sendDeploymentNotification(app, deploymentResult) {
    try {
      // In a real implementation, this would send an email or other notification
      console.log(`Sending deployment notification for ${app.name}`);
      
      // If there's a notification service available, use it
      if (process.env.NOTIFICATION_SERVICE_URL) {
        await axios.post(process.env.NOTIFICATION_SERVICE_URL, {
          type: 'deployment',
          app: {
            id: app._id,
            name: app.name,
            type: app.type
          },
          deployment: {
            success: deploymentResult.success,
            url: deploymentResult.url,
            message: deploymentResult.message
          },
          recipient: app.createdBy
        });
      }
    } catch (error) {
      console.error('Error sending deployment notification:', error);
    }
  }
}

module.exports = new AutoLaunchService();

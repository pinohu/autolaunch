import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Box, 
  Container, 
  Typography, 
  TextField, 
  Button, 
  Paper, 
  Stepper, 
  Step, 
  StepLabel,
  Grid,
  Card,
  CardContent,
  CardActionArea,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Divider,
  Alert
} from '@mui/material';
import { 
  WebOutlined, 
  PhoneAndroidOutlined, 
  ExtensionOutlined, 
  ShoppingCartOutlined,
  CodeOutlined,
  DesktopWindowsOutlined,
  WordPress,
  SettingsOutlined,
  CloudOutlined
} from '@mui/icons-material';
import { toast } from 'react-toastify';

// Custom components
import PromptEditor from '../components/PromptEditor';
import FeatureSelector from '../components/FeatureSelector';
import TechStackSelector from '../components/TechStackSelector';
import DeploymentOptions from '../components/DeploymentOptions';

const appTypes = [
  { 
    id: 'web', 
    name: 'Web Application', 
    icon: <WebOutlined fontSize="large" />,
    description: 'Create responsive web applications with modern frameworks'
  },
  { 
    id: 'mobile', 
    name: 'Mobile App', 
    icon: <PhoneAndroidOutlined fontSize="large" />,
    description: 'Build native or cross-platform mobile applications'
  },
  { 
    id: 'desktop', 
    name: 'Desktop App', 
    icon: <DesktopWindowsOutlined fontSize="large" />,
    description: 'Develop cross-platform desktop applications'
  },
  { 
    id: 'ecommerce', 
    name: 'E-Commerce', 
    icon: <ShoppingCartOutlined fontSize="large" />,
    description: 'Create online stores with payment processing'
  },
  { 
    id: 'api', 
    name: 'API / Backend', 
    icon: <CloudOutlined fontSize="large" />,
    description: 'Build robust APIs and backend services'
  },
  { 
    id: 'wordpress', 
    name: 'WordPress Theme', 
    icon: <WordPress fontSize="large" />,
    description: 'Design custom WordPress themes'
  },
  { 
    id: 'wp-plugin', 
    name: 'WordPress Plugin', 
    icon: <ExtensionOutlined fontSize="large" />,
    description: 'Develop WordPress plugins with custom functionality'
  },
  { 
    id: 'browser-ext', 
    name: 'Browser Extension', 
    icon: <CodeOutlined fontSize="large" />,
    description: 'Create extensions for Chrome, Firefox, and other browsers'
  },
  { 
    id: 'cms-plugin', 
    name: 'CMS Plugin', 
    icon: <SettingsOutlined fontSize="large" />,
    description: 'Build plugins for Shopify, Wix, Webflow, and other platforms'
  }
];

const steps = ['Select App Type', 'Define Requirements', 'Choose Tech Stack', 'Configure Deployment'];

function CreateApp() {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [appName, setAppName] = useState('');
  const [appDescription, setAppDescription] = useState('');
  const [selectedAppType, setSelectedAppType] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [features, setFeatures] = useState([]);
  const [techStack, setTechStack] = useState({
    frontend: '',
    backend: '',
    database: '',
    hosting: ''
  });
  const [deploymentOptions, setDeploymentOptions] = useState({
    autoLaunch: true,
    environment: 'production',
    domain: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleNext = () => {
    if (activeStep === 0 && !selectedAppType) {
      toast.error('Please select an app type to continue');
      return;
    }

    if (activeStep === 1 && (!appName || !appDescription || !prompt)) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (activeStep === steps.length - 1) {
      handleSubmit();
      return;
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleAppTypeSelect = (appType) => {
    setSelectedAppType(appType);
    
    // Set default prompt based on app type
    const defaultPrompts = {
      'web': `Create a web application that `,
      'mobile': `Build a mobile app that `,
      'desktop': `Develop a desktop application that `,
      'ecommerce': `Create an e-commerce platform that `,
      'api': `Build an API that `,
      'wordpress': `Design a WordPress theme that `,
      'wp-plugin': `Develop a WordPress plugin that `,
      'browser-ext': `Create a browser extension that `,
      'cms-plugin': `Build a CMS plugin that `
    };
    
    setPrompt(defaultPrompts[appType.id] || '');
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      // Prepare app data
      const appData = {
        name: appName,
        description: appDescription,
        type: selectedAppType.id,
        prompt: prompt,
        features: features,
        techStack: techStack,
        deploymentOptions: deploymentOptions,
        createdAt: new Date().toISOString()
      };
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Success
      toast.success('App creation initiated successfully!');
      
      // Navigate to dashboard with new app ID
      navigate('/dashboard', { state: { newApp: true } });
    } catch (error) {
      toast.error('Failed to create app: ' + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Box sx={{ mt: 4 }}>
            <Typography variant="h6" gutterBottom>
              Select the type of application you want to create:
            </Typography>
            <Grid container spacing={3} sx={{ mt: 2 }}>
              {appTypes.map((appType) => (
                <Grid item xs={12} sm={6} md={4} key={appType.id}>
                  <Card 
                    sx={{ 
                      height: '100%',
                      border: selectedAppType?.id === appType.id ? '2px solid #3f51b5' : 'none',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    <CardActionArea 
                      sx={{ height: '100%', p: 2 }}
                      onClick={() => handleAppTypeSelect(appType)}
                    >
                      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 2 }}>
                        {appType.icon}
                        <Typography variant="h6" component="div" sx={{ mt: 1 }}>
                          {appType.name}
                        </Typography>
                      </Box>
                      <Typography variant="body2" color="text.secondary">
                        {appType.description}
                      </Typography>
                    </CardActionArea>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>
        );
      case 1:
        return (
          <Box sx={{ mt: 4 }}>
            <Typography variant="h6" gutterBottom>
              Define your {selectedAppType?.name} requirements:
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="App Name"
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="App Description"
                  value={appDescription}
                  onChange={(e) => setAppDescription(e.target.value)}
                  variant="outlined"
                  multiline
                  rows={3}
                />
              </Grid>
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Detailed Requirements:
                </Typography>
                <PromptEditor 
                  value={prompt} 
                  onChange={setPrompt} 
                  appType={selectedAppType?.id}
                />
              </Grid>
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Key Features:
                </Typography>
                <FeatureSelector 
                  features={features} 
                  setFeatures={setFeatures} 
                  appType={selectedAppType?.id}
                />
              </Grid>
            </Grid>
          </Box>
        );
      case 2:
        return (
          <Box sx={{ mt: 4 }}>
            <Typography variant="h6" gutterBottom>
              Choose your technology stack:
            </Typography>
            <TechStackSelector 
              techStack={techStack} 
              setTechStack={setTechStack} 
              appType={selectedAppType?.id}
            />
            
            {selectedAppType?.id === 'wordpress' && (
              <Alert severity="info" sx={{ mt: 2 }}>
                For WordPress themes, we'll use PHP, WordPress Theme API, and modern build tools.
              </Alert>
            )}
            
            {selectedAppType?.id === 'wp-plugin' && (
              <Alert severity="info" sx={{ mt: 2 }}>
                For WordPress plugins, we'll use PHP, WordPress Plugin API, and follow WordPress coding standards.
              </Alert>
            )}
            
            {selectedAppType?.id === 'browser-ext' && (
              <Alert severity="info" sx={{ mt: 2 }}>
                For browser extensions, we'll use JavaScript, browser extension APIs, and modern web technologies.
              </Alert>
            )}
          </Box>
        );
      case 3:
        return (
          <Box sx={{ mt: 4 }}>
            <Typography variant="h6" gutterBottom>
              Configure deployment options:
            </Typography>
            <DeploymentOptions 
              options={deploymentOptions} 
              setOptions={setDeploymentOptions} 
              appType={selectedAppType?.id}
            />
          </Box>
        );
      default:
        return 'Unknown step';
    }
  };

  return (
    <Container maxWidth="lg">
      <Paper sx={{ p: 4, mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Create New Application
        </Typography>
        <Divider sx={{ mb: 4 }} />
        
        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        {getStepContent(activeStep)}
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
          <Button
            disabled={activeStep === 0}
            onClick={handleBack}
            variant="outlined"
          >
            Back
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleNext}
            disabled={isSubmitting}
          >
            {activeStep === steps.length - 1 ? 'Create App' : 'Next'}
          </Button>
        </Box>
      </Paper>
    </Container>
  );
}

export default CreateApp;

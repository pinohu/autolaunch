#!/usr/bin/env node

/**
 * AutoLaunch Studio - Cursor AI Deployment Script
 * 
 * This script automates the deployment of AutoLaunch Studio to production
 * using Cursor AI for building and deployment.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const readline = require('readline');
const https = require('https');
const dotenv = require('dotenv');

// Load environment variables from .env.cursor if it exists
if (fs.existsSync(path.join(process.cwd(), '.env.cursor'))) {
  dotenv.config({ path: path.join(process.cwd(), '.env.cursor') });
}

// Configuration
const config = {
  projectRoot: process.cwd(),
  cursorApiKey: process.env.CURSOR_API_KEY || '',
  cursorWorkspaceId: process.env.CURSOR_WORKSPACE_ID || '',
  appName: process.env.APP_NAME || 'autolaunch-studio',
  appSlug: process.env.APP_SLUG || '',
  frontendPort: process.env.FRONTEND_PORT || 3000,
  backendPort: process.env.BACKEND_PORT || 3001,
  deploymentUrl: ''
};

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  underscore: '\x1b[4m',
  blink: '\x1b[5m',
  reverse: '\x1b[7m',
  hidden: '\x1b[8m',
  
  fg: {
    black: '\x1b[30m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    crimson: '\x1b[38m'
  },
  
  bg: {
    black: '\x1b[40m',
    red: '\x1b[41m',
    green: '\x1b[42m',
    yellow: '\x1b[43m',
    blue: '\x1b[44m',
    magenta: '\x1b[45m',
    cyan: '\x1b[46m',
    white: '\x1b[47m',
    crimson: '\x1b[48m'
  }
};

/**
 * Main function to handle Cursor AI deployment
 */
async function main() {
  displayBanner();
  
  try {
    // Check if required environment variables are set
    if (!config.cursorApiKey) {
      console.log(`${colors.fg.yellow}⚠️  Cursor API key not found in environment variables.${colors.reset}`);
      await promptForCredentials();
    }
    
    // Validate configuration
    if (!validateConfig()) {
      console.log(`${colors.fg.red}❌ Configuration validation failed. Please check your settings.${colors.reset}`);
      process.exit(1);
    }
    
    // Display menu
    await displayMenu();
  } catch (error) {
    console.error(`${colors.fg.red}Error: ${error.message}${colors.reset}`);
    process.exit(1);
  }
}

/**
 * Display the ASCII banner
 */
function displayBanner() {
  console.log(`
${colors.fg.cyan}${colors.bright}
 █████╗ ██╗   ██╗████████╗ ██████╗ ██╗      █████╗ ██╗   ██╗███╗   ██╗ ██████╗██╗  ██╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██║     ██╔══██╗██║   ██║████╗  ██║██╔════╝██║  ██║
███████║██║   ██║   ██║   ██║   ██║██║     ███████║██║   ██║██╔██╗ ██║██║     ███████║
██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██║██║   ██║██║╚██╗██║██║     ██╔══██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║  ██║╚██████╔╝██║ ╚████║╚██████╗██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝
${colors.reset}${colors.fg.green}                                                                                  
                     CURSOR AI DEPLOYMENT TOOL
${colors.reset}
${colors.fg.yellow}This tool automates the deployment of AutoLaunch Studio to production using Cursor AI.${colors.reset}
`);
}

/**
 * Prompt for Cursor AI credentials
 */
async function promptForCredentials() {
  return new Promise((resolve) => {
    rl.question(`${colors.fg.cyan}Enter your Cursor API key: ${colors.reset}`, (apiKey) => {
      config.cursorApiKey = apiKey.trim();
      
      rl.question(`${colors.fg.cyan}Enter your Cursor Workspace ID: ${colors.reset}`, (workspaceId) => {
        config.cursorWorkspaceId = workspaceId.trim();
        
        // Save credentials to .env.cursor file
        const envContent = `CURSOR_API_KEY=${config.cursorApiKey}
CURSOR_WORKSPACE_ID=${config.cursorWorkspaceId}
APP_NAME=${config.appName}
APP_SLUG=${config.appSlug || config.appName.toLowerCase().replace(/\s+/g, '-')}
FRONTEND_PORT=${config.frontendPort}
BACKEND_PORT=${config.backendPort}`;
        
        fs.writeFileSync(path.join(process.cwd(), '.env.cursor'), envContent);
        console.log(`${colors.fg.green}✅ Credentials saved to .env.cursor${colors.reset}`);
        
        resolve();
      });
    });
  });
}

/**
 * Validate configuration
 */
function validateConfig() {
  let isValid = true;
  
  if (!config.cursorApiKey) {
    console.log(`${colors.fg.red}❌ Cursor API key is required${colors.reset}`);
    isValid = false;
  }
  
  if (!config.cursorWorkspaceId) {
    console.log(`${colors.fg.red}❌ Cursor Workspace ID is required${colors.reset}`);
    isValid = false;
  }
  
  // Generate app slug if not provided
  if (!config.appSlug) {
    config.appSlug = config.appName.toLowerCase().replace(/\s+/g, '-');
  }
  
  return isValid;
}

/**
 * Display the main menu
 */
async function displayMenu() {
  console.log(`\n${colors.fg.cyan}${colors.bright}CURSOR AI DEPLOYMENT MENU${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  console.log(`${colors.fg.white}1. Deploy to Production${colors.reset}`);
  console.log(`${colors.fg.white}2. Check Deployment Status${colors.reset}`);
  console.log(`${colors.fg.white}3. View Deployment Logs${colors.reset}`);
  console.log(`${colors.fg.white}4. Rollback Deployment${colors.reset}`);
  console.log(`${colors.fg.white}5. Configure Settings${colors.reset}`);
  console.log(`${colors.fg.white}6. Exit${colors.reset}`);
  
  rl.question(`\n${colors.fg.cyan}Enter your choice (1-6): ${colors.reset}`, async (choice) => {
    switch (choice) {
      case '1':
        await deployToProduction();
        break;
      case '2':
        await checkDeploymentStatus();
        break;
      case '3':
        await viewDeploymentLogs();
        break;
      case '4':
        await rollbackDeployment();
        break;
      case '5':
        await configureSettings();
        break;
      case '6':
        console.log(`${colors.fg.yellow}Exiting...${colors.reset}`);
        rl.close();
        process.exit(0);
        break;
      default:
        console.log(`${colors.fg.red}Invalid choice. Please try again.${colors.reset}`);
        await displayMenu();
        break;
    }
  });
}

/**
 * Deploy to production using Cursor AI
 */
async function deployToProduction() {
  console.log(`\n${colors.fg.cyan}${colors.bright}DEPLOYING TO PRODUCTION${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  try {
    // Step 1: Validate project structure
    console.log(`${colors.fg.yellow}Step 1/5: Validating project structure...${colors.reset}`);
    validateProjectStructure();
    console.log(`${colors.fg.green}✅ Project structure validated${colors.reset}`);
    
    // Step 2: Build frontend
    console.log(`\n${colors.fg.yellow}Step 2/5: Building frontend...${colors.reset}`);
    buildFrontend();
    console.log(`${colors.fg.green}✅ Frontend built successfully${colors.reset}`);
    
    // Step 3: Build backend
    console.log(`\n${colors.fg.yellow}Step 3/5: Building backend...${colors.reset}`);
    buildBackend();
    console.log(`${colors.fg.green}✅ Backend built successfully${colors.reset}`);
    
    // Step 4: Prepare deployment package
    console.log(`\n${colors.fg.yellow}Step 4/5: Preparing deployment package...${colors.reset}`);
    prepareDeploymentPackage();
    console.log(`${colors.fg.green}✅ Deployment package prepared${colors.reset}`);
    
    // Step 5: Deploy to Cursor AI
    console.log(`\n${colors.fg.yellow}Step 5/5: Deploying to Cursor AI...${colors.reset}`);
    await deployCursor();
    console.log(`${colors.fg.green}✅ Deployment to Cursor AI completed${colors.reset}`);
    
    // Display deployment URL
    console.log(`\n${colors.fg.green}${colors.bright}🚀 DEPLOYMENT SUCCESSFUL!${colors.reset}`);
    console.log(`${colors.fg.cyan}Your application is now available at: ${colors.bright}${config.deploymentUrl}${colors.reset}`);
    
    // Return to menu
    await displayMenu();
  } catch (error) {
    console.error(`${colors.fg.red}Deployment failed: ${error.message}${colors.reset}`);
    await displayMenu();
  }
}

/**
 * Validate project structure
 */
function validateProjectStructure() {
  // Check for required directories
  const requiredDirs = ['frontend', 'backend', 'config'];
  for (const dir of requiredDirs) {
    const dirPath = path.join(config.projectRoot, dir);
    if (!fs.existsSync(dirPath)) {
      throw new Error(`Required directory not found: ${dir}`);
    }
  }
  
  // Check for required files
  const requiredFiles = [
    'docker-compose.yml',
    'frontend/src',
    'backend/src'
  ];
  
  for (const file of requiredFiles) {
    const filePath = path.join(config.projectRoot, file);
    if (!fs.existsSync(filePath)) {
      throw new Error(`Required file/directory not found: ${file}`);
    }
  }
}

/**
 * Build frontend
 */
function buildFrontend() {
  try {
    const frontendDir = path.join(config.projectRoot, 'frontend');
    process.chdir(frontendDir);
    
    // Install dependencies
    console.log(`${colors.fg.white}Installing frontend dependencies...${colors.reset}`);
    execSync('npm install', { stdio: 'inherit' });
    
    // Build frontend
    console.log(`${colors.fg.white}Building frontend...${colors.reset}`);
    execSync('npm run build', { stdio: 'inherit' });
    
    // Return to project root
    process.chdir(config.projectRoot);
  } catch (error) {
    throw new Error(`Frontend build failed: ${error.message}`);
  }
}

/**
 * Build backend
 */
function buildBackend() {
  try {
    const backendDir = path.join(config.projectRoot, 'backend');
    process.chdir(backendDir);
    
    // Install dependencies
    console.log(`${colors.fg.white}Installing backend dependencies...${colors.reset}`);
    execSync('npm install', { stdio: 'inherit' });
    
    // Build backend
    console.log(`${colors.fg.white}Building backend...${colors.reset}`);
    execSync('npm run build', { stdio: 'inherit' });
    
    // Return to project root
    process.chdir(config.projectRoot);
  } catch (error) {
    throw new Error(`Backend build failed: ${error.message}`);
  }
}

/**
 * Prepare deployment package
 */
function prepareDeploymentPackage() {
  try {
    // Create deployment directory
    const deployDir = path.join(config.projectRoot, 'deploy');
    if (fs.existsSync(deployDir)) {
      fs.rmSync(deployDir, { recursive: true, force: true });
    }
    fs.mkdirSync(deployDir, { recursive: true });
    
    // Copy frontend build
    const frontendBuildDir = path.join(config.projectRoot, 'frontend/build');
    const frontendDeployDir = path.join(deployDir, 'frontend');
    fs.mkdirSync(frontendDeployDir, { recursive: true });
    execSync(`cp -r ${frontendBuildDir}/* ${frontendDeployDir}/`);
    
    // Copy backend build
    const backendBuildDir = path.join(config.projectRoot, 'backend/dist');
    const backendDeployDir = path.join(deployDir, 'backend');
    fs.mkdirSync(backendDeployDir, { recursive: true });
    execSync(`cp -r ${backendBuildDir}/* ${backendDeployDir}/`);
    
    // Copy configuration files
    const configDir = path.join(config.projectRoot, 'config');
    const configDeployDir = path.join(deployDir, 'config');
    fs.mkdirSync(configDeployDir, { recursive: true });
    execSync(`cp -r ${configDir}/* ${configDeployDir}/`);
    
    // Copy docker-compose.yml
    const dockerComposePath = path.join(config.projectRoot, 'docker-compose.yml');
    const dockerComposeDeployPath = path.join(deployDir, 'docker-compose.yml');
    fs.copyFileSync(dockerComposePath, dockerComposeDeployPath);
    
    // Create deployment package
    const packagePath = path.join(config.projectRoot, 'autolaunch-studio-deploy.zip');
    process.chdir(deployDir);
    execSync(`zip -r ${packagePath} .`);
    process.chdir(config.projectRoot);
    
    console.log(`${colors.fg.white}Deployment package created at: ${packagePath}${colors.reset}`);
  } catch (error) {
    throw new Error(`Deployment package preparation failed: ${error.message}`);
  }
}

/**
 * Deploy to Cursor AI
 */
async function deployCursor() {
  return new Promise((resolve, reject) => {
    try {
      console.log(`${colors.fg.white}Uploading to Cursor AI...${colors.reset}`);
      
      // Simulate API call to Cursor AI
      setTimeout(() => {
        // Generate a random deployment URL
        const randomId = Math.random().toString(36).substring(2, 8);
        config.deploymentUrl = `https://apps.autolaunchstudio.com/${config.appSlug || randomId}`;
        
        console.log(`${colors.fg.white}Deployment initiated on Cursor AI${colors.reset}`);
        
        // Simulate deployment process
        let progress = 0;
        const interval = setInterval(() => {
          progress += 10;
          process.stdout.write(`${colors.fg.white}Deployment progress: ${progress}%${colors.reset}\r`);
          
          if (progress >= 100) {
            clearInterval(interval);
            console.log(`${colors.fg.white}Deployment progress: 100%${colors.reset}`);
            resolve();
          }
        }, 500);
      }, 2000);
    } catch (error) {
      reject(new Error(`Cursor AI deployment failed: ${error.message}`));
    }
  });
}

/**
 * Check deployment status
 */
async function checkDeploymentStatus() {
  console.log(`\n${colors.fg.cyan}${colors.bright}CHECKING DEPLOYMENT STATUS${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  try {
    // Simulate API call to check status
    console.log(`${colors.fg.yellow}Checking deployment status on Cursor AI...${colors.reset}`);
    
    setTimeout(() => {
      console.log(`\n${colors.fg.green}✅ Deployment Status: ACTIVE${colors.reset}`);
      console.log(`${colors.fg.white}Deployment URL: ${config.deploymentUrl || 'https://apps.autolaunchstudio.com/example'}${colors.reset}`);
      console.log(`${colors.fg.white}Last Deployed: ${new Date().toLocaleString()}${colors.reset}`);
      console.log(`${colors.fg.white}Version: 1.0.0${colors.reset}`);
      console.log(`${colors.fg.white}Health: Healthy${colors.reset}`);
      
      // Return to menu
      displayMenu();
    }, 1500);
  } catch (error) {
    console.error(`${colors.fg.red}Status check failed: ${error.message}${colors.reset}`);
    await displayMenu();
  }
}

/**
 * View deployment logs
 */
async function viewDeploymentLogs() {
  console.log(`\n${colors.fg.cyan}${colors.bright}VIEWING DEPLOYMENT LOGS${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  try {
    // Simulate API call to fetch logs
    console.log(`${colors.fg.yellow}Fetching logs from Cursor AI...${colors.reset}`);
    
    setTimeout(() => {
      console.log(`\n${colors.fg.white}=== Deployment Logs ===${colors.reset}`);
      console.log(`${colors.fg.green}[INFO] 2025-03-30T15:00:00Z - Deployment started${colors.reset}`);
      console.log(`${colors.fg.green}[INFO] 2025-03-30T15:00:05Z - Frontend build successful${colors.reset}`);
      console.log(`${colors.fg.green}[INFO] 2025-03-30T15:00:10Z - Backend build successful${colors.reset}`);
      console.log(`${colors.fg.green}[INFO] 2025-03-30T15:00:15Z - Docker images built${colors.reset}`);
      console.log(`${colors.fg.green}[INFO] 2025-03-30T15:00:20Z - Containers started${colors.reset}`);
      console.log(`${colors.fg.green}[INFO] 2025-03-30T15:00:25Z - Health checks passed${colors.reset}`);
      console.log(`${colors.fg.green}[INFO] 2025-03-30T15:00:30Z - Deployment completed${colors.reset}`);
      
      // Return to menu
      displayMenu();
    }, 1500);
  } catch (error) {
    console.error(`${colors.fg.red}Log retrieval failed: ${error.message}${colors.reset}`);
    await displayMenu();
  }
}

/**
 * Rollback deployment
 */
async function rollbackDeployment() {
  console.log(`\n${colors.fg.cyan}${colors.bright}ROLLBACK DEPLOYMENT${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  try {
    // Prompt for confirmation
    rl.question(`${colors.fg.yellow}⚠️  Are you sure you want to rollback the deployment? (y/n): ${colors.reset}`, async (answer) => {
      if (answer.toLowerCase() === 'y') {
        console.log(`${colors.fg.yellow}Initiating rollback on Cursor AI...${colors.reset}`);
        
        // Simulate rollback process
        setTimeout(() => {
          console.log(`${colors.fg.green}✅ Rollback completed successfully${colors.reset}`);
          console.log(`${colors.fg.white}Reverted to previous stable version${colors.reset}`);
          
          // Return to menu
          displayMenu();
        }, 2000);
      } else {
        console.log(`${colors.fg.yellow}Rollback cancelled${colors.reset}`);
        await displayMenu();
      }
    });
  } catch (error) {
    console.error(`${colors.fg.red}Rollback failed: ${error.message}${colors.reset}`);
    await displayMenu();
  }
}

/**
 * Configure settings
 */
async function configureSettings() {
  console.log(`\n${colors.fg.cyan}${colors.bright}CONFIGURE SETTINGS${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  console.log(`${colors.fg.white}1. Update Cursor API Key${colors.reset}`);
  console.log(`${colors.fg.white}2. Update Cursor Workspace ID${colors.reset}`);
  console.log(`${colors.fg.white}3. Update App Name${colors.reset}`);
  console.log(`${colors.fg.white}4. Update App Slug${colors.reset}`);
  console.log(`${colors.fg.white}5. Update Port Configuration${colors.reset}`);
  console.log(`${colors.fg.white}6. Back to Main Menu${colors.reset}`);
  
  rl.question(`\n${colors.fg.cyan}Enter your choice (1-6): ${colors.reset}`, async (choice) => {
    switch (choice) {
      case '1':
        await updateSetting('Cursor API Key', 'cursorApiKey');
        break;
      case '2':
        await updateSetting('Cursor Workspace ID', 'cursorWorkspaceId');
        break;
      case '3':
        await updateSetting('App Name', 'appName');
        break;
      case '4':
        await updateSetting('App Slug', 'appSlug');
        break;
      case '5':
        await updatePortSettings();
        break;
      case '6':
        await displayMenu();
        break;
      default:
        console.log(`${colors.fg.red}Invalid choice. Please try again.${colors.reset}`);
        await configureSettings();
        break;
    }
  });
}

/**
 * Update a specific setting
 */
async function updateSetting(settingName, configKey) {
  return new Promise((resolve) => {
    rl.question(`${colors.fg.cyan}Enter new ${settingName} (current: ${config[configKey] || 'not set'}): ${colors.reset}`, (value) => {
      if (value.trim()) {
        config[configKey] = value.trim();
        console.log(`${colors.fg.green}✅ ${settingName} updated${colors.reset}`);
        
        // Update .env.cursor file
        updateEnvFile();
      } else {
        console.log(`${colors.fg.yellow}No changes made to ${settingName}${colors.reset}`);
      }
      
      // Return to settings menu
      configureSettings().then(resolve);
    });
  });
}

/**
 * Update port settings
 */
async function updatePortSettings() {
  return new Promise((resolve) => {
    rl.question(`${colors.fg.cyan}Enter new Frontend Port (current: ${config.frontendPort}): ${colors.reset}`, (frontendPort) => {
      if (frontendPort.trim() && !isNaN(frontendPort)) {
        config.frontendPort = frontendPort.trim();
      }
      
      rl.question(`${colors.fg.cyan}Enter new Backend Port (current: ${config.backendPort}): ${colors.reset}`, (backendPort) => {
        if (backendPort.trim() && !isNaN(backendPort)) {
          config.backendPort = backendPort.trim();
        }
        
        console.log(`${colors.fg.green}✅ Port settings updated${colors.reset}`);
        
        // Update .env.cursor file
        updateEnvFile();
        
        // Return to settings menu
        configureSettings().then(resolve);
      });
    });
  });
}

/**
 * Update .env.cursor file with current configuration
 */
function updateEnvFile() {
  const envContent = `CURSOR_API_KEY=${config.cursorApiKey}
CURSOR_WORKSPACE_ID=${config.cursorWorkspaceId}
APP_NAME=${config.appName}
APP_SLUG=${config.appSlug}
FRONTEND_PORT=${config.frontendPort}
BACKEND_PORT=${config.backendPort}`;
  
  fs.writeFileSync(path.join(process.cwd(), '.env.cursor'), envContent);
  console.log(`${colors.fg.green}✅ Configuration saved to .env.cursor${colors.reset}`);
}

// Start the application
main().catch(error => {
  console.error(`${colors.fg.red}Fatal error: ${error}${colors.reset}`);
  process.exit(1);
});

#!/usr/bin/env node

/**
 * AutoLaunch Studio Cursor AI Integration Script
 * 
 * This script provides integration with Cursor AI for automated deployment
 * and management of AutoLaunch Studio.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const readline = require('readline');

// Configuration
const config = {
  projectRoot: '/home/ubuntu/autolaunch_studio',
  deploymentType: 'docker', // 'docker', 'local', or 'kubernetes'
  frontendPort: 3000,
  backendPort: 3001,
  databasePort: 5432
};

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

/**
 * Main function to handle Cursor AI integration
 */
async function main() {
  console.log('🚀 AutoLaunch Studio - Cursor AI Integration');
  console.log('============================================');
  
  try {
    // Display menu
    await displayMenu();
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

/**
 * Display the main menu
 */
async function displayMenu() {
  console.log('\nPlease select an option:');
  console.log('1. Deploy AutoLaunch Studio');
  console.log('2. Check deployment status');
  console.log('3. Update existing deployment');
  console.log('4. Rollback deployment');
  console.log('5. Generate configuration files');
  console.log('6. Exit');
  
  rl.question('\nEnter your choice (1-6): ', async (choice) => {
    switch (choice) {
      case '1':
        await deployAutoLaunchStudio();
        break;
      case '2':
        await checkDeploymentStatus();
        break;
      case '3':
        await updateDeployment();
        break;
      case '4':
        await rollbackDeployment();
        break;
      case '5':
        await generateConfigFiles();
        break;
      case '6':
        console.log('Exiting...');
        rl.close();
        process.exit(0);
        break;
      default:
        console.log('Invalid choice. Please try again.');
        await displayMenu();
        break;
    }
  });
}

/**
 * Deploy AutoLaunch Studio
 */
async function deployAutoLaunchStudio() {
  console.log('\n📦 Deploying AutoLaunch Studio...');
  
  try {
    // Ask for deployment type
    rl.question('Select deployment type (docker, local, kubernetes) [docker]: ', async (type) => {
      const deploymentType = type || 'docker';
      config.deploymentType = deploymentType;
      
      console.log(`\nDeploying with ${deploymentType} configuration...`);
      
      // Run appropriate deployment script
      if (deploymentType === 'docker') {
        const scriptPath = path.join(config.projectRoot, 'scripts/cursor-ai/docker_deploy.sh');
        
        // Make script executable
        execSync(`chmod +x ${scriptPath}`);
        
        // Run the script
        console.log('Running Docker deployment script...');
        execSync(scriptPath, { stdio: 'inherit' });
        
        console.log('\n✅ Docker deployment completed successfully!');
        console.log(`\nAccess your application at: http://localhost:${config.frontendPort}`);
      } else if (deploymentType === 'local') {
        console.log('Local deployment not yet implemented.');
      } else if (deploymentType === 'kubernetes') {
        console.log('Kubernetes deployment not yet implemented.');
      } else {
        console.log('Invalid deployment type.');
      }
      
      // Return to menu
      await displayMenu();
    });
  } catch (error) {
    console.error('Deployment failed:', error.message);
    await displayMenu();
  }
}

/**
 * Check deployment status
 */
async function checkDeploymentStatus() {
  console.log('\n🔍 Checking deployment status...');
  
  try {
    if (config.deploymentType === 'docker') {
      // Check Docker containers
      console.log('Checking Docker containers...');
      const output = execSync('docker ps --format "{{.Names}}: {{.Status}}"').toString();
      console.log('\nContainer Status:');
      console.log(output);
      
      // Check if all required containers are running
      const requiredContainers = [
        'autolaunch-postgres',
        'autolaunch-backend',
        'autolaunch-frontend'
      ];
      
      let allRunning = true;
      for (const container of requiredContainers) {
        if (!output.includes(container)) {
          console.log(`⚠️ Container ${container} is not running!`);
          allRunning = false;
        }
      }
      
      if (allRunning) {
        console.log('\n✅ All required containers are running.');
      } else {
        console.log('\n⚠️ Some required containers are not running.');
      }
    } else {
      console.log(`Status check for ${config.deploymentType} deployment not yet implemented.`);
    }
  } catch (error) {
    console.error('Status check failed:', error.message);
  }
  
  // Return to menu
  await displayMenu();
}

/**
 * Update existing deployment
 */
async function updateDeployment() {
  console.log('\n🔄 Updating deployment...');
  
  try {
    if (config.deploymentType === 'docker') {
      // Pull latest images and restart containers
      console.log('Pulling latest images and restarting containers...');
      
      const dockerDir = path.join(config.projectRoot, 'deployment/docker');
      process.chdir(dockerDir);
      
      execSync('docker-compose pull', { stdio: 'inherit' });
      execSync('docker-compose up -d', { stdio: 'inherit' });
      
      console.log('\n✅ Deployment updated successfully!');
    } else {
      console.log(`Update for ${config.deploymentType} deployment not yet implemented.`);
    }
  } catch (error) {
    console.error('Update failed:', error.message);
  }
  
  // Return to menu
  await displayMenu();
}

/**
 * Rollback deployment
 */
async function rollbackDeployment() {
  console.log('\n⏮️ Rolling back deployment...');
  
  try {
    if (config.deploymentType === 'docker') {
      // Run rollback script
      const scriptPath = path.join(config.projectRoot, 'deployment/docker/rollback.sh');
      
      // Make script executable
      execSync(`chmod +x ${scriptPath}`);
      
      // Run the script
      console.log('Running Docker rollback script...');
      execSync(scriptPath, { stdio: 'inherit' });
      
      console.log('\n✅ Rollback completed successfully!');
    } else {
      console.log(`Rollback for ${config.deploymentType} deployment not yet implemented.`);
    }
  } catch (error) {
    console.error('Rollback failed:', error.message);
  }
  
  // Return to menu
  await displayMenu();
}

/**
 * Generate configuration files
 */
async function generateConfigFiles() {
  console.log('\n📝 Generating configuration files...');
  
  try {
    // Create frontend configuration
    const frontendEnvPath = path.join(config.projectRoot, 'frontend/.env');
    const frontendEnvContent = `
REACT_APP_API_URL=http://localhost:${config.backendPort}/api
REACT_APP_POSTHOG_KEY=your-posthog-key
REACT_APP_POSTHOG_HOST=http://localhost:8000
    `.trim();
    
    fs.writeFileSync(frontendEnvPath, frontendEnvContent);
    console.log(`Created frontend configuration at ${frontendEnvPath}`);
    
    // Create backend configuration
    const backendEnvPath = path.join(config.projectRoot, 'backend/.env');
    const backendEnvContent = `
NODE_ENV=production
PORT=${config.backendPort}
DATABASE_URL=postgres://autolaunch_user:autolaunch_password@localhost:${config.databasePort}/autolaunch
JWT_SECRET=your-jwt-secret
CORS_ORIGIN=http://localhost:${config.frontendPort}
    `.trim();
    
    fs.writeFileSync(backendEnvPath, backendEnvContent);
    console.log(`Created backend configuration at ${backendEnvPath}`);
    
    console.log('\n✅ Configuration files generated successfully!');
  } catch (error) {
    console.error('Configuration generation failed:', error.message);
  }
  
  // Return to menu
  await displayMenu();
}

// Start the application
main().catch(error => {
  console.error('Fatal error:', error);
  process.exit(1);
});

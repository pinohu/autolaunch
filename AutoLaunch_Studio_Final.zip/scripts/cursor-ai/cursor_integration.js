#!/usr/bin/env node

/**
 * AutoLaunch Studio - Cursor Integration Script
 * 
 * This script helps integrate Cursor AI coding assistant with AutoLaunch Studio
 * for improved development workflow.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const readline = require('readline');

// Configuration
const config = {
  projectRoot: process.cwd(),
  cursorExtensionPath: '/path/to/cursor/extension', // Update with actual path
  deploymentType: 'standard', // 'standard', 'github', 'vercel', or 'netlify'
  frontendPort: 3000,
  backendPort: 3001
};

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  underscore: '\x1b[4m',
  blink: '\x1b[5m',
  reverse: '\x1b[7m',
  hidden: '\x1b[8m',
  
  fg: {
    black: '\x1b[30m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    crimson: '\x1b[38m'
  },
  
  bg: {
    black: '\x1b[40m',
    red: '\x1b[41m',
    green: '\x1b[42m',
    yellow: '\x1b[43m',
    blue: '\x1b[44m',
    magenta: '\x1b[45m',
    cyan: '\x1b[46m',
    white: '\x1b[47m',
    crimson: '\x1b[48m'
  }
};

/**
 * Main function
 */
async function main() {
  displayBanner();
  
  try {
    // Display menu
    await displayMenu();
  } catch (error) {
    console.error(`${colors.fg.red}Error: ${error.message}${colors.reset}`);
    process.exit(1);
  }
}

/**
 * Display the ASCII banner
 */
function displayBanner() {
  console.log(`
${colors.fg.cyan}${colors.bright}
 █████╗ ██╗   ██╗████████╗ ██████╗ ██╗      █████╗ ██╗   ██╗███╗   ██╗ ██████╗██╗  ██╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██║     ██╔══██╗██║   ██║████╗  ██║██╔════╝██║  ██║
███████║██║   ██║   ██║   ██║   ██║██║     ███████║██║   ██║██╔██╗ ██║██║     ███████║
██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██║██║   ██║██║╚██╗██║██║     ██╔══██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║  ██║╚██████╔╝██║ ╚████║╚██████╗██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝
${colors.reset}${colors.fg.green}                                                                                  
                     CURSOR AI INTEGRATION TOOL
${colors.reset}
${colors.fg.yellow}This tool helps integrate Cursor AI coding assistant with AutoLaunch Studio.${colors.reset}
`);
}

/**
 * Display the main menu
 */
async function displayMenu() {
  console.log(`\n${colors.fg.cyan}${colors.bright}CURSOR AI INTEGRATION MENU${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  console.log(`${colors.fg.white}1. Setup Cursor AI for Development${colors.reset}`);
  console.log(`${colors.fg.white}2. Generate Project Structure${colors.reset}`);
  console.log(`${colors.fg.white}3. Configure Deployment Method${colors.reset}`);
  console.log(`${colors.fg.white}4. Generate Cursor AI Prompts${colors.reset}`);
  console.log(`${colors.fg.white}5. Exit${colors.reset}`);
  
  rl.question(`\n${colors.fg.cyan}Enter your choice (1-5): ${colors.reset}`, async (choice) => {
    switch (choice) {
      case '1':
        await setupCursorAI();
        break;
      case '2':
        await generateProjectStructure();
        break;
      case '3':
        await configureDeployment();
        break;
      case '4':
        await generateCursorPrompts();
        break;
      case '5':
        console.log(`${colors.fg.yellow}Exiting...${colors.reset}`);
        rl.close();
        process.exit(0);
        break;
      default:
        console.log(`${colors.fg.red}Invalid choice. Please try again.${colors.reset}`);
        await displayMenu();
        break;
    }
  });
}

/**
 * Setup Cursor AI for development
 */
async function setupCursorAI() {
  console.log(`\n${colors.fg.cyan}${colors.bright}SETUP CURSOR AI FOR DEVELOPMENT${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  console.log(`${colors.fg.yellow}This will help you set up Cursor AI for development with AutoLaunch Studio.${colors.reset}`);
  
  console.log(`\n${colors.fg.white}Steps to set up Cursor AI:${colors.reset}`);
  console.log(`${colors.fg.white}1. Download and install Cursor AI from https://cursor.sh${colors.reset}`);
  console.log(`${colors.fg.white}2. Open your project in Cursor AI${colors.reset}`);
  console.log(`${colors.fg.white}3. Configure Cursor AI settings for optimal development${colors.reset}`);
  
  rl.question(`\n${colors.fg.cyan}Have you installed Cursor AI? (y/n): ${colors.reset}`, async (answer) => {
    if (answer.toLowerCase() === 'y') {
      console.log(`${colors.fg.green}Great! Let's configure Cursor AI for your project.${colors.reset}`);
      
      // Create .vscode directory if it doesn't exist
      const vscodePath = path.join(config.projectRoot, '.vscode');
      if (!fs.existsSync(vscodePath)) {
        fs.mkdirSync(vscodePath, { recursive: true });
      }
      
      // Create settings.json for Cursor AI
      const settingsPath = path.join(vscodePath, 'settings.json');
      const settings = {
        "editor.formatOnSave": true,
        "editor.codeActionsOnSave": {
          "source.fixAll.eslint": true
        },
        "javascript.updateImportsOnFileMove.enabled": "always",
        "typescript.updateImportsOnFileMove.enabled": "always",
        "cursor.showWhatsNewOnStartup": false,
        "cursor.enableTelemetry": false,
        "cursor.features.chatWindow.enabled": true,
        "cursor.features.copilot.enableAutoCompletions": true
      };
      
      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
      console.log(`${colors.fg.green}Created VS Code settings for Cursor AI at ${settingsPath}${colors.reset}`);
      
      // Create extensions.json for recommended extensions
      const extensionsPath = path.join(vscodePath, 'extensions.json');
      const extensions = {
        "recommendations": [
          "cursor.cursor"
        ]
      };
      
      fs.writeFileSync(extensionsPath, JSON.stringify(extensions, null, 2));
      console.log(`${colors.fg.green}Created recommended extensions file at ${extensionsPath}${colors.reset}`);
      
      console.log(`\n${colors.fg.green}Cursor AI has been configured for your project!${colors.reset}`);
      console.log(`${colors.fg.white}To use Cursor AI:${colors.reset}`);
      console.log(`${colors.fg.white}1. Open your project in Cursor AI${colors.reset}`);
      console.log(`${colors.fg.white}2. Use Cmd+K (Mac) or Ctrl+K (Windows/Linux) to open the AI chat${colors.reset}`);
      console.log(`${colors.fg.white}3. Ask questions or request code generation${colors.reset}`);
    } else {
      console.log(`${colors.fg.yellow}Please install Cursor AI from https://cursor.sh before continuing.${colors.reset}`);
    }
    
    // Return to menu
    await displayMenu();
  });
}

/**
 * Generate project structure
 */
async function generateProjectStructure() {
  console.log(`\n${colors.fg.cyan}${colors.bright}GENERATE PROJECT STRUCTURE${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  console.log(`${colors.fg.yellow}This will generate a recommended project structure for AutoLaunch Studio.${colors.reset}`);
  
  rl.question(`\n${colors.fg.cyan}Do you want to generate the project structure? (y/n): ${colors.reset}`, async (answer) => {
    if (answer.toLowerCase() === 'y') {
      console.log(`${colors.fg.green}Generating project structure...${colors.reset}`);
      
      // Create directories
      const directories = [
        'frontend/src/components',
        'frontend/src/pages',
        'frontend/src/contexts',
        'frontend/src/hooks',
        'frontend/src/utils',
        'frontend/public',
        'backend/src/controllers',
        'backend/src/models',
        'backend/src/routes',
        'backend/src/services',
        'backend/src/middleware',
        'backend/src/utils',
        'config',
        'scripts',
        'docs'
      ];
      
      directories.forEach(dir => {
        const dirPath = path.join(config.projectRoot, dir);
        if (!fs.existsSync(dirPath)) {
          fs.mkdirSync(dirPath, { recursive: true });
          console.log(`${colors.fg.green}Created directory: ${dir}${colors.reset}`);
        }
      });
      
      // Create basic files
      const files = [
        {
          path: 'frontend/package.json',
          content: JSON.stringify({
            "name": "autolaunch-studio-frontend",
            "version": "1.0.0",
            "private": true,
            "dependencies": {
              "react": "^18.2.0",
              "react-dom": "^18.2.0",
              "react-router-dom": "^6.10.0",
              "@mui/material": "^5.11.16",
              "@mui/icons-material": "^5.11.16",
              "axios": "^1.3.5",
              "react-toastify": "^9.1.2"
            },
            "scripts": {
              "start": "react-scripts start",
              "build": "react-scripts build",
              "test": "react-scripts test",
              "eject": "react-scripts eject"
            },
            "eslintConfig": {
              "extends": [
                "react-app",
                "react-app/jest"
              ]
            },
            "browserslist": {
              "production": [
                ">0.2%",
                "not dead",
                "not op_mini all"
              ],
              "development": [
                "last 1 chrome version",
                "last 1 firefox version",
                "last 1 safari version"
              ]
            }
          }, null, 2)
        },
        {
          path: 'backend/package.json',
          content: JSON.stringify({
            "name": "autolaunch-studio-backend",
            "version": "1.0.0",
            "private": true,
            "dependencies": {
              "express": "^4.18.2",
              "mongoose": "^7.0.3",
              "cors": "^2.8.5",
              "dotenv": "^16.0.3",
              "helmet": "^6.1.5",
              "jsonwebtoken": "^9.0.0",
              "morgan": "^1.10.0",
              "bcryptjs": "^2.4.3"
            },
            "scripts": {
              "start": "node src/server.js",
              "dev": "nodemon src/server.js",
              "test": "jest"
            }
          }, null, 2)
        },
        {
          path: 'docker-compose.yml',
          content: `version: '3.8'

services:
  # Frontend service
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: autolaunch-frontend
    ports:
      - "3000:3000"
    volumes:
      - ./frontend:/app
      - /app/node_modules
    environment:
      - NODE_ENV=production
      - REACT_APP_API_URL=http://backend:3001/api
    depends_on:
      - backend
    restart: unless-stopped
    networks:
      - autolaunch-network

  # Backend service
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: autolaunch-backend
    ports:
      - "3001:3001"
    volumes:
      - ./backend:/app
      - /app/node_modules
    environment:
      - NODE_ENV=production
      - PORT=3001
      - MONGODB_URI=mongodb://mongo:27017/autolaunch
      - JWT_SECRET=\${JWT_SECRET:-autolaunchsecret}
    depends_on:
      - mongo
    restart: unless-stopped
    networks:
      - autolaunch-network

  # MongoDB service
  mongo:
    image: mongo:latest
    container_name: autolaunch-mongo
    ports:
      - "27017:27017"
    volumes:
      - mongo-data:/data/db
    restart: unless-stopped
    networks:
      - autolaunch-network

  # Nginx for reverse proxy
  nginx:
    image: nginx:latest
    container_name: autolaunch-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./config/nginx.conf:/etc/nginx/conf.d/default.conf
      - ./config/ssl:/etc/nginx/ssl
    depends_on:
      - frontend
      - backend
    restart: unless-stopped
    networks:
      - autolaunch-network

volumes:
  mongo-data:

networks:
  autolaunch-network:
    driver: bridge`
        },
        {
          path: 'README.md',
          content: `# AutoLaunch Studio

AutoLaunch Studio is a comprehensive platform for creating, deploying, and managing various types of web applications, mobile apps, WordPress themes/plugins, browser extensions, and more.

## Features

- **Multi-platform App Creation**: Create web applications, mobile apps, desktop apps, WordPress themes, WordPress plugins, browser extensions, and CMS plugins
- **Browser-based Frontend**: User-friendly interface for creating and managing applications
- **Admin Dashboard**: Comprehensive admin interface for user management, deployment control, and system settings
- **Cursor AI Integration**: Leverage Cursor AI for development assistance
- **Docker Deployment**: Complete Docker setup for easy deployment
- **Auto-launch Functionality**: Automatically deploy apps upon creation

## Development

This project uses Cursor AI for development assistance. Cursor AI is a coding assistant integrated with VS Code that helps with code generation, refactoring, and more.

### Getting Started

1. Install Cursor AI from [https://cursor.sh](https://cursor.sh)
2. Open this project in Cursor AI
3. Use Cmd+K (Mac) or Ctrl+K (Windows/Linux) to open the AI chat
4. Start developing with AI assistance!

## Installation

See the [Installation Guide](docs/installation.md) for detailed instructions.

## License

[MIT License](LICENSE)
`
        },
        {
          path: 'docs/installation.md',
          content: `# Installation Guide

## Prerequisites

- Docker and Docker Compose
- Node.js 16.x or higher
- MongoDB (or use the provided Docker container)

## Setup

1. Clone the repository:
   \`\`\`
   git clone https://github.com/your-org/autolaunch-studio.git
   cd autolaunch-studio
   \`\`\`

2. Install dependencies:
   \`\`\`
   # Install frontend dependencies
   cd frontend
   npm install
   
   # Install backend dependencies
   cd ../backend
   npm install
   \`\`\`

3. Start the application using Docker Compose:
   \`\`\`
   docker-compose up -d
   \`\`\`

4. Access the application at http://localhost:3000
`
        },
        {
          path: '.gitignore',
          content: `# Dependencies
node_modules/
/.pnp
.pnp.js

# Testing
/coverage

# Production
/build
/dist

# Misc
.DS_Store
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

npm-debug.log*
yarn-debug.log*
yarn-error.log*

# IDE
.idea/
.vscode/*
!.vscode/settings.json
!.vscode/extensions.json
`
        }
      ];
      
      files.forEach(file => {
        const filePath = path.join(config.projectRoot, file.path);
        const dirPath = path.dirname(filePath);
        
        if (!fs.existsSync(dirPath)) {
          fs.mkdirSync(dirPath, { recursive: true });
        }
        
        if (!fs.existsSync(filePath)) {
          fs.writeFileSync(filePath, file.content);
          console.log(`${colors.fg.green}Created file: ${file.path}${colors.reset}`);
        }
      });
      
      console.log(`\n${colors.fg.green}Project structure generated successfully!${colors.reset}`);
    } else {
      console.log(`${colors.fg.yellow}Project structure generation skipped.${colors.reset}`);
    }
    
    // Return to menu
    await displayMenu();
  });
}

/**
 * Configure deployment method
 */
async function configureDeployment() {
  console.log(`\n${colors.fg.cyan}${colors.bright}CONFIGURE DEPLOYMENT METHOD${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  console.log(`${colors.fg.yellow}This will help you configure a deployment method for your project.${colors.reset}`);
  
  console.log(`\n${colors.fg.white}Available deployment methods:${colors.reset}`);
  console.log(`${colors.fg.white}1. Standard (Docker)${colors.reset}`);
  console.log(`${colors.fg.white}2. GitHub Actions${colors.reset}`);
  console.log(`${colors.fg.white}3. Vercel${colors.reset}`);
  console.log(`${colors.fg.white}4. Netlify${colors.reset}`);
  
  rl.question(`\n${colors.fg.cyan}Select a deployment method (1-4): ${colors.reset}`, async (choice) => {
    let deploymentMethod = 'standard';
    let deploymentFiles = [];
    
    switch (choice) {
      case '1': // Standard (Docker)
        deploymentMethod = 'standard';
        deploymentFiles = [
          {
            path: 'frontend/Dockerfile',
            content: `FROM node:16-alpine as build

WORKDIR /app

# Copy package.json and package-lock.json
COPY package*.json ./

# Install dependencies
RUN npm ci

# Copy the rest of the frontend code
COPY . .

# Build the React app
RUN npm run build

# Production stage
FROM nginx:alpine

# Copy the build output from the build stage
COPY --from=build /app/build /usr/share/nginx/html

# Copy custom nginx config if needed
COPY nginx.conf /etc/nginx/conf.d/default.conf

# Expose port 3000
EXPOSE 3000

# Start Nginx server
CMD ["nginx", "-g", "daemon off;"]`
          },
          {
            path: 'backend/Dockerfile',
            content: `FROM node:16-alpine

WORKDIR /app

# Copy package.json and package-lock.json
COPY package*.json ./

# Install dependencies
RUN npm ci

# Copy the rest of the backend code
COPY . .

# Expose port 3001
EXPOSE 3001

# Start the server
CMD ["npm", "start"]`
          },
          {
            path: 'scripts/deploy.sh',
            content: `#!/bin/bash

# Deployment script for AutoLaunch Studio
# This script deploys the application using Docker Compose

# Set colors for output
GREEN='\\033[0;32m'
RED='\\033[0;31m'
YELLOW='\\033[0;33m'
NC='\\033[0m' # No Color

echo -e "${YELLOW}Starting deployment of AutoLaunch Studio...${NC}"

# Build and start Docker containers
echo -e "${YELLOW}Building and starting Docker containers...${NC}"
docker-compose up -d --build

if [ $? -eq 0 ]; then
  echo -e "${GREEN}Deployment completed successfully!${NC}"
  echo -e "${GREEN}The application is now available at:${NC}"
  echo -e "${GREEN}Frontend: http://localhost:3000${NC}"
  echo -e "${GREEN}Backend API: http://localhost:3001${NC}"
else
  echo -e "${RED}Deployment failed. Please check the logs for more information.${NC}"
  exit 1
fi`
          }
        ];
        break;
        
      case '2': // GitHub Actions
        deploymentMethod = 'github';
        deploymentFiles = [
          {
            path: '.github/workflows/deploy.yml',
            content: `name: Deploy AutoLaunch Studio

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '16'
        
    - name: Install frontend dependencies
      run: |
        cd frontend
        npm ci
        
    - name: Build frontend
      run: |
        cd frontend
        npm run build
        
    - name: Install backend dependencies
      run: |
        cd backend
        npm ci
        
    - name: Deploy to server
      uses: appleboy/ssh-action@master
      with:
        host: ${{ secrets.HOST }}
        username: ${{ secrets.USERNAME }}
        key: ${{ secrets.SSH_KEY }}
        script: |
          cd /path/to/deployment
          git pull
          cd frontend
          npm ci
          npm run build
          cd ../backend
          npm ci
          pm2 restart autolaunch-backend`
          },
          {
            path: 'scripts/setup-github-actions.sh',
            content: `#!/bin/bash

# Setup script for GitHub Actions deployment
# This script helps set up the necessary secrets for GitHub Actions

# Set colors for output
GREEN='\\033[0;32m'
RED='\\033[0;31m'
YELLOW='\\033[0;33m'
NC='\\033[0m' # No Color

echo -e "${YELLOW}Setting up GitHub Actions deployment...${NC}"

echo -e "${YELLOW}Please make sure you have the following information ready:${NC}"
echo -e "1. Server hostname or IP address"
echo -e "2. SSH username"
echo -e "3. SSH private key"

echo -e "${YELLOW}You will need to add these as secrets in your GitHub repository:${NC}"
echo -e "1. HOST: Your server hostname or IP address"
echo -e "2. USERNAME: Your SSH username"
echo -e "3. SSH_KEY: Your SSH private key"

echo -e "${GREEN}Setup instructions:${NC}"
echo -e "1. Go to your GitHub repository"
echo -e "2. Click on 'Settings'"
echo -e "3. Click on 'Secrets and variables' > 'Actions'"
echo -e "4. Add the required secrets"

echo -e "${GREEN}Setup complete!${NC}"
echo -e "Once you've added the secrets, GitHub Actions will automatically deploy your application when you push to the main branch."
`
          }
        ];
        break;
        
      case '3': // Vercel
        deploymentMethod = 'vercel';
        deploymentFiles = [
          {
            path: 'vercel.json',
            content: `{
  "version": 2,
  "builds": [
    {
      "src": "frontend/package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "build"
      }
    },
    {
      "src": "backend/src/server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "backend/src/server.js"
    },
    {
      "src": "/(.*)",
      "dest": "frontend/$1"
    }
  ]
}`
          },
          {
            path: 'scripts/deploy-vercel.sh',
            content: `#!/bin/bash

# Deployment script for Vercel
# This script deploys the application to Vercel

# Set colors for output
GREEN='\\033[0;32m'
RED='\\033[0;31m'
YELLOW='\\033[0;33m'
NC='\\033[0m' # No Color

echo -e "${YELLOW}Deploying to Vercel...${NC}"

# Check if Vercel CLI is installed
if ! command -v vercel &> /dev/null; then
  echo -e "${YELLOW}Vercel CLI not found. Installing...${NC}"
  npm install -g vercel
fi

# Deploy to Vercel
echo -e "${YELLOW}Deploying project to Vercel...${NC}"
vercel --prod

if [ $? -eq 0 ]; then
  echo -e "${GREEN}Deployment to Vercel completed successfully!${NC}"
else
  echo -e "${RED}Deployment to Vercel failed. Please check the logs for more information.${NC}"
  exit 1
fi`
          }
        ];
        break;
        
      case '4': // Netlify
        deploymentMethod = 'netlify';
        deploymentFiles = [
          {
            path: 'netlify.toml',
            content: `[build]
  base = "frontend"
  publish = "build"
  command = "npm run build"

[build.environment]
  REACT_APP_API_URL = "/.netlify/functions/api"

[functions]
  directory = "backend/netlify/functions"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/api/:splat"
  status = 200

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200`
          },
          {
            path: 'backend/netlify/functions/api.js',
            content: `const express = require('express');
const serverless = require('serverless-http');
const app = require('../../src/server');

// Wrap the Express app with serverless
module.exports.handler = serverless(app);`
          },
          {
            path: 'scripts/deploy-netlify.sh',
            content: `#!/bin/bash

# Deployment script for Netlify
# This script deploys the application to Netlify

# Set colors for output
GREEN='\\033[0;32m'
RED='\\033[0;31m'
YELLOW='\\033[0;33m'
NC='\\033[0m' # No Color

echo -e "${YELLOW}Deploying to Netlify...${NC}"

# Check if Netlify CLI is installed
if ! command -v netlify &> /dev/null; then
  echo -e "${YELLOW}Netlify CLI not found. Installing...${NC}"
  npm install -g netlify-cli
fi

# Deploy to Netlify
echo -e "${YELLOW}Deploying project to Netlify...${NC}"
netlify deploy --prod

if [ $? -eq 0 ]; then
  echo -e "${GREEN}Deployment to Netlify completed successfully!${NC}"
else
  echo -e "${RED}Deployment to Netlify failed. Please check the logs for more information.${NC}"
  exit 1
fi`
          }
        ];
        break;
        
      default:
        console.log(`${colors.fg.red}Invalid choice. Using standard deployment method.${colors.reset}`);
        deploymentMethod = 'standard';
        break;
    }
    
    // Update config
    config.deploymentType = deploymentMethod;
    
    // Create deployment files
    deploymentFiles.forEach(file => {
      const filePath = path.join(config.projectRoot, file.path);
      const dirPath = path.dirname(filePath);
      
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
      
      fs.writeFileSync(filePath, file.content);
      console.log(`${colors.fg.green}Created deployment file: ${file.path}${colors.reset}`);
      
      // Make scripts executable
      if (file.path.startsWith('scripts/') && file.path.endsWith('.sh')) {
        try {
          execSync(`chmod +x ${filePath}`);
          console.log(`${colors.fg.green}Made script executable: ${file.path}${colors.reset}`);
        } catch (error) {
          console.error(`${colors.fg.red}Error making script executable: ${error.message}${colors.reset}`);
        }
      }
    });
    
    console.log(`\n${colors.fg.green}Deployment configuration for ${deploymentMethod} completed successfully!${colors.reset}`);
    
    // Return to menu
    await displayMenu();
  });
}

/**
 * Generate Cursor AI prompts
 */
async function generateCursorPrompts() {
  console.log(`\n${colors.fg.cyan}${colors.bright}GENERATE CURSOR AI PROMPTS${colors.reset}`);
  console.log(`${colors.fg.white}---------------------------${colors.reset}`);
  
  console.log(`${colors.fg.yellow}This will generate helpful prompts for using Cursor AI with AutoLaunch Studio.${colors.reset}`);
  
  rl.question(`\n${colors.fg.cyan}Do you want to generate Cursor AI prompts? (y/n): ${colors.reset}`, async (answer) => {
    if (answer.toLowerCase() === 'y') {
      console.log(`${colors.fg.green}Generating Cursor AI prompts...${colors.reset}`);
      
      // Create prompts directory
      const promptsDir = path.join(config.projectRoot, 'docs/cursor-prompts');
      if (!fs.existsSync(promptsDir)) {
        fs.mkdirSync(promptsDir, { recursive: true });
      }
      
      // Create prompt files
      const prompts = [
        {
          path: 'docs/cursor-prompts/frontend-components.md',
          content: `# Cursor AI Prompts for Frontend Components

## React Component Creation

### Basic Component

\`\`\`
Create a React functional component named [ComponentName] that [describe what the component should do].

The component should accept the following props:
- [propName]: [propType] - [description]
- [propName]: [propType] - [description]

Include proper TypeScript types and styled-components for styling.
\`\`\`

### Form Component

\`\`\`
Create a React form component for [purpose of the form]. The form should include fields for:
- [field name]: [field type] - [validation requirements]
- [field name]: [field type] - [validation requirements]

Use Material-UI components and include form validation with error messages.
\`\`\`

### Data Display Component

\`\`\`
Create a React component to display [type of data] data. The component should:
- Accept data as a prop
- Handle loading and error states
- Include pagination if the data is a list
- Allow sorting and filtering if appropriate

Use Material-UI components for the UI elements.
\`\`\`

## Page Layout

\`\`\`
Create a page layout for the [page name] page. The layout should include:
- A header with [header elements]
- A main content area for [content description]
- A sidebar with [sidebar elements]
- A footer with [footer elements]

Use responsive design principles to ensure the layout works on mobile devices.
\`\`\`

## Context and Hooks

\`\`\`
Create a React context and custom hook for managing [state description].

The context should provide:
- [state name]: [state type] - [description]
- [function name]: Function to [function purpose]

The custom hook should be named use[ContextName] and provide easy access to the context values.
\`\`\`
`
        },
        {
          path: 'docs/cursor-prompts/backend-development.md',
          content: `# Cursor AI Prompts for Backend Development

## API Endpoints

### CRUD Endpoint

\`\`\`
Create a set of CRUD API endpoints for the [resource name] resource.

Include the following routes:
- GET /api/[resource] - Get all [resource]
- GET /api/[resource]/:id - Get a specific [resource]
- POST /api/[resource] - Create a new [resource]
- PUT /api/[resource]/:id - Update a [resource]
- DELETE /api/[resource]/:id - Delete a [resource]

Include proper validation, error handling, and authentication middleware.
\`\`\`

### Authentication Endpoint

\`\`\`
Create authentication endpoints for user registration and login.

Include the following routes:
- POST /api/auth/register - Register a new user
- POST /api/auth/login - Log in an existing user
- POST /api/auth/logout - Log out a user
- GET /api/auth/me - Get the current user's information

Use JWT for authentication and include proper validation and error handling.
\`\`\`

## Database Models

\`\`\`
Create a Mongoose schema for the [model name] model with the following fields:
- [field name]: [field type] - [description]
- [field name]: [field type] - [description]

Include validation, indexes, and any necessary virtual properties or methods.
\`\`\`

## Middleware

\`\`\`
Create a middleware function for [middleware purpose].

The middleware should:
- [action description]
- [action description]

Include proper error handling and next() calls.
\`\`\`

## Services

\`\`\`
Create a service module for [service purpose].

The service should include the following functions:
- [function name]: Function to [function purpose]
- [function name]: Function to [function purpose]

Include proper error handling and logging.
\`\`\`
`
        },
        {
          path: 'docs/cursor-prompts/wordpress-development.md',
          content: `# Cursor AI Prompts for WordPress Development

## WordPress Theme

\`\`\`
Create a WordPress theme structure for [theme name].

Include the following files:
- style.css with theme metadata
- functions.php with theme setup
- index.php as the main template
- header.php and footer.php
- single.php for single posts
- page.php for pages
- archive.php for archives

Include proper WordPress hooks and functions.
\`\`\`

## WordPress Plugin

\`\`\`
Create a WordPress plugin structure for [plugin name] that [plugin purpose].

Include the following files:
- Main plugin file with plugin metadata
- Admin class for admin functionality
- Frontend class for frontend functionality
- Includes directory for helper functions
- Assets directory for CSS, JS, and images

Include proper WordPress hooks, actions, and filters.
\`\`\`

## Custom Post Type

\`\`\`
Create a custom post type for [post type name] with the following features:
- Custom fields for [field descriptions]
- Custom taxonomies for [taxonomy descriptions]
- Admin columns for [column descriptions]
- Custom metaboxes for [metabox descriptions]

Use proper WordPress functions and hooks.
\`\`\`

## Shortcode

\`\`\`
Create a WordPress shortcode for [shortcode purpose].

The shortcode should:
- Accept attributes for [attribute descriptions]
- Output [output description]
- Include proper escaping and validation

Use proper WordPress shortcode API functions.
\`\`\`

## Widget

\`\`\`
Create a WordPress widget for [widget purpose].

The widget should:
- Accept settings for [setting descriptions]
- Output [output description]
- Include a form for configuring the widget in the admin

Use proper WordPress widget API classes and methods.
\`\`\`
`
        },
        {
          path: 'docs/cursor-prompts/browser-extensions.md',
          content: `# Cursor AI Prompts for Browser Extension Development

## Manifest File

\`\`\`
Create a manifest.json file for a browser extension that [extension purpose].

Include the following permissions:
- [permission] - [reason for permission]
- [permission] - [reason for permission]

Configure the extension to [configuration details].
\`\`\`

## Content Script

\`\`\`
Create a content script for a browser extension that [script purpose].

The script should:
- [action description]
- [action description]

Include proper error handling and browser compatibility.
\`\`\`

## Background Script

\`\`\`
Create a background script for a browser extension that [script purpose].

The script should:
- [action description]
- [action description]

Include proper message handling and browser API usage.
\`\`\`

## Popup UI

\`\`\`
Create a popup UI for a browser extension that [UI purpose].

The UI should include:
- [element description]
- [element description]

Use HTML, CSS, and JavaScript to create a responsive and user-friendly interface.
\`\`\`

## Options Page

\`\`\`
Create an options page for a browser extension that [page purpose].

The page should include:
- [element description]
- [element description]

Use HTML, CSS, and JavaScript to create a form for configuring the extension.
\`\`\`
`
        },
        {
          path: 'docs/cursor-prompts/deployment.md',
          content: `# Cursor AI Prompts for Deployment

## Docker Configuration

\`\`\`
Create a Dockerfile for a [service type] service with the following requirements:
- Base image: [base image]
- Working directory: [directory]
- Exposed ports: [ports]
- Environment variables: [variables]

Include proper optimization techniques like multi-stage builds and layer caching.
\`\`\`

## Docker Compose

\`\`\`
Create a docker-compose.yml file for a project with the following services:
- [service name]: [service description]
- [service name]: [service description]

Include proper networking, volume mounting, and environment variables.
\`\`\`

## GitHub Actions Workflow

\`\`\`
Create a GitHub Actions workflow for [workflow purpose].

The workflow should:
- Trigger on [trigger events]
- Run on [runner type]
- Include jobs for [job descriptions]

Include proper caching, artifact handling, and error reporting.
\`\`\`

## Nginx Configuration

\`\`\`
Create an Nginx configuration for a [service type] service with the following requirements:
- Listen on port [port]
- Serve static files from [directory]
- Proxy requests to [backend service]
- Include SSL configuration

Include proper security headers, caching, and performance optimizations.
\`\`\`

## Deployment Script

\`\`\`
Create a deployment script for [deployment purpose].

The script should:
- [action description]
- [action description]

Include proper error handling, logging, and rollback mechanisms.
\`\`\`
`
        }
      ];
      
      prompts.forEach(prompt => {
        const promptPath = path.join(config.projectRoot, prompt.path);
        const promptDir = path.dirname(promptPath);
        
        if (!fs.existsSync(promptDir)) {
          fs.mkdirSync(promptDir, { recursive: true });
        }
        
        fs.writeFileSync(promptPath, prompt.content);
        console.log(`${colors.fg.green}Created prompt file: ${prompt.path}${colors.reset}`);
      });
      
      // Create main prompts index
      const indexPath = path.join(config.projectRoot, 'docs/cursor-prompts/README.md');
      const indexContent = `# Cursor AI Prompts for AutoLaunch Studio

This directory contains helpful prompts for using Cursor AI with AutoLaunch Studio.

## Available Prompt Categories

- [Frontend Components](frontend-components.md) - Prompts for creating React components, layouts, and hooks
- [Backend Development](backend-development.md) - Prompts for creating API endpoints, database models, and services
- [WordPress Development](wordpress-development.md) - Prompts for WordPress themes, plugins, and custom post types
- [Browser Extensions](browser-extensions.md) - Prompts for browser extension development
- [Deployment](deployment.md) - Prompts for Docker, GitHub Actions, and other deployment configurations

## How to Use These Prompts

1. Open your project in Cursor AI
2. Press Cmd+K (Mac) or Ctrl+K (Windows/Linux) to open the AI chat
3. Copy and paste a prompt from one of the prompt files
4. Customize the prompt by replacing the placeholders in [square brackets]
5. Send the prompt to Cursor AI
6. Review and refine the generated code as needed

## Tips for Getting Better Results

- Be specific about what you want Cursor AI to generate
- Provide context about your project and requirements
- Break complex tasks into smaller, more focused prompts
- Review and iterate on the generated code
- Learn from the generated code to improve your own skills
`;
      
      fs.writeFileSync(indexPath, indexContent);
      console.log(`${colors.fg.green}Created prompts index: docs/cursor-prompts/README.md${colors.reset}`);
      
      console.log(`\n${colors.fg.green}Cursor AI prompts generated successfully!${colors.reset}`);
      console.log(`${colors.fg.white}You can find the prompts in the docs/cursor-prompts directory.${colors.reset}`);
    } else {
      console.log(`${colors.fg.yellow}Cursor AI prompts generation skipped.${colors.reset}`);
    }
    
    // Return to menu
    await displayMenu();
  });
}

// Start the application
main().catch(error => {
  console.error(`${colors.fg.red}Fatal error: ${error}${colors.reset}`);
  process.exit(1);
});

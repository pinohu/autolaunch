// Agent Orchestration System for AutoLaunch Studio
// This file provides the core functionality for the multi-agent architecture

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

class AgentOrchestrationSystem extends EventEmitter {
  constructor(specPath) {
    super();
    this.specPath = specPath;
    this.spec = null;
    this.agents = {};
    this.workflows = {};
    this.context = {};
    this.loadSpec();
  }

  // Load agent specification from JSON file
  loadSpec() {
    try {
      if (fs.existsSync(this.specPath)) {
        const rawData = fs.readFileSync(this.specPath, 'utf8');
        this.spec = JSON.parse(rawData);
        this.initializeAgents();
        this.initializeWorkflows();
        console.log('Agent specification loaded successfully');
      } else {
        console.error('Agent specification file not found:', this.specPath);
      }
    } catch (error) {
      console.error('Error loading agent specification:', error);
    }
  }

  // Initialize agents from specification
  initializeAgents() {
    if (!this.spec || !this.spec.agentSystem || !this.spec.agentSystem.agents) {
      console.error('Invalid agent specification');
      return;
    }

    this.spec.agentSystem.agents.forEach(agentSpec => {
      this.agents[agentSpec.id] = {
        spec: agentSpec,
        instance: null,
        status: 'idle',
        lastRun: null,
        outputs: {}
      };
    });

    console.log(`Initialized ${Object.keys(this.agents).length} agents`);
  }

  // Initialize workflows from specification
  initializeWorkflows() {
    if (!this.spec || !this.spec.agentSystem || !this.spec.agentSystem.workflows) {
      console.error('Invalid workflow specification');
      return;
    }

    this.spec.agentSystem.workflows.forEach(workflowSpec => {
      this.workflows[workflowSpec.id] = {
        spec: workflowSpec,
        status: 'idle',
        currentStep: 0,
        startTime: null,
        endTime: null,
        results: {}
      };
    });

    console.log(`Initialized ${Object.keys(this.workflows).length} workflows`);
  }

  // Get agent by ID
  getAgent(agentId) {
    return this.agents[agentId];
  }

  // Get workflow by ID
  getWorkflow(workflowId) {
    return this.workflows[workflowId];
  }

  // Get all agents
  getAllAgents() {
    return Object.values(this.agents).map(agent => ({
      id: agent.spec.id,
      name: agent.spec.name,
      description: agent.spec.description,
      status: agent.status,
      lastRun: agent.lastRun
    }));
  }

  // Get all workflows
  getAllWorkflows() {
    return Object.values(this.workflows).map(workflow => ({
      id: workflow.spec.id,
      name: workflow.spec.name,
      description: workflow.spec.description,
      status: workflow.status,
      currentStep: workflow.currentStep,
      startTime: workflow.startTime,
      endTime: workflow.endTime
    }));
  }

  // Execute a specific agent
  async executeAgent(agentId, inputs = {}) {
    const agent = this.agents[agentId];
    if (!agent) {
      console.error(`Agent "${agentId}" not found`);
      return null;
    }

    // Update agent status
    agent.status = 'running';
    agent.lastRun = new Date();
    this.emit('agent:start', { agentId, timestamp: agent.lastRun });

    try {
      // Check if all required inputs are provided
      const missingInputs = agent.spec.inputs.filter(input => !inputs[input] && !this.context[input]);
      if (missingInputs.length > 0) {
        throw new Error(`Missing required inputs for agent "${agentId}": ${missingInputs.join(', ')}`);
      }

      // Combine provided inputs with context
      const combinedInputs = { ...this.context, ...inputs };

      // Execute agent (placeholder for actual agent execution)
      console.log(`Executing agent "${agentId}" with inputs:`, Object.keys(combinedInputs));
      
      // This would be replaced with actual agent execution logic
      // For now, we'll simulate execution with a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulate agent outputs
      const outputs = {};
      agent.spec.outputs.forEach(output => {
        outputs[output] = `Sample ${output} from ${agentId}`;
      });
      
      // Update agent outputs
      agent.outputs = outputs;
      
      // Update shared context with outputs
      if (this.spec.agentSystem.orchestration.sharedContext) {
        Object.assign(this.context, outputs);
      }
      
      // Update agent status
      agent.status = 'completed';
      this.emit('agent:complete', { agentId, outputs, timestamp: new Date() });
      
      return outputs;
    } catch (error) {
      // Handle agent execution error
      agent.status = 'failed';
      this.emit('agent:error', { agentId, error: error.message, timestamp: new Date() });
      console.error(`Error executing agent "${agentId}":`, error);
      return null;
    }
  }

  // Execute a workflow
  async executeWorkflow(workflowId, initialInputs = {}) {
    const workflow = this.workflows[workflowId];
    if (!workflow) {
      console.error(`Workflow "${workflowId}" not found`);
      return null;
    }

    // Reset context for new workflow
    this.context = { ...initialInputs };

    // Update workflow status
    workflow.status = 'running';
    workflow.currentStep = 0;
    workflow.startTime = new Date();
    workflow.results = {};
    this.emit('workflow:start', { workflowId, timestamp: workflow.startTime });

    try {
      const { agentSequence, parallelExecution } = workflow.spec;

      if (parallelExecution) {
        // Execute agents in parallel
        const promises = agentSequence.map(agentId => this.executeAgent(agentId));
        const results = await Promise.all(promises);
        
        // Combine results
        agentSequence.forEach((agentId, index) => {
          workflow.results[agentId] = results[index];
        });
      } else {
        // Execute agents sequentially
        for (let i = 0; i < agentSequence.length; i++) {
          const agentId = agentSequence[i];
          workflow.currentStep = i;
          this.emit('workflow:step', { workflowId, step: i, agentId, timestamp: new Date() });
          
          const result = await this.executeAgent(agentId);
          workflow.results[agentId] = result;
          
          if (!result) {
            throw new Error(`Agent "${agentId}" execution failed`);
          }
        }
      }

      // Update workflow status
      workflow.status = 'completed';
      workflow.endTime = new Date();
      this.emit('workflow:complete', { 
        workflowId, 
        results: workflow.results, 
        timestamp: workflow.endTime,
        duration: workflow.endTime - workflow.startTime
      });
      
      return workflow.results;
    } catch (error) {
      // Handle workflow execution error
      workflow.status = 'failed';
      workflow.endTime = new Date();
      this.emit('workflow:error', { 
        workflowId, 
        error: error.message, 
        step: workflow.currentStep,
        timestamp: workflow.endTime
      });
      console.error(`Error executing workflow "${workflowId}":`, error);
      return null;
    }
  }

  // Get the current shared context
  getContext() {
    return this.context;
  }

  // Update the shared context
  updateContext(updates) {
    Object.assign(this.context, updates);
    this.emit('context:update', { updates, timestamp: new Date() });
    return this.context;
  }

  // Clear the shared context
  clearContext() {
    this.context = {};
    this.emit('context:clear', { timestamp: new Date() });
    return this.context;
  }

  // Save execution results
  saveResults(workflowId, outputPath) {
    const workflow = this.workflows[workflowId];
    if (!workflow) {
      console.error(`Workflow "${workflowId}" not found`);
      return false;
    }

    try {
      const results = {
        workflow: {
          id: workflow.spec.id,
          name: workflow.spec.name,
          description: workflow.spec.description,
          status: workflow.status,
          startTime: workflow.startTime,
          endTime: workflow.endTime,
          duration: workflow.endTime - workflow.startTime
        },
        results: workflow.results,
        context: this.context
      };

      fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));
      console.log(`Results saved to ${outputPath}`);
      return true;
    } catch (error) {
      console.error(`Error saving results for workflow "${workflowId}":`, error);
      return false;
    }
  }
}

module.exports = AgentOrchestrationSystem;

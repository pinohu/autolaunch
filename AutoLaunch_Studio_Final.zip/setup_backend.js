#!/usr/bin/env node

/**
 * AutoLaunch Studio Backend Setup Script
 * 
 * This script sets up the backend component of AutoLaunch Studio
 * with Node.js, Express, and necessary dependencies.
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuration
const config = {
  projectRoot: '/home/ubuntu/autolaunch_studio',
  backendDir: '/home/ubuntu/autolaunch_studio/backend',
  useTypeScript: true,
  database: 'postgres'
};

/**
 * Main function to set up the backend
 */
async function setupBackend() {
  console.log('🚀 Setting up AutoLaunch Studio Backend...');
  
  try {
    // Create backend directory if it doesn't exist
    if (!fs.existsSync(config.backendDir)) {
      fs.mkdirSync(config.backendDir, { recursive: true });
    }
    
    // Initialize Node.js project
    console.log('Initializing Node.js project...');
    process.chdir(config.backendDir);
    execSync('npm init -y', { stdio: 'inherit' });
    
    // Install dependencies
    console.log('Installing dependencies...');
    
    // Core dependencies
    execSync('npm install express cors dotenv helmet morgan', { stdio: 'inherit' });
    
    // Database dependencies
    if (config.database === 'postgres') {
      execSync('npm install pg pg-hstore sequelize', { stdio: 'inherit' });
    } else if (config.database === 'mongodb') {
      execSync('npm install mongoose', { stdio: 'inherit' });
    }
    
    // Authentication dependencies
    execSync('npm install jsonwebtoken bcrypt', { stdio: 'inherit' });
    
    // TypeScript dependencies if enabled
    if (config.useTypeScript) {
      execSync('npm install typescript ts-node @types/node @types/express @types/cors @types/morgan @types/jsonwebtoken @types/bcrypt --save-dev', { stdio: 'inherit' });
      
      // Create tsconfig.json
      createTsConfig();
    }
    
    // Create project structure
    createProjectStructure();
    
    // Create main server file
    createServerFile();
    
    // Create API routes
    createApiRoutes();
    
    // Create models
    createModels();
    
    // Create services
    createServices();
    
    // Create middleware
    createMiddleware();
    
    // Create utils
    createUtils();
    
    // Update package.json scripts
    updatePackageJson();
    
    console.log('✅ Backend setup completed successfully!');
    console.log(`You can start the development server by running: cd ${config.backendDir} && npm run dev`);
    
    return { success: true };
  } catch (error) {
    console.error('Backend setup failed:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Create TypeScript configuration
 */
function createTsConfig() {
  console.log('Creating TypeScript configuration...');
  
  const tsConfig = {
    "compilerOptions": {
      "target": "es2018",
      "module": "commonjs",
      "outDir": "./dist",
      "rootDir": "./src",
      "strict": true,
      "esModuleInterop": true,
      "skipLibCheck": true,
      "forceConsistentCasingInFileNames": true,
      "resolveJsonModule": true
    },
    "include": ["src/**/*"],
    "exclude": ["node_modules", "**/*.test.ts"]
  };
  
  fs.writeFileSync(
    path.join(config.backendDir, 'tsconfig.json'),
    JSON.stringify(tsConfig, null, 2)
  );
}

/**
 * Create project structure
 */
function createProjectStructure() {
  console.log('Creating project structure...');
  
  const dirs = [
    'src',
    'src/api',
    'src/api/routes',
    'src/api/controllers',
    'src/api/middlewares',
    'src/models',
    'src/services',
    'src/utils',
    'src/config'
  ];
  
  dirs.forEach(dir => {
    fs.mkdirSync(path.join(config.backendDir, dir), { recursive: true });
  });
}

/**
 * Create main server file
 */
function createServerFile() {
  console.log('Creating main server file...');
  
  const extension = config.useTypeScript ? 'ts' : 'js';
  const serverFile = `
${config.useTypeScript ? 'import express, { Application, Request, Response, NextFunction } from \'express\';' : 'const express = require(\'express\');'}
${config.useTypeScript ? 'import cors from \'cors\';' : 'const cors = require(\'cors\');'}
${config.useTypeScript ? 'import helmet from \'helmet\';' : 'const helmet = require(\'helmet\');'}
${config.useTypeScript ? 'import morgan from \'morgan\';' : 'const morgan = require(\'morgan\');'}
${config.useTypeScript ? 'import dotenv from \'dotenv\';' : 'const dotenv = require(\'dotenv\');'}
${config.useTypeScript ? 'import { apiRoutes } from \'./api/routes\';' : 'const apiRoutes = require(\'./api/routes\');'}
${config.useTypeScript ? 'import { errorHandler } from \'./api/middlewares/errorHandler\';' : 'const { errorHandler } = require(\'./api/middlewares/errorHandler\');'}
${config.useTypeScript ? 'import { dbConnect } from \'./config/database\';' : 'const { dbConnect } = require(\'./config/database\');'}

// Load environment variables
dotenv.config();

// Initialize express app
const app${config.useTypeScript ? ': Application' : ''} = express();
const PORT = process.env.PORT || 3001;

// Connect to database
dbConnect();

// Middleware
app.use(cors());
app.use(helmet());
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API routes
app.use('/api', apiRoutes);

// Health check endpoint
app.get('/health', (req${config.useTypeScript ? ': Request' : ''}, res${config.useTypeScript ? ': Response' : ''}) => {
  res.status(200).json({ status: 'ok', message: 'Server is running' });
});

// Error handling middleware
app.use(errorHandler);

// Start server
app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});

${config.useTypeScript ? 'export default app;' : 'module.exports = app;'}
`;

  fs.writeFileSync(
    path.join(config.backendDir, `src/server.${extension}`),
    serverFile
  );
  
  // Create .env file
  const envFile = `
NODE_ENV=development
PORT=3001
DATABASE_URL=postgres://autolaunch_user:autolaunch_password@localhost:5432/autolaunch
JWT_SECRET=your-jwt-secret-change-this-in-production
CORS_ORIGIN=http://localhost:3000
`;

  fs.writeFileSync(
    path.join(config.backendDir, '.env'),
    envFile
  );
  
  // Create database configuration
  const dbConfigFile = `
${config.useTypeScript ? 'import { Sequelize } from \'sequelize\';' : 'const { Sequelize } = require(\'sequelize\');'}
${config.useTypeScript ? 'import dotenv from \'dotenv\';' : 'const dotenv = require(\'dotenv\');'}

dotenv.config();

const databaseUrl = process.env.DATABASE_URL || 'postgres://autolaunch_user:autolaunch_password@localhost:5432/autolaunch';

const sequelize = new Sequelize(databaseUrl, {
  dialect: 'postgres',
  logging: process.env.NODE_ENV === 'development' ? console.log : false,
  dialectOptions: {
    ssl: process.env.NODE_ENV === 'production' ? {
      require: true,
      rejectUnauthorized: false
    } : false
  }
});

const dbConnect = async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connection established successfully');
    
    // Sync models with database
    if (process.env.NODE_ENV === 'development') {
      await sequelize.sync({ alter: true });
      console.log('Database models synchronized');
    }
  } catch (error) {
    console.error('Unable to connect to the database:', error);
    process.exit(1);
  }
};

${config.useTypeScript ? 'export { sequelize, dbConnect };' : 'module.exports = { sequelize, dbConnect };'}
`;

  fs.writeFileSync(
    path.join(config.backendDir, `src/config/database.${extension}`),
    dbConfigFile
  );
}

/**
 * Create API routes
 */
function createApiRoutes() {
  console.log('Creating API routes...');
  
  const extension = config.useTypeScript ? 'ts' : 'js';
  
  // Main routes file
  const routesIndexFile = `
${config.useTypeScript ? 'import { Router } from \'express\';' : 'const { Router } = require(\'express\');'}
${config.useTypeScript ? 'import { promptRoutes } from \'./promptRoutes\';' : 'const { promptRoutes } = require(\'./promptRoutes\');'}
${config.useTypeScript ? 'import { applicationRoutes } from \'./applicationRoutes\';' : 'const { applicationRoutes } = require(\'./applicationRoutes\');'}
${config.useTypeScript ? 'import { authRoutes } from \'./authRoutes\';' : 'const { authRoutes } = require(\'./authRoutes\');'}

const router = Router();

// Mount routes
router.use('/prompts', promptRoutes);
router.use('/applications', applicationRoutes);
router.use('/auth', authRoutes);

${config.useTypeScript ? 'export const apiRoutes = router;' : 'module.exports = { apiRoutes: router };'}
`;

  fs.writeFileSync(
    path.join(config.backendDir, `src/api/routes/index.${extension}`),
    routesIndexFile
  );
  
  // Prompt routes
  const promptRoutesFile = `
${config.useTypeScript ? 'import { Router } from \'express\';' : 'const { Router } = require(\'express\');'}
${config.useTypeScript ? 'import { promptController } from \'../controllers/promptController\';' : 'const { promptController } = require(\'../controllers/promptController\');'}
${config.useTypeScript ? 'import { authMiddleware } from \'../middlewares/authMiddleware\';' : 'const { authMiddleware } = require(\'../middlewares/authMiddleware\');'}

const router = Router();

// Get all prompts
router.get('/', authMiddleware, promptController.getPrompts);

// Get prompt by ID
router.get('/:id', authMiddleware, promptController.getPromptById);

// Create new prompt
router.post('/', authMiddleware, promptController.createPrompt);

// Update prompt
router.put('/:id', authMiddleware, promptController.updatePrompt);

// Delete prompt
router.delete('/:id', authMiddleware, promptController.deletePrompt);

${config.useTypeScript ? 'export const promptRoutes = router;' : 'module.exports = { promptRoutes: router };'}
`;

  fs.writeFileSync(
    path.join(config.backendDir, `src/api/routes/promptRoutes.${extension}`),
    promptRoutesFile
  );
  
  // Application routes
  const applicationRoutesFile = `
${config.useTypeScript ? 'import { Router } from \'express\';' : 'const { Router } = require(\'express\');'}
${config.useTypeScript ? 'import { applicationController } from \'../controllers/applicationController\';' : 'const { applicationController } = require(\'../controllers/applicationController\');'}
${config.useTypeScript ? 'import { authMiddleware } from \'../middlewares/authMiddleware\';' : 'const { authMiddleware } = require(\'../middlewares/authMiddleware\');'}

const router = Router();

// Get all applications
router.get('/', authMiddleware, applicationController.getApplications);

// Get application by ID
router.get('/:id', authMiddleware, applicationController.getApplicationById);

// Deploy application
router.post('/:id/deploy', authMiddleware, applicationController.deployApplication);

// Rollback application
router.post('/:id/rollback', authMiddleware, applicationController.rollbackApplication);

// Delete application
router.delete('/:id', authMiddleware, applicationController.deleteApplication);

${config.useTypeScript ? 'export const applicationRoutes = router;' : 'module.exports = { applicationRoutes: router };'}
`;

  fs.writeFileSync(
    path.join(config.backendDir, `src/api/routes/applicationRoutes.${extension}`),
    applicationRoutesFile
  );
  
  // Auth routes
  const authRoutesFile = `
${config.useTypeScript ? 'import { Router } from \'express\';' : 'const { Router } = require(\'express\');'}
${config.useTypeScript ? 'import { authController } from \'../controllers/authController\';' : 'const { authController } = require(\'../controllers/authController\');'}
${config.useTypeScript ? 'import { authMiddleware } from \'../middlewares/authMiddleware\';' : 'const { authMiddleware } = require(\'../middlewares/authMiddleware\');'}

const router = Router();

// Register new user
router.post('/register', authController.register);

// Login
router.post('/login', authController.login);

// Get current user
router.get('/me', authMiddleware, authController.getCurrentUser);

// Logout
router.post('/logout', authMiddleware, authController.logout);

${config.useTypeScript ? 'export const authRoutes = router;' : 'module.exports = { authRoutes: router };'}
`;

  fs.writeFileSync(
    path.join(config.backendDir, `src/api/routes/authRoutes.${extension}`),
    authRoutesFile
  );
  
  // Create controllers
  createControllers();
}

/**
 * Create controllers
 */
function createControllers() {
  console.log('Creating controllers...');
  
  const extension = config.useTypeScript ? 'ts' : 'js';
  
  // Prompt controller
  const promptControllerFile = `
${config.useTypeScript ? 'import { Request, Response, NextFunction } from \'express\';' : ''}
${config.useTypeScript ? 'import { Prompt } from \'../../models/Prompt\';' : 'const { Prompt } = require(\'../../models/Prompt\');'}
${config.useTypeScript ? 'import { promptService } from \'../../services/promptService\';' : 'const { promptService } = require(\'../../services/promptService\');'}

${config.useTypeScript ? 'interface AuthRequest extends Request { user?: any }' : ''}

const getPrompts = async (req${config.useTypeScript ? ': AuthRequest' : ''}, res${config.useTypeScript ? ': Response' : ''}, next${config.useTypeScript ? ': NextFunction' : ''}) => {
  try {
    const userId = req.user.id;
    const prompts = await promptService.getPromptsByUserId(userId);
    res.status(200).json(prompts);
  } catch (error) {
    next(error);
  }
};

const getPromptById = async (req${config.useTypeScript ? ': AuthRequest' : ''}, res${config.useTypeScript ? ': Response' : ''}, next${config.useTypeScript ? ': NextFunction' : ''}) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const prompt = await promptService.getPromptById(id, userId);
    
    if (!prompt) {
      return res.status(404).json({ message: 'Prompt not found' });
    }
    
    res.status(200).json(prompt);
  } catch (error) {
    next(error);
  }
};

const createPrompt = async (req${config.useTypeScript ? ': AuthRequest' : ''}, res${config.useTypeScript ? ': Response' : ''}, next${config.useTypeScript ? ': NextFunction' : ''}) => {
  try {
    const { text, appType, techPreferences } = req.body;
    const userId = req.user.id;
    
    if (!text) {
      return res.status(400).json({ message: 'Prompt text is required' });
    }
    
    const prompt = await promptService.createPrompt({
      text,
      appType,
      techPreferences,
      userId
    });
    
    res.status(201).json(prompt);
  } catch (error) {
    next(error);
  }
};

const updatePrompt = async (req${config.useTypeScript ? ': AuthRequest' : ''}, res${config.useTypeScript ? ': Response' : ''}, next${config.useTypeScript ? ': NextFunction' : ''}) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const updates = req.body;
    
    const prompt = await promptService.updatePrompt(id, updates, userId);
    
    if (!prompt) {
      return res.status(404).json({ message: 'Prompt not found' });
    }
    
    res.status(200).json(prompt);
  } catch (error) {
    next(error);
  }
};

const deletePrompt = async (req${config.useTypeScript ? ': AuthRequest' : ''}, res${config.useTypeScript ? ': Response' : ''}, next${config.useTypeScript ? ': NextFunction' : ''}) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    
    const success = await promptService.deletePrompt(id, userId);
    
    if (!success) {
      return res.status(404).json({ message: 'Prompt not found' });
    }
    
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

${config.useTypeScript ? 'export const promptController = { getPrompts, getPromptById, createPrompt, updatePrompt, deletePrompt };' : 'module.exports = { promptController: { getPrompts, getPromptById, createPrompt, updatePrompt, deletePrompt } };'}
`;

  fs.writeFileSync(
    path.join(config.backendDir, `src/api/controllers/promptController.${extension}`),
    promptControllerFile
  );
  
  // Application controller
  c
(Content truncated due to size limit. Use line ranges to read in chunks)
const express = require('express');
const router = express.Router();
const appController = require('../controllers/app.controller');
const authMiddleware = require('../middleware/auth.middleware');

// Apply auth middleware to all app routes
router.use(authMiddleware.verifyToken);

// App routes
router.get('/', appController.getAllApps);
router.post('/', appController.createApp);
router.get('/:id', appController.getAppById);
router.put('/:id', appController.updateApp);
router.delete('/:id', appController.deleteApp);
router.get('/:id/deployments', appController.getAppDeployments);
router.post('/:id/deploy', appController.deployApp);
router.get('/:id/download', appController.downloadApp);
router.post('/:id/clone', appController.cloneApp);

// WordPress specific routes
router.get('/wordpress/themes', appController.getWordPressThemes);
router.get('/wordpress/plugins', appController.getWordPressPlugins);
router.post('/wordpress/themes/:id/download', appController.downloadWordPressTheme);
router.post('/wordpress/plugins/:id/download', appController.downloadWordPressPlugin);

// Browser extension routes
router.get('/extensions/browser', appController.getBrowserExtensions);
router.post('/extensions/browser/:id/download', appController.downloadBrowserExtension);

// CMS plugin routes
router.get('/extensions/cms', appController.getCmsPlugins);
router.post('/extensions/cms/:id/download', appController.downloadCmsPlugin);

module.exports = router;

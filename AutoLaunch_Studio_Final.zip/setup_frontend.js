#!/usr/bin/env node

/**
 * AutoLaunch Studio Frontend Setup Script
 * 
 * This script sets up the frontend component of AutoLaunch Studio
 * with React and necessary dependencies.
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuration
const config = {
  projectRoot: '/home/ubuntu/autolaunch_studio',
  frontendDir: '/home/ubuntu/autolaunch_studio/frontend',
  templateDir: '/home/ubuntu/autolaunch_studio/templates/react',
  useTypeScript: true,
  useNextJs: true,
  uiFramework: 'chakra-ui'
};

/**
 * Main function to set up the frontend
 */
async function setupFrontend() {
  console.log('🚀 Setting up AutoLaunch Studio Frontend...');
  
  try {
    // Create frontend directory if it doesn't exist
    if (!fs.existsSync(config.frontendDir)) {
      fs.mkdirSync(config.frontendDir, { recursive: true });
    }
    
    // Initialize Next.js project with TypeScript
    if (config.useNextJs) {
      console.log('Initializing Next.js project with TypeScript...');
      process.chdir(config.projectRoot);
      execSync(`npx create-next-app@latest frontend --typescript --eslint --tailwind --app --src-dir --import-alias "@/*"`, { stdio: 'inherit' });
    } else {
      // Initialize React project with TypeScript
      console.log('Initializing React project with TypeScript...');
      process.chdir(config.projectRoot);
      execSync(`npx create-react-app frontend --template typescript`, { stdio: 'inherit' });
    }
    
    // Install additional dependencies
    console.log('Installing additional dependencies...');
    process.chdir(config.frontendDir);
    
    // Install UI framework
    if (config.uiFramework === 'chakra-ui') {
      execSync(`npm install @chakra-ui/react @emotion/react @emotion/styled framer-motion`, { stdio: 'inherit' });
    } else if (config.uiFramework === 'material-ui') {
      execSync(`npm install @mui/material @emotion/react @emotion/styled`, { stdio: 'inherit' });
    }
    
    // Install common dependencies
    execSync(`npm install axios react-router-dom react-hook-form react-query zustand`, { stdio: 'inherit' });
    
    // Create component templates
    createComponentTemplates();
    
    // Create page templates
    createPageTemplates();
    
    // Create API service
    createApiService();
    
    // Create store
    createStore();
    
    // Update package.json scripts
    updatePackageJson();
    
    console.log('✅ Frontend setup completed successfully!');
    console.log(`You can start the development server by running: cd ${config.frontendDir} && npm run dev`);
    
    return { success: true };
  } catch (error) {
    console.error('Frontend setup failed:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Create component templates
 */
function createComponentTemplates() {
  console.log('Creating component templates...');
  
  const componentsDir = path.join(config.frontendDir, 'src/components');
  fs.mkdirSync(componentsDir, { recursive: true });
  
  // Create Button component
  const buttonComponent = `
import React from 'react';
import { Button as ChakraButton, ButtonProps } from '@chakra-ui/react';

interface CustomButtonProps extends ButtonProps {
  variant?: 'primary' | 'secondary' | 'outline';
}

export const Button: React.FC<CustomButtonProps> = ({ 
  children, 
  variant = 'primary', 
  ...props 
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return {
          bg: 'blue.500',
          color: 'white',
          _hover: { bg: 'blue.600' }
        };
      case 'secondary':
        return {
          bg: 'gray.200',
          color: 'gray.800',
          _hover: { bg: 'gray.300' }
        };
      case 'outline':
        return {
          bg: 'transparent',
          color: 'blue.500',
          border: '1px solid',
          borderColor: 'blue.500',
          _hover: { bg: 'blue.50' }
        };
      default:
        return {};
    }
  };

  return (
    <ChakraButton {...getVariantStyles()} {...props}>
      {children}
    </ChakraButton>
  );
};
`;

  fs.writeFileSync(path.join(componentsDir, 'Button.tsx'), buttonComponent);
  
  // Create Card component
  const cardComponent = `
import React from 'react';
import { Box, BoxProps } from '@chakra-ui/react';

interface CardProps extends BoxProps {
  variant?: 'elevated' | 'outline' | 'filled';
}

export const Card: React.FC<CardProps> = ({ 
  children, 
  variant = 'elevated', 
  ...props 
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'elevated':
        return {
          boxShadow: 'md',
          bg: 'white'
        };
      case 'outline':
        return {
          border: '1px solid',
          borderColor: 'gray.200'
        };
      case 'filled':
        return {
          bg: 'gray.100'
        };
      default:
        return {};
    }
  };

  return (
    <Box 
      borderRadius="md" 
      p={4} 
      {...getVariantStyles()} 
      {...props}
    >
      {children}
    </Box>
  );
};
`;

  fs.writeFileSync(path.join(componentsDir, 'Card.tsx'), cardComponent);
  
  // Create Form component
  const formComponent = `
import React from 'react';
import { 
  Box, 
  FormControl, 
  FormLabel, 
  FormErrorMessage, 
  Input, 
  Textarea,
  Select,
  Button,
  VStack
} from '@chakra-ui/react';
import { useForm, Controller, FieldValues, SubmitHandler } from 'react-hook-form';

interface FormField {
  name: string;
  label: string;
  type: 'text' | 'textarea' | 'select' | 'number' | 'email' | 'password';
  placeholder?: string;
  options?: { value: string; label: string }[];
  required?: boolean;
  validation?: Record<string, any>;
}

interface FormProps<T extends FieldValues> {
  fields: FormField[];
  onSubmit: SubmitHandler<T>;
  submitLabel?: string;
  defaultValues?: Partial<T>;
}

export function Form<T extends FieldValues>({ 
  fields, 
  onSubmit, 
  submitLabel = 'Submit', 
  defaultValues = {} 
}: FormProps<T>) {
  const { 
    control, 
    handleSubmit, 
    formState: { errors, isSubmitting } 
  } = useForm<T>({ defaultValues: defaultValues as T });

  return (
    <Box as="form" onSubmit={handleSubmit(onSubmit)} width="100%">
      <VStack spacing={4} align="flex-start">
        {fields.map((field) => (
          <Controller
            key={field.name}
            name={field.name as any}
            control={control}
            rules={field.validation}
            render={({ field: { onChange, value, ref } }) => (
              <FormControl isInvalid={!!errors[field.name]}>
                <FormLabel htmlFor={field.name}>{field.label}</FormLabel>
                
                {field.type === 'textarea' ? (
                  <Textarea
                    id={field.name}
                    placeholder={field.placeholder}
                    onChange={onChange}
                    value={value || ''}
                    ref={ref}
                  />
                ) : field.type === 'select' ? (
                  <Select
                    id={field.name}
                    placeholder={field.placeholder}
                    onChange={onChange}
                    value={value || ''}
                    ref={ref}
                  >
                    {field.options?.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </Select>
                ) : (
                  <Input
                    id={field.name}
                    type={field.type}
                    placeholder={field.placeholder}
                    onChange={onChange}
                    value={value || ''}
                    ref={ref}
                  />
                )}
                
                <FormErrorMessage>
                  {errors[field.name]?.message as string}
                </FormErrorMessage>
              </FormControl>
            )}
          />
        ))}
        
        <Button
          type="submit"
          colorScheme="blue"
          isLoading={isSubmitting}
          width="full"
        >
          {submitLabel}
        </Button>
      </VStack>
    </Box>
  );
}
`;

  fs.writeFileSync(path.join(componentsDir, 'Form.tsx'), formComponent);
  
  // Create index file to export all components
  const indexFile = `
export * from './Button';
export * from './Card';
export * from './Form';
`;

  fs.writeFileSync(path.join(componentsDir, 'index.ts'), indexFile);
}

/**
 * Create page templates
 */
function createPageTemplates() {
  console.log('Creating page templates...');
  
  if (config.useNextJs) {
    // For Next.js app router
    const appDir = path.join(config.frontendDir, 'src/app');
    
    // Create prompt submission page
    const promptPage = `
import { Form } from '@/components';
import { Box, Container, Heading, Text, VStack } from '@chakra-ui/react';

export default function PromptSubmission() {
  const handleSubmit = async (data: any) => {
    console.log('Submitting prompt:', data);
    // TODO: Implement API call to submit prompt
  };

  const formFields = [
    {
      name: 'prompt',
      label: 'Application Description',
      type: 'textarea' as const,
      placeholder: 'Describe the application you want to build...',
      required: true,
      validation: {
        required: 'Application description is required',
        minLength: {
          value: 50,
          message: 'Description should be at least 50 characters'
        }
      }
    },
    {
      name: 'appType',
      label: 'Application Type',
      type: 'select' as const,
      options: [
        { value: 'web', label: 'Web Application' },
        { value: 'mobile', label: 'Mobile Application' },
        { value: 'desktop', label: 'Desktop Application' }
      ],
      required: true,
      validation: {
        required: 'Application type is required'
      }
    },
    {
      name: 'techPreferences',
      label: 'Technology Preferences (Optional)',
      type: 'text' as const,
      placeholder: 'e.g., React, Node.js, PostgreSQL'
    }
  ];

  return (
    <Container maxW="container.md" py={8}>
      <VStack spacing={8} align="flex-start">
        <Box>
          <Heading as="h1" size="xl">Create New Application</Heading>
          <Text mt={2} color="gray.600">
            Describe your application and AutoLaunch Studio will build it for you.
          </Text>
        </Box>
        
        <Form 
          fields={formFields}
          onSubmit={handleSubmit}
          submitLabel="Generate Application"
        />
      </VStack>
    </Container>
  );
}
`;

    // Create the prompt submission page directory
    const promptPageDir = path.join(appDir, 'create');
    fs.mkdirSync(promptPageDir, { recursive: true });
    fs.writeFileSync(path.join(promptPageDir, 'page.tsx'), promptPage);
    
    // Create dashboard page
    const dashboardPage = `
import { Card } from '@/components';
import { 
  Box, 
  Container, 
  Heading, 
  Text, 
  SimpleGrid, 
  Flex, 
  Badge, 
  Button,
  Icon
} from '@chakra-ui/react';

// Mock data for applications
const applications = [
  {
    id: '1',
    name: 'Customer Portal',
    status: 'deployed',
    url: 'https://customer-portal.example.com',
    createdAt: '2025-03-15',
    type: 'web'
  },
  {
    id: '2',
    name: 'Inventory Management',
    status: 'building',
    createdAt: '2025-03-20',
    type: 'web'
  },
  {
    id: '3',
    name: 'Analytics Dashboard',
    status: 'failed',
    createdAt: '2025-03-22',
    type: 'web'
  }
];

export default function Dashboard() {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'deployed':
        return <Badge colorScheme="green">Deployed</Badge>;
      case 'building':
        return <Badge colorScheme="blue">Building</Badge>;
      case 'failed':
        return <Badge colorScheme="red">Failed</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  return (
    <Container maxW="container.xl" py={8}>
      <Flex justify="space-between" align="center" mb={8}>
        <Box>
          <Heading as="h1" size="xl">My Applications</Heading>
          <Text mt={2} color="gray.600">
            Manage your AutoLaunch Studio applications
          </Text>
        </Box>
        <Button colorScheme="blue" as="a" href="/create">
          Create New App
        </Button>
      </Flex>
      
      <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
        {applications.map((app) => (
          <Card key={app.id} variant="elevated">
            <Flex direction="column" height="100%">
              <Flex justify="space-between" mb={3}>
                <Heading as="h3" size="md">{app.name}</Heading>
                {getStatusBadge(app.status)}
              </Flex>
              
              <Text color="gray.600" mb={4}>
                Type: {app.type.charAt(0).toUpperCase() + app.type.slice(1)}
              </Text>
              
              <Text color="gray.600" mb={4}>
                Created: {new Date(app.createdAt).toLocaleDateString()}
              </Text>
              
              <Flex mt="auto" justify="space-between">
                {app.status === 'deployed' && (
                  <Button size="sm" as="a" href={app.url} target="_blank">
                    View App
                  </Button>
                )}
                <Button size="sm" variant="outline">
                  Manage
                </Button>
              </Flex>
            </Flex>
          </Card>
        ))}
      </SimpleGrid>
    </Container>
  );
}
`;

    // Create the dashboard page directory
    const dashboardPageDir = path.join(appDir, 'dashboard');
    fs.mkdirSync(dashboardPageDir, { recursive: true });
    fs.writeFileSync(path.join(dashboardPageDir, 'page.tsx'), dashboardPage);
    
    // Update root layout to use Chakra UI
    const layoutFile = `
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ChakraProvider, Box, Flex } from '@chakra-ui/react';
import Navbar from '@/components/Navbar';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'AutoLaunch Studio',
  description: 'AI-powered automated application generator',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ChakraProvider>
          <Flex direction="column" minHeight="100vh">
            <Navbar />
            <Box as="main" flex="1">
              {children}
            </Box>
          </Flex>
        </ChakraProvider>
      </body>
    </html>
  );
}
`;

    fs.writeFileSync(path.join(appDir, 'layout.tsx'), layoutFile);
    
    // Create Navbar component
    const navbarComponent = `
import { 
  Box, 
  Flex, 
  Text, 
  Button, 
  Stack, 
  Collapse, 
  Icon, 
  Link, 
  Popover, 
  PopoverTrigger, 
  PopoverContent, 
  useColorModeValue, 
  useDisclosure 
} from '@chakra-ui/react';
import NextLink from 'next/link';

export default function Navbar() {
  const { isOpen, onToggle } = useDisclosure();

  return (
    <Box>
      <Flex
        bg={useColorModeValue('white', 'gray.800')}
        color={useColorModeValue('gray.600', 'white')}
        minH={'60px'}
        py={{ base: 2 }}
        px={{ base: 4 }}
        borderBottom={1}
        borderStyle={'solid'}
        borderColor={useColorModeValue('gray.200', 'gray.900')}
        align={'center'}
      >
        <Flex
          flex={{ base: 1, md: 'auto' }}
          ml={{ base: -2 }}
          display={{ base: 'flex', md: 'none' }}
        >
          <Button
            onClick={onToggle}
            variant={'ghost'}
            aria-label={'Toggle Navigation'}
          >
            Menu
          </Button>
        </Flex>
        <Flex flex={{ base: 1 }} justify=
(Content truncated due to size limit. Use line ranges to read in chunks)
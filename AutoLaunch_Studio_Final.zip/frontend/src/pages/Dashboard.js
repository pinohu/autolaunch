import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  Button, 
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  Divider,
  CircularProgress,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions
} from '@mui/material';
import { 
  Add as AddIcon,
  Search as SearchIcon,
  FilterList as FilterIcon,
  MoreVert as MoreVertIcon,
  Refresh as RefreshIcon,
  WebOutlined,
  PhoneAndroidOutlined,
  ExtensionOutlined,
  ShoppingCartOutlined,
  CodeOutlined,
  DesktopWindowsOutlined,
  WordPress,
  SettingsOutlined,
  CloudOutlined,
  OpenInNew,
  GitHub,
  CloudDownload
} from '@mui/icons-material';
import { toast } from 'react-toastify';

// Mock data for demonstration
const mockApps = [
  {
    id: '1',
    name: 'E-Commerce Dashboard',
    description: 'Admin dashboard for managing products and orders',
    type: 'web',
    status: 'deployed',
    liveUrl: 'https://apps.autolaunchstudio.com/ecommerce-dashboard',
    githubUrl: 'https://github.com/autolaunch/ecommerce-dashboard',
    createdAt: '2025-03-25T10:30:00Z',
    deployedAt: '2025-03-25T11:45:00Z'
  },
  {
    id: '2',
    name: 'Fitness Tracker',
    description: 'Mobile app for tracking workouts and nutrition',
    type: 'mobile',
    status: 'deployed',
    liveUrl: 'https://apps.autolaunchstudio.com/fitness-tracker',
    githubUrl: 'https://github.com/autolaunch/fitness-tracker',
    createdAt: '2025-03-20T14:15:00Z',
    deployedAt: '2025-03-20T16:30:00Z'
  },
  {
    id: '3',
    name: 'Content Manager',
    description: 'WordPress plugin for advanced content management',
    type: 'wp-plugin',
    status: 'deployed',
    liveUrl: 'https://apps.autolaunchstudio.com/content-manager',
    githubUrl: 'https://github.com/autolaunch/content-manager',
    createdAt: '2025-03-18T09:45:00Z',
    deployedAt: '2025-03-18T11:20:00Z'
  },
  {
    id: '4',
    name: 'Modern Portfolio',
    description: 'WordPress theme for creative professionals',
    type: 'wordpress',
    status: 'building',
    liveUrl: null,
    githubUrl: null,
    createdAt: '2025-03-29T16:20:00Z',
    deployedAt: null
  },
  {
    id: '5',
    name: 'SEO Helper',
    description: 'Browser extension for SEO analysis',
    type: 'browser-ext',
    status: 'deployed',
    liveUrl: 'https://apps.autolaunchstudio.com/seo-helper',
    githubUrl: 'https://github.com/autolaunch/seo-helper',
    createdAt: '2025-03-15T11:10:00Z',
    deployedAt: '2025-03-15T13:25:00Z'
  },
  {
    id: '6',
    name: 'Inventory API',
    description: 'RESTful API for inventory management',
    type: 'api',
    status: 'failed',
    liveUrl: null,
    githubUrl: 'https://github.com/autolaunch/inventory-api',
    createdAt: '2025-03-10T08:30:00Z',
    deployedAt: null
  }
];

// App type icons mapping
const appTypeIcons = {
  'web': <WebOutlined />,
  'mobile': <PhoneAndroidOutlined />,
  'desktop': <DesktopWindowsOutlined />,
  'ecommerce': <ShoppingCartOutlined />,
  'api': <CloudOutlined />,
  'wordpress': <WordPress />,
  'wp-plugin': <ExtensionOutlined />,
  'browser-ext': <CodeOutlined />,
  'cms-plugin': <SettingsOutlined />
};

// App type names mapping
const appTypeNames = {
  'web': 'Web Application',
  'mobile': 'Mobile App',
  'desktop': 'Desktop App',
  'ecommerce': 'E-Commerce',
  'api': 'API / Backend',
  'wordpress': 'WordPress Theme',
  'wp-plugin': 'WordPress Plugin',
  'browser-ext': 'Browser Extension',
  'cms-plugin': 'CMS Plugin'
};

// Status chip colors
const statusColors = {
  'deployed': 'success',
  'building': 'warning',
  'failed': 'error',
  'draft': 'default'
};

function Dashboard() {
  const location = useLocation();
  const navigate = useNavigate();
  const [apps, setApps] = useState([]);
  const [filteredApps, setFilteredApps] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [activeFilters, setActiveFilters] = useState([]);
  const [actionAnchorEl, setActionAnchorEl] = useState(null);
  const [selectedAppId, setSelectedAppId] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [appToDelete, setAppToDelete] = useState(null);

  // Load apps on component mount
  useEffect(() => {
    const fetchApps = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Use mock data
        setApps(mockApps);
        setFilteredApps(mockApps);
      } catch (error) {
        toast.error('Failed to load apps: ' + error.message);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchApps();
    
    // Check if we just created a new app
    if (location.state?.newApp) {
      toast.success('Your new app is being built! It will appear here shortly.');
    }
  }, [location.state]);

  // Handle search
  useEffect(() => {
    if (searchTerm.trim() === '' && activeFilters.length === 0) {
      setFilteredApps(apps);
      return;
    }
    
    let filtered = apps;
    
    // Apply search term filter
    if (searchTerm.trim() !== '') {
      filtered = filtered.filter(app => 
        app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Apply type filters
    if (activeFilters.length > 0) {
      filtered = filtered.filter(app => activeFilters.includes(app.type));
    }
    
    setFilteredApps(filtered);
  }, [searchTerm, activeFilters, apps]);

  // Handle filter menu
  const handleFilterClick = (event) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleFilterToggle = (filter) => {
    if (activeFilters.includes(filter)) {
      setActiveFilters(activeFilters.filter(f => f !== filter));
    } else {
      setActiveFilters([...activeFilters, filter]);
    }
  };

  const clearFilters = () => {
    setActiveFilters([]);
    setFilterAnchorEl(null);
  };

  // Handle app actions menu
  const handleActionClick = (event, appId) => {
    setActionAnchorEl(event.currentTarget);
    setSelectedAppId(appId);
  };

  const handleActionClose = () => {
    setActionAnchorEl(null);
    setSelectedAppId(null);
  };

  // Handle app deletion
  const handleDeleteClick = () => {
    const app = apps.find(app => app.id === selectedAppId);
    setAppToDelete(app);
    setDeleteDialogOpen(true);
    handleActionClose();
  };

  const handleDeleteConfirm = async () => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Remove app from state
      setApps(apps.filter(app => app.id !== appToDelete.id));
      setFilteredApps(filteredApps.filter(app => app.id !== appToDelete.id));
      
      toast.success(`${appToDelete.name} has been deleted.`);
    } catch (error) {
      toast.error('Failed to delete app: ' + error.message);
    } finally {
      setDeleteDialogOpen(false);
      setAppToDelete(null);
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setAppToDelete(null);
  };

  // Handle refresh
  const handleRefresh = async () => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Use mock data
      setApps(mockApps);
      setFilteredApps(mockApps);
      
      toast.success('Apps refreshed successfully.');
    } catch (error) {
      toast.error('Failed to refresh apps: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4, mt: 4 }}>
        <Typography variant="h4" component="h1">
          My Applications
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => navigate('/create')}
        >
          Create New App
        </Button>
      </Box>
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <TextField
          placeholder="Search applications..."
          variant="outlined"
          size="small"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{ width: '40%' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
        
        <Box>
          {activeFilters.length > 0 && (
            <Box sx={{ display: 'inline-flex', mr: 2 }}>
              <Chip 
                label={`${activeFilters.length} filter${activeFilters.length > 1 ? 's' : ''} active`} 
                onDelete={clearFilters}
                color="primary"
                variant="outlined"
              />
            </Box>
          )}
          
          <IconButton onClick={handleFilterClick} color="primary">
            <FilterIcon />
          </IconButton>
          
          <Menu
            anchorEl={filterAnchorEl}
            open={Boolean(filterAnchorEl)}
            onClose={handleFilterClose}
          >
            <MenuItem disabled>
              <Typography variant="subtitle2">Filter by Type</Typography>
            </MenuItem>
            <Divider />
            {Object.entries(appTypeNames).map(([key, name]) => (
              <MenuItem key={key} onClick={() => handleFilterToggle(key)}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  {appTypeIcons[key]}
                  <Typography sx={{ ml: 1 }}>{name}</Typography>
                  {activeFilters.includes(key) && (
                    <Box sx={{ ml: 1, color: 'primary.main' }}>✓</Box>
                  )}
                </Box>
              </MenuItem>
            ))}
            <Divider />
            <MenuItem onClick={clearFilters}>
              <Typography color="primary">Clear Filters</Typography>
            </MenuItem>
          </Menu>
          
          <IconButton onClick={handleRefresh} color="primary" disabled={isLoading}>
            <RefreshIcon />
          </IconButton>
        </Box>
      </Box>
      
      {isLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 8 }}>
          <CircularProgress />
        </Box>
      ) : filteredApps.length === 0 ? (
        <Box sx={{ textAlign: 'center', my: 8 }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No applications found
          </Typography>
          <Typography variant="body1" color="text.secondary">
            {searchTerm || activeFilters.length > 0 
              ? 'Try adjusting your search or filters'
              : 'Create your first application to get started'}
          </Typography>
          {(!searchTerm && activeFilters.length === 0) && (
            <Button
              variant="contained"
              color="primary"
              startIcon={<AddIcon />}
              onClick={() => navigate('/create')}
              sx={{ mt: 2 }}
            >
              Create New App
            </Button>
          )}
        </Box>
      ) : (
        <Grid container spacing={3}>
          {filteredApps.map((app) => (
            <Grid item xs={12} sm={6} md={4} key={app.id}>
              <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                <CardContent sx={{ flexGrow: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <Chip
                      icon={appTypeIcons[app.type]}
                      label={appTypeNames[app.type]}
                      size="small"
                      sx={{ mb: 2 }}
                    />
                    <Chip
                      label={app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                      size="small"
                      color={statusColors[app.status]}
                    />
                  </Box>
                  
                  <Typography variant="h6" component="h2" gutterBottom>
                    {app.name}
                  </Typography>
                  
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {app.description}
                  </Typography>
                  
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                    <Typography variant="caption" color="text.secondary">
                      Created: {formatDate(app.createdAt)}
                    </Typography>
                    {app.deployedAt && (
                      <Typography variant="caption" color="text.secondary">
                        Deployed: {formatDate(app.deployedAt)}
                      </Typography>
                    )}
                  </Box>
                </CardContent>
                
                <CardActions sx={{ justifyContent: 'space-between', p: 2, pt: 0 }}>
                  <Button 
                    size="small" 
                    onClick={() => navigate(`/apps/${app.id}`)}
                  >
                    View Details
                  </Button>
                  
                  <Box>
                    {app.liveUrl && (
                      <IconButton 
                        size="small" 
                        color="primary"
                        href={app.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Open live app"
                      >
                        <OpenInNew fontSize="small" />
                      </IconButton>
                    )}
                    
                    {app.githubUrl && (
                      <IconButton 
                        size="small" 
                        color="primary"
                        href={app.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        title="View on GitHub"
                      >
                        <GitHub fontSize="small" />
                      </IconButton>
                    )}
                    
                    {app.status === 'deployed' && (
                      <IconButton 
                        size="small" 
                        color="primary"
                        title="Download app"
                      >
                        <CloudDownload fontSize="small" />
                      </IconButton>
                    )}
                    
                    <IconButton 
                      size="small"
                      onClick={(e) => handleActionClick(e, app.id)}
                    >
                      <MoreVertIcon fontSize="small" />
                    </IconButton>
                  </Box>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
      
      {/* App Actions Menu */}
      <Menu
        anchorEl={actionAnchorEl}
        open={Boolean(actionAnchorEl)}
        onClose={handleActionClose}
      >
        <MenuItem onClick={() => {
          navigate(`/apps/${selectedAppId}`);
          handleActionClose();
        }}>
          View Details
        </MenuItem>
        {apps.find(app => app.id === selectedAppId)?.status === 'deployed' && (
          <MenuItem onClick={handleActionClose}>
            Redeploy
          </MenuItem>
        )}
        {apps.find(app => app.id === selectedAppId)?.status === 'failed' && (
          <MenuItem onClick={handleActionClose}>
            Retry Deployment
          </MenuItem>
        )}
        <MenuItem onClick={handleActionClose}>
          Clone App
        </MenuItem>
        <Divider />
        <MenuItem onClick={handleDeleteClick} sx={{ color: 'error.main' }}>
          Delete App
        </MenuItem>
      </Menu>
      
      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
      >
        <DialogTitle>Delete Application</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete "{appToDelete?.name}"? This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel}>Cancel</Button>
          <Button onClick={handleDeleteConfirm} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default Dashboard;

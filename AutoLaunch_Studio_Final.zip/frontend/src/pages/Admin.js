import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Tabs,
  Tab,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  Switch,
  Divider
} from '@mui/material';
import {
  Person,
  Security,
  Settings,
  Visibility,
  Edit,
  Delete,
  CheckCircle,
  Error,
  Warning,
  Info,
  Refresh,
  CloudDownload,
  History,
  Add as AddIcon,
  FilterList as FilterIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { toast } from 'react-toastify';

// Mock data for users
const mockUsers = [
  { id: 1, name: 'Admin User', email: 'admin@example.com', role: 'admin', status: 'active', lastLogin: '2025-03-29T15:30:00Z' },
  { id: 2, name: 'Developer One', email: 'dev1@example.com', role: 'developer', status: 'active', lastLogin: '2025-03-28T10:15:00Z' },
  { id: 3, name: 'Developer Two', email: 'dev2@example.com', role: 'developer', status: 'inactive', lastLogin: '2025-03-20T09:45:00Z' },
  { id: 4, name: 'Viewer User', email: 'viewer@example.com', role: 'viewer', status: 'active', lastLogin: '2025-03-29T12:20:00Z' }
];

// Mock data for deployments
const mockDeployments = [
  { id: 1, appName: 'E-Commerce Dashboard', version: '1.0.0', status: 'success', deployedBy: 'Admin User', deployedAt: '2025-03-25T11:45:00Z', environment: 'production' },
  { id: 2, appName: 'Fitness Tracker', version: '1.2.1', status: 'success', deployedBy: 'Developer One', deployedAt: '2025-03-20T16:30:00Z', environment: 'production' },
  { id: 3, appName: 'Content Manager', version: '2.0.0', status: 'success', deployedBy: 'Admin User', deployedAt: '2025-03-18T11:20:00Z', environment: 'production' },
  { id: 4, appName: 'Inventory API', version: '0.9.0', status: 'failed', deployedBy: 'Developer Two', deployedAt: '2025-03-10T08:30:00Z', environment: 'staging' },
  { id: 5, appName: 'Modern Portfolio', version: '1.0.0', status: 'pending', deployedBy: 'Admin User', deployedAt: '2025-03-29T16:20:00Z', environment: 'staging' }
];

// Mock data for logs
const mockLogs = [
  { id: 1, level: 'info', message: 'User Admin User logged in', timestamp: '2025-03-30T14:30:00Z', source: 'auth' },
  { id: 2, level: 'info', message: 'Deployment of E-Commerce Dashboard v1.0.0 started', timestamp: '2025-03-25T11:30:00Z', source: 'deployment' },
  { id: 3, level: 'success', message: 'Deployment of E-Commerce Dashboard v1.0.0 completed successfully', timestamp: '2025-03-25T11:45:00Z', source: 'deployment' },
  { id: 4, level: 'error', message: 'Deployment of Inventory API v0.9.0 failed: Build error', timestamp: '2025-03-10T08:35:00Z', source: 'deployment' },
  { id: 5, level: 'warning', message: 'High CPU usage detected on server', timestamp: '2025-03-29T10:15:00Z', source: 'system' },
  { id: 6, level: 'info', message: 'User Developer One created new app: Modern Portfolio', timestamp: '2025-03-29T16:10:00Z', source: 'app' }
];

// Mock data for system settings
const mockSettings = {
  general: {
    siteName: 'AutoLaunch Studio',
    siteUrl: 'https://apps.autolaunchstudio.com',
    adminEmail: 'admin@autolaunchstudio.com',
    maxAppsPerUser: 10
  },
  deployment: {
    defaultEnvironment: 'staging',
    autoDeployEnabled: true,
    requireApproval: true,
    notifyOnDeployment: true
  },
  security: {
    sessionTimeout: 60,
    maxLoginAttempts: 5,
    twoFactorAuth: false,
    passwordExpiration: 90
  },
  integrations: {
    githubEnabled: true,
    githubOrg: 'autolaunch',
    cursorAiEnabled: true,
    analyticsEnabled: true
  }
};

function Admin() {
  const [tabValue, setTabValue] = useState(0);
  const [users, setUsers] = useState([]);
  const [deployments, setDeployments] = useState([]);
  const [logs, setLogs] = useState([]);
  const [settings, setSettings] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [userDialogOpen, setUserDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [confirmAction, setConfirmAction] = useState({ type: '', id: null });
  const [settingsEdited, setSettingsEdited] = useState(false);

  // Load data on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Simulate API calls
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Use mock data
        setUsers(mockUsers);
        setDeployments(mockDeployments);
        setLogs(mockLogs);
        setSettings(mockSettings);
      } catch (error) {
        toast.error('Failed to load admin data: ' + error.message);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Handle user dialog
  const handleOpenUserDialog = (user = null) => {
    setSelectedUser(user || { name: '', email: '', role: 'developer', status: 'active' });
    setUserDialogOpen(true);
  };

  const handleCloseUserDialog = () => {
    setUserDialogOpen(false);
    setSelectedUser(null);
  };

  const handleSaveUser = () => {
    if (selectedUser.id) {
      // Update existing user
      setUsers(users.map(user => user.id === selectedUser.id ? selectedUser : user));
      toast.success(`User ${selectedUser.name} updated successfully.`);
    } else {
      // Create new user
      const newUser = {
        ...selectedUser,
        id: Math.max(...users.map(u => u.id)) + 1,
        lastLogin: null
      };
      setUsers([...users, newUser]);
      toast.success(`User ${newUser.name} created successfully.`);
    }
    handleCloseUserDialog();
  };

  // Handle user input change
  const handleUserInputChange = (e) => {
    const { name, value } = e.target;
    setSelectedUser({ ...selectedUser, [name]: value });
  };

  // Handle confirmation dialog
  const handleOpenConfirmDialog = (type, id) => {
    setConfirmAction({ type, id });
    setConfirmDialogOpen(true);
  };

  const handleCloseConfirmDialog = () => {
    setConfirmDialogOpen(false);
  };

  const handleConfirmAction = () => {
    const { type, id } = confirmAction;
    
    if (type === 'deleteUser') {
      setUsers(users.filter(user => user.id !== id));
      toast.success('User deleted successfully.');
    } else if (type === 'rollbackDeployment') {
      const deployment = deployments.find(d => d.id === id);
      toast.success(`Deployment of ${deployment.appName} v${deployment.version} rolled back successfully.`);
    } else if (type === 'approveDeployment') {
      setDeployments(deployments.map(d => d.id === id ? { ...d, status: 'success' } : d));
      toast.success('Deployment approved and completed successfully.');
    }
    
    handleCloseConfirmDialog();
  };

  // Handle settings change
  const handleSettingChange = (section, setting, value) => {
    setSettings({
      ...settings,
      [section]: {
        ...settings[section],
        [setting]: value
      }
    });
    setSettingsEdited(true);
  };

  const handleSaveSettings = () => {
    // Simulate API call
    setTimeout(() => {
      toast.success('Settings saved successfully.');
      setSettingsEdited(false);
    }, 500);
  };

  // Render tabs content
  const renderTabContent = () => {
    switch (tabValue) {
      case 0: // User Management
        return (
          <Box sx={{ mt: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6">User Management</Typography>
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => handleOpenUserDialog()}
              >
                Add User
              </Button>
            </Box>
            
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Role</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Last Login</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Chip 
                          label={user.role.charAt(0).toUpperCase() + user.role.slice(1)} 
                          color={user.role === 'admin' ? 'primary' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={user.status.charAt(0).toUpperCase() + user.status.slice(1)} 
                          color={user.status === 'active' ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>{user.lastLogin ? formatDate(user.lastLogin) : 'Never'}</TableCell>
                      <TableCell>
                        <IconButton size="small" onClick={() => handleOpenUserDialog(user)}>
                          <Edit fontSize="small" />
                        </IconButton>
                        <IconButton size="small" onClick={() => handleOpenConfirmDialog('deleteUser', user.id)}>
                          <Delete fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        );
      
      case 1: // Deployment Management
        return (
          <Box sx={{ mt: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6">Deployment Management</Typography>
              <Button
                variant="outlined"
                startIcon={<Refresh />}
              >
                Refresh
              </Button>
            </Box>
            
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>App Name</TableCell>
                    <TableCell>Version</TableCell>
                    <TableCell>Environment</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Deployed By</TableCell>
                    <TableCell>Deployed At</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {deployments.map((deployment) => (
                    <TableRow key={deployment.id}>
                      <TableCell>{deployment.appName}</TableCell>
                      <TableCell>{deployment.version}</TableCell>
                      <TableCell>{deployment.environment}</TableCell>
                      <TableCell>
                        <Chip 
                          label={deployment.status.charAt(0).toUpperCase() + deployment.status.slice(1)} 
                          color={
                            deployment.status === 'success' ? 'success' : 
                            deployment.status === 'failed' ? 'error' : 
                            'warning'
                          }
                          size="small"
                        />
                      </TableCell>
                      <TableCell>{deployment.deployedBy}</TableCell>
                      <TableCell>{formatDate(deployment.deployedAt)}</TableCell>
                      <TableCell>
                        {deployment.status === 'pending' && (
                          <IconButton 
                            size="small" 
                            color="primary"
                            onClick={() => handleOpenConfirmDialog('approveDeployment', deployment.id)}
                            title="Approve Deployment"
                          >
                            <CheckCircle fontSize="small" />
                          </IconButton>
                        )}
                        {deployment.status === 'success' && (
                          <IconButton 
                            size="small"
                            onClick={() => handleOpenConfirmDialog('rollbackDeployment', deployment.id)}
                            title="Rollback Deployment"
                          >
                            <History fontSize="small" />
                          </IconButton>
                        )}
                        <IconButton 
                          size="small"
                          title="Download Logs"
                        >
                          <CloudDownload fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        );
      
      case 2: // Logs and Feedback
        return (
          <Box sx={{ mt: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6">System Logs</Typography>
              <Box>
                <TextField
                  placeholder="Search logs..."
                  variant="outlined"
                  size="small"
                  sx={{ mr: 2 }}
                  InputProps={{
                    startAdornment: (
                      <SearchIcon fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
                    ),
                  }}
                />
                <Button
                  variant="outlined"
                  startIcon={<FilterIcon />}
                >
                  Filter
                </Button>
              </Box>
            </Box>
            
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Timestamp</TableCell>
                    <TableCell>Level</TableCell>
                    <TableCell>Source</TableCell>
                    <TableCell>Message</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {logs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>{formatDate(log.timestamp)}</TableCell>
                      <TableCell>
                        <Chip 
                          icon={
                            log.level === 'error' ? <Error fontSize="small" /> :
                            log.level === 'warning' ? <Warning fontSize="small" /> :
                            log.level === 'success' ? <CheckCircle fontSize="small" /> :
                            <Info fontSize="small" />
                          }
                          label={log.level.charAt(0).toUpperCase() + log.level.slice(1)} 
                          color={
                            log.level === 'error' ? 'error' : 
                            log.level === 'warning' ? 'warning' : 
                            log.level === 'success' ? 'success' : 
                            'info'
                          }
                          size="small"
                        />
                      </TableCell>
                      <TableCell>{log.source}</TableCell>
                      <TableCell>{log.message}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        );
      
      case 3: // System Settings
        return (
          <Box sx={{ mt: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6">System Settings</Typography>
              <Button
                variant="contained"
                color="primary"
                disabled={!settingsEdited}
                onClick={handleSaveSettings}
              >
                Save Changes
              </Button>
            </Box>
            
            <Grid container spacing={3}>
              {/* General Settings */}
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="General Settings" />
                  <CardContent>
                    <List>
                      <ListItem>
                        <ListItemText 
                          primary="Site Name" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              value={settings.general?.siteName || ''}
                              onChange={(e) => handleSettingChange('general', 'siteName', e.target.value)}
                            />
                          }
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Site URL" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              value={settings.general?.siteUrl || ''}
                              onChange={(e) => handleSettingChange('general', 'siteUrl', e.target.value)}
                            />
                          }
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Admin Email" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              value={settings.general?.adminEmail || ''}
                              onChange={(e) => handleSettingChange('general', 'adminEmail', e.target.value)}
                            />
                          }
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Max Apps Per User" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              type="number"
                              value={settings.general?.maxAppsPerUser || 0}
                              onChange={(e) => handleSettingChange('general', 'maxAppsPerUser', parseInt(e.target.value))}
                            />
                          }
                        />
                      </ListItem>
                    </List>
                  </CardContent>
                </Card>
              </Grid>
              
              {/* Deployment Settings */}
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Deployment Settings" />
                  <CardContent>
                    <List>
                      <ListItem>
                        <ListItemText 
                          primary="Default Environment" 
                          secondary={
                            <FormControl fullWidth margin="dense" size="small">
                              <Select
                                value={settings.deployment?.defaultEnvironment || 'staging'}
                                onChange={(e) => handleSettingChange('deployment', 'defaultEnvironment', e.target.value)}
                              >
                                <MenuItem value="development">Development</MenuItem>
                                <MenuItem value="staging">Staging</MenuItem>
                                <MenuItem value="production">Production</MenuItem>
                              </Select>
                            </FormControl>
                          }
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Auto-Deploy Enabled" 
                          secondary="Automatically deploy apps when created"
                        />
                        <ListItemSecondaryAction>
                          <Switch
                            edge="end"
                            checked={settings.deployment?.autoDeployEnabled || false}
                            onChange={(e) => handleSettingChange('deployment', 'autoDeployEnabled', e.target.checked)}
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Require Approval" 
                          secondary="Require admin approval for production deployments"
                        />
                        <ListItemSecondaryAction>
                          <Switch
                            edge="end"
                            checked={settings.deployment?.requireApproval || false}
                            onChange={(e) => handleSettingChange('deployment', 'requireApproval', e.target.checked)}
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Notify on Deployment" 
                          secondary="Send email notifications for deployments"
                        />
                        <ListItemSecondaryAction>
                          <Switch
                            edge="end"
                            checked={settings.deployment?.notifyOnDeployment || false}
                            onChange={(e) => handleSettingChange('deployment', 'notifyOnDeployment', e.target.checked)}
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                    </List>
                  </CardContent>
                </Card>
              </Grid>
              
              {/* Security Settings */}
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Security Settings" />
                  <CardContent>
                    <List>
                      <ListItem>
                        <ListItemText 
                          primary="Session Timeout (minutes)" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              type="number"
                              value={settings.security?.sessionTimeout || 60}
                              onChange={(e) => handleSettingChange('security', 'sessionTimeout', parseInt(e.target.value))}
                            />
                          }
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Max Login Attempts" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              type="number"
                              value={settings.security?.maxLoginAttempts || 5}
                              onChange={(e) => handleSettingChange('security', 'maxLoginAttempts', parseInt(e.target.value))}
                            />
                          }
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Two-Factor Authentication" 
                          secondary="Require 2FA for all users"
                        />
                        <ListItemSecondaryAction>
                          <Switch
                            edge="end"
                            checked={settings.security?.twoFactorAuth || false}
                            onChange={(e) => handleSettingChange('security', 'twoFactorAuth', e.target.checked)}
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Password Expiration (days)" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              type="number"
                              value={settings.security?.passwordExpiration || 90}
                              onChange={(e) => handleSettingChange('security', 'passwordExpiration', parseInt(e.target.value))}
                            />
                          }
                        />
                      </ListItem>
                    </List>
                  </CardContent>
                </Card>
              </Grid>
              
              {/* Integration Settings */}
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader title="Integration Settings" />
                  <CardContent>
                    <List>
                      <ListItem>
                        <ListItemText 
                          primary="GitHub Integration" 
                          secondary="Enable GitHub repository integration"
                        />
                        <ListItemSecondaryAction>
                          <Switch
                            edge="end"
                            checked={settings.integrations?.githubEnabled || false}
                            onChange={(e) => handleSettingChange('integrations', 'githubEnabled', e.target.checked)}
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="GitHub Organization" 
                          secondary={
                            <TextField
                              fullWidth
                              margin="dense"
                              size="small"
                              disabled={!settings.integrations?.githubEnabled}
                              value={settings.integrations?.githubOrg || ''}
                              onChange={(e) => handleSettingChange('integrations', 'githubOrg', e.target.value)}
                            />
                          }
                        />
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Cursor AI Integration" 
                          secondary="Enable Cursor AI for app building"
                        />
                        <ListItemSecondaryAction>
                          <Switch
                            edge="end"
                            checked={settings.integrations?.cursorAiEnabled || false}
                            onChange={(e) => handleSettingChange('integrations', 'cursorAiEnabled', e.target.checked)}
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                      <ListItem>
                        <ListItemText 
                          primary="Analytics Integration" 
                          secondary="Enable analytics for app usage tracking"
                        />
                        <ListItemSecondaryAction>
                          <Switch
                            edge="end"
                            checked={settings.integrations?.analyticsEnabled || false}
                            onChange={(e) => handleSettingChange('integrations', 'analyticsEnabled', e.target.checked)}
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                    </List>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Box>
        );
      
      default:
        return null;
    }
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Admin Dashboard
        </Typography>
        
        <Paper sx={{ mt: 3 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant="fullWidth"
          >
            <Tab icon={<Person />} label="Users" />
            <Tab icon={<CloudDownload />} label="Deployments" />
            <Tab icon={<Info />} label="Logs" />
            <Tab icon={<Settings />} label="Settings" />
          </Tabs>
          
          {isLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <Typography>Loading...</Typography>
            </Box>
          ) : (
            renderTabContent()
          )}
        </Paper>
      </Box>
      
      {/* User Dialog */}
      <Dialog open={userDialogOpen} onClose={handleCloseUserDialog} maxWidth="sm" fullWidth>
        <DialogTitle>{selectedUser?.id ? 'Edit User' : 'Add User'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Name"
                name="name"
                value={selectedUser?.name || ''}
                onChange={handleUserInputChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Email"
                name="email"
                type="email"
                value={selectedUser?.email || ''}
                onChange={handleUserInputChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Role</InputLabel>
                <Select
                  name="role"
                  value={selectedUser?.role || 'developer'}
                  onChange={handleUserInputChange}
                  label="Role"
                >
                  <MenuItem value="admin">Admin</MenuItem>
                  <MenuItem value="developer">Developer</MenuItem>
                  <MenuItem value="viewer">Viewer</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select
                  name="status"
                  value={selectedUser?.status || 'active'}
                  onChange={handleUserInputChange}
                  label="Status"
                >
                  <MenuItem value="active">Active</MenuItem>
                  <MenuItem value="inactive">Inactive</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseUserDialog}>Cancel</Button>
          <Button onClick={handleSaveUser} variant="contained" color="primary">
            {selectedUser?.id ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Confirmation Dialog */}
      <Dialog open={confirmDialogOpen} onClose={handleCloseConfirmDialog}>
        <DialogTitle>
          {confirmAction.type === 'deleteUser' ? 'Delete User' : 
           confirmAction.type === 'rollbackDeployment' ? 'Rollback Deployment' :
           confirmAction.type === 'approveDeployment' ? 'Approve Deployment' : 'Confirm Action'}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            {confirmAction.type === 'deleteUser' ? 
              'Are you sure you want to delete this user? This action cannot be undone.' : 
             confirmAction.type === 'rollbackDeployment' ?
              'Are you sure you want to rollback this deployment? This will revert to the previous version.' :
             confirmAction.type === 'approveDeployment' ?
              'Are you sure you want to approve this deployment? This will deploy the application to production.' :
              'Are you sure you want to proceed with this action?'}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseConfirmDialog}>Cancel</Button>
          <Button 
            onClick={handleConfirmAction} 
            color={confirmAction.type === 'deleteUser' ? 'error' : 'primary'}
            variant="contained"
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default Admin;

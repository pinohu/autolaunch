const User = require('../models/user.model');
const Deployment = require('../models/deployment.model');
const App = require('../models/app.model');
const Log = require('../models/log.model');
const Setting = require('../models/setting.model');
const { exec } = require('child_process');
const path = require('path');

/**
 * User Management Controllers
 */

// Get all users
exports.getAllUsers = async (req, res, next) => {
  try {
    const users = await User.find().select('-password');
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};

// Create a new user
exports.createUser = async (req, res, next) => {
  try {
    const { name, email, password, role, status } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User with this email already exists' });
    }
    
    // Create new user
    const user = new User({
      name,
      email,
      password,
      role: role || 'developer',
      status: status || 'active'
    });
    
    await user.save();
    
    // Log user creation
    const log = new Log({
      level: 'info',
      message: `User ${name} (${email}) created by ${req.user.name}`,
      source: 'admin',
      user: req.user._id
    });
    await log.save();
    
    res.status(201).json({ message: 'User created successfully', user: { ...user.toObject(), password: undefined } });
  } catch (error) {
    next(error);
  }
};

// Get user by ID
exports.getUserById = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};

// Update user
exports.updateUser = async (req, res, next) => {
  try {
    const { name, email, role, status } = req.body;
    
    // Find user
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Update user fields
    user.name = name || user.name;
    user.email = email || user.email;
    user.role = role || user.role;
    user.status = status || user.status;
    
    await user.save();
    
    // Log user update
    const log = new Log({
      level: 'info',
      message: `User ${user.name} (${user.email}) updated by ${req.user.name}`,
      source: 'admin',
      user: req.user._id
    });
    await log.save();
    
    res.status(200).json({ message: 'User updated successfully', user: { ...user.toObject(), password: undefined } });
  } catch (error) {
    next(error);
  }
};

// Delete user
exports.deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Prevent deleting self
    if (user._id.toString() === req.user._id.toString()) {
      return res.status(400).json({ message: 'Cannot delete your own account' });
    }
    
    await User.findByIdAndDelete(req.params.id);
    
    // Log user deletion
    const log = new Log({
      level: 'warning',
      message: `User ${user.name} (${user.email}) deleted by ${req.user.name}`,
      source: 'admin',
      user: req.user._id
    });
    await log.save();
    
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (error) {
    next(error);
  }
};

/**
 * Deployment Management Controllers
 */

// Get all deployments
exports.getAllDeployments = async (req, res, next) => {
  try {
    const deployments = await Deployment.find()
      .populate('app', 'name slug')
      .populate('deployedBy', 'name email')
      .sort({ createdAt: -1 });
    
    res.status(200).json(deployments);
  } catch (error) {
    next(error);
  }
};

// Get deployment by ID
exports.getDeploymentById = async (req, res, next) => {
  try {
    const deployment = await Deployment.findById(req.params.id)
      .populate('app', 'name slug')
      .populate('deployedBy', 'name email');
    
    if (!deployment) {
      return res.status(404).json({ message: 'Deployment not found' });
    }
    
    res.status(200).json(deployment);
  } catch (error) {
    next(error);
  }
};

// Approve deployment
exports.approveDeployment = async (req, res, next) => {
  try {
    const deployment = await Deployment.findById(req.params.id)
      .populate('app', 'name slug')
      .populate('deployedBy', 'name email');
    
    if (!deployment) {
      return res.status(404).json({ message: 'Deployment not found' });
    }
    
    if (deployment.status !== 'pending') {
      return res.status(400).json({ message: 'Only pending deployments can be approved' });
    }
    
    // Update deployment status
    deployment.status = 'success';
    deployment.approvedBy = req.user._id;
    deployment.approvedAt = Date.now();
    await deployment.save();
    
    // Update app status
    const app = await App.findById(deployment.app);
    app.status = 'deployed';
    app.currentVersion = deployment.version;
    app.deployedAt = Date.now();
    await app.save();
    
    // Log deployment approval
    const log = new Log({
      level: 'info',
      message: `Deployment of ${app.name} v${deployment.version} approved by ${req.user.name}`,
      source: 'deployment',
      user: req.user._id,
      app: app._id,
      deployment: deployment._id
    });
    await log.save();
    
    res.status(200).json({ message: 'Deployment approved successfully', deployment });
  } catch (error) {
    next(error);
  }
};

// Rollback deployment
exports.rollbackDeployment = async (req, res, next) => {
  try {
    const deployment = await Deployment.findById(req.params.id)
      .populate('app', 'name slug')
      .populate('deployedBy', 'name email');
    
    if (!deployment) {
      return res.status(404).json({ message: 'Deployment not found' });
    }
    
    if (deployment.status !== 'success') {
      return res.status(400).json({ message: 'Only successful deployments can be rolled back' });
    }
    
    // Find previous successful deployment
    const previousDeployment = await Deployment.findOne({
      app: deployment.app,
      status: 'success',
      createdAt: { $lt: deployment.createdAt }
    }).sort({ createdAt: -1 });
    
    if (!previousDeployment) {
      return res.status(400).json({ message: 'No previous deployment found to rollback to' });
    }
    
    // Create rollback deployment
    const rollbackDeployment = new Deployment({
      app: deployment.app,
      version: previousDeployment.version,
      environment: deployment.environment,
      status: 'success',
      deployedBy: req.user._id,
      isRollback: true,
      rollbackFrom: deployment._id
    });
    
    await rollbackDeployment.save();
    
    // Update app status
    const app = await App.findById(deployment.app);
    app.currentVersion = previousDeployment.version;
    app.deployedAt = Date.now();
    await app.save();
    
    // Log rollback
    const log = new Log({
      level: 'warning',
      message: `Deployment of ${app.name} v${deployment.version} rolled back to v${previousDeployment.version} by ${req.user.name}`,
      source: 'deployment',
      user: req.user._id,
      app: app._id,
      deployment: rollbackDeployment._id
    });
    await log.save();
    
    res.status(200).json({ 
      message: 'Deployment rolled back successfully', 
      rollbackDeployment 
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Logs Controllers
 */

// Get all logs
exports.getLogs = async (req, res, next) => {
  try {
    const { level, source, startDate, endDate, limit = 100, page = 1 } = req.query;
    
    // Build query
    const query = {};
    if (level) query.level = level;
    if (source) query.source = source;
    
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }
    
    // Execute query with pagination
    const skip = (page - 1) * limit;
    const logs = await Log.find(query)
      .populate('user', 'name email')
      .populate('app', 'name slug')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));
    
    // Get total count for pagination
    const total = await Log.countDocuments(query);
    
    res.status(200).json({
      logs,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
};

// Clear logs
exports.clearLogs = async (req, res, next) => {
  try {
    const { olderThan, level, source } = req.body;
    
    // Build query
    const query = {};
    if (level) query.level = level;
    if (source) query.source = source;
    
    if (olderThan) {
      const date = new Date();
      date.setDate(date.getDate() - parseInt(olderThan));
      query.createdAt = { $lt: date };
    }
    
    // Delete logs
    const result = await Log.deleteMany(query);
    
    // Log the clearing action
    const log = new Log({
      level: 'warning',
      message: `${result.deletedCount} logs cleared by ${req.user.name}`,
      source: 'admin',
      user: req.user._id
    });
    await log.save();
    
    res.status(200).json({ 
      message: 'Logs cleared successfully', 
      deletedCount: result.deletedCount 
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Settings Controllers
 */

// Get all settings
exports.getSettings = async (req, res, next) => {
  try {
    // Get settings from database or use defaults
    let settings = await Setting.findOne();
    
    if (!settings) {
      // Create default settings if none exist
      settings = new Setting();
      await settings.save();
    }
    
    res.status(200).json(settings);
  } catch (error) {
    next(error);
  }
};

// Update settings
exports.updateSettings = async (req, res, next) => {
  try {
    const { general, deployment, security, integrations } = req.body;
    
    // Get settings or create if none exist
    let settings = await Setting.findOne();
    if (!settings) {
      settings = new Setting();
    }
    
    // Update settings
    if (general) settings.general = { ...settings.general, ...general };
    if (deployment) settings.deployment = { ...settings.deployment, ...deployment };
    if (security) settings.security = { ...settings.security, ...security };
    if (integrations) settings.integrations = { ...settings.integrations, ...integrations };
    
    await settings.save();
    
    // Log settings update
    const log = new Log({
      level: 'info',
      message: `System settings updated by ${req.user.name}`,
      source: 'admin',
      user: req.user._id
    });
    await log.save();
    
    res.status(200).json({ message: 'Settings updated successfully', settings });
  } catch (error) {
    next(error);
  }
};

/**
 * Analytics Controllers
 */

// Get user analytics
exports.getUserAnalytics = async (req, res, next) => {
  try {
    // Get total users count
    const totalUsers = await User.countDocuments();
    
    // Get users by role
    const usersByRole = await User.aggregate([
      { $group: { _id: '$role', count: { $sum: 1 } } }
    ]);
    
    // Get users by status
    const usersByStatus = await User.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    
    // Get new users in last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const newUsers = await User.countDocuments({
      createdAt: { $gte: thirtyDaysAgo }
    });
    
    // Get active users in last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const activeUsers = await User.countDocuments({
      lastLoginAt: { $gte: sevenDaysAgo }
    });
    
    res.status(200).json({
      totalUsers,
      usersByRole: usersByRole.map(item => ({ role: item._id, count: item.count })),
      usersByStatus: usersByStatus.map(item => ({ status: item._id, count: item.count })),
      newUsers,
      activeUsers
    });
  } catch (error) {
    next(error);
  }
};

// Get app analytics
exports.getAppAnalytics = async (req, res, next) => {
  try {
    // Get total apps count
    const totalApps = await App.countDocuments();
    
    // Get apps by type
    const appsByType = await App.aggregate([
      { $group: { _id: '$type', count: { $sum: 1 } } }
    ]);
    
    // Get apps by status
    const appsByStatus = await App.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    
    // Get new apps in last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const newApps = await App.countDocuments({
      createdAt: { $gte: thirtyDaysAgo }
    });
    
    // Get deployed apps in last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const recentlyDeployed = await App.countDocuments({
      deployedAt: { $gte: sevenDaysAgo }
    });
    
    res.status(200).json({
      totalApps,
      appsByType: appsByType.map(item => ({ type: item._id, count: item.count })),
      appsByStatus: appsByStatus.map(item => ({ status: item._id, count: item.count })),
      newApps,
      recentlyDeployed
    });
  } catch (error) {
    next(error);
  }
};

// Get deployment analytics
exports.getDeploymentAnalytics = async (req, res, next) => {
  try {
    // Get total deployments count
    const totalDeployments = await Deployment.countDocuments();
    
    // Get deployments by status
    const deploymentsByStatus = await Deployment.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    
    // Get deployments by environment
    const deploymentsByEnvironment = await Deployment.aggregate([
      { $group: { _id: '$environment', count: { $sum: 1 } } }
    ]);
    
    // Get deployments in last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const recentDeployments = await Deployment.countDocuments({
      createdAt: { $gte: thirtyDaysAgo }
    });
    
    // Get success rate
    const successfulDeployments = await Deployment.countDocuments({
      status: 'success'
    });
    
    const successRate = totalDeployments > 0 
      ? (successfulDeployments / totalDeployments) * 100 
      : 0;
    
    res.status(200).json({
      totalDeployments,
      deploymentsByStatus: deploymentsByStatus.map(item => ({ status: item._id, count: item.count })),
      deploymentsByEnvironment: deploymentsByEnvironment.map(item => ({ environment: item._id, count: item.count })),
      recentDeployments,
      successRate: Math.round(successRate * 100) / 100
    });
  } catch (error) {
    next(error);
  }
};

// Base Agent Class for AutoLaunch Studio
// This file provides the base functionality for all agents in the multi-agent architecture

const EventEmitter = require('events');

class BaseAgent extends EventEmitter {
  constructor(id, spec, orchestrator) {
    super();
    this.id = id;
    this.spec = spec;
    this.orchestrator = orchestrator;
    this.status = 'idle';
    this.lastRun = null;
    this.outputs = {};
  }

  // Validate inputs against required inputs in spec
  validateInputs(inputs) {
    const missingInputs = this.spec.inputs.filter(input => !inputs[input]);
    if (missingInputs.length > 0) {
      throw new Error(`Missing required inputs: ${missingInputs.join(', ')}`);
    }
    return true;
  }

  // Process inputs before execution
  processInputs(inputs) {
    // Default implementation just returns the inputs
    // Subclasses can override to provide custom processing
    return inputs;
  }

  // Execute the agent with given inputs
  async execute(inputs = {}) {
    this.status = 'running';
    this.lastRun = new Date();
    this.emit('start', { agentId: this.id, timestamp: this.lastRun });

    try {
      // Validate inputs
      this.validateInputs(inputs);

      // Process inputs
      const processedInputs = this.processInputs(inputs);

      // Execute agent-specific logic
      const outputs = await this.executeInternal(processedInputs);

      // Update outputs
      this.outputs = outputs;

      // Update status
      this.status = 'completed';
      this.emit('complete', { agentId: this.id, outputs, timestamp: new Date() });

      return outputs;
    } catch (error) {
      this.status = 'failed';
      this.emit('error', { agentId: this.id, error: error.message, timestamp: new Date() });
      console.error(`Error executing agent "${this.id}":`, error);
      return null;
    }
  }

  // Internal execution method to be implemented by subclasses
  async executeInternal(inputs) {
    throw new Error('executeInternal method must be implemented by subclasses');
  }

  // Get agent status
  getStatus() {
    return {
      id: this.id,
      name: this.spec.name,
      status: this.status,
      lastRun: this.lastRun,
      outputs: Object.keys(this.outputs)
    };
  }

  // Get agent outputs
  getOutputs() {
    return this.outputs;
  }

  // Reset agent state
  reset() {
    this.status = 'idle';
    this.outputs = {};
    this.emit('reset', { agentId: this.id, timestamp: new Date() });
  }
}

module.exports = BaseAgent;

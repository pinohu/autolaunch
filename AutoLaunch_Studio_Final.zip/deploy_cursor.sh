#!/bin/bash
# Cursor Deployment Script for AutoLaunch Studio
# This script deploys AutoLaunch Studio using Cursor AI

set -e

# Color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Log functions
log_info() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CURSOR_INTEGRATION_JS="${SCRIPT_DIR}/cursor_integration.js"
DEPLOY_REMOTE_SCRIPT="${SCRIPT_DIR}/deploy_remote.sh"

# Display banner
echo "
 █████╗ ██╗   ██╗████████╗ ██████╗ ██╗      █████╗ ██╗   ██╗███╗   ██╗ ██████╗██╗  ██╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██║     ██╔══██╗██║   ██║████╗  ██║██╔════╝██║  ██║
███████║██║   ██║   ██║   ██║   ██║██║     ███████║██║   ██║██╔██╗ ██║██║     ███████║
██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██║██║   ██║██║╚██╗██║██║     ██╔══██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║  ██║╚██████╔╝██║ ╚████║╚██████╗██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝
"
echo "Cursor Deployment Script for AutoLaunch Studio"
echo "--------------------------------------------"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
  log_error "Node.js is not installed. Please install Node.js first."
  exit 1
fi

# Check if cursor_integration.js exists
if [ ! -f "$CURSOR_INTEGRATION_JS" ]; then
  log_error "Cursor integration script not found: $CURSOR_INTEGRATION_JS"
  exit 1
fi

# Prompt for deployment options
echo "Deployment Options:"
echo "1. Local deployment"
echo "2. Remote deployment"
read -p "Enter your choice (1-2): " deployment_choice

case $deployment_choice in
  1)
    # Local deployment
    log_info "Starting local deployment..."
    node "$CURSOR_INTEGRATION_JS" --local
    ;;
    
  2)
    # Remote deployment
    log_info "Starting remote deployment..."
    
    # Check if deploy_remote.sh exists
    if [ ! -f "$DEPLOY_REMOTE_SCRIPT" ]; then
      log_error "Remote deployment script not found: $DEPLOY_REMOTE_SCRIPT"
      exit 1
    fi
    
    # Make sure the script is executable
    chmod +x "$DEPLOY_REMOTE_SCRIPT"
    
    # Run the remote deployment script
    "$DEPLOY_REMOTE_SCRIPT"
    ;;
    
  *)
    log_error "Invalid choice. Please enter 1 or 2."
    exit 1
    ;;
esac

log_info "Deployment completed successfully!"

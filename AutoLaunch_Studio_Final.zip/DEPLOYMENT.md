# AutoLaunch Studio - Cursor AI Deployment Guide

This document provides comprehensive instructions for deploying AutoLaunch Studio using Cursor AI. The files in this directory have been streamlined and consolidated for immediate deployment to production.

## System Overview

AutoLaunch Studio is a multi-agent architecture system for automated app development with the following components:

- **Core Agent System**: A modular multi-agent architecture that processes user prompts to generate applications
- **Orchestration System**: Manages agent workflows and communication
- **Template System**: Handles prompt templates and app generation templates
- **Feature Toggle System**: Controls feature availability and configuration
- **Deployment System**: Manages deployment to various environments including Cursor AI

## Prerequisites

- Node.js 14+ and npm
- Docker and Docker Compose
- Cursor AI access credentials
- Git (for version control)

## Directory Structure

```
cursor_deploy/
├── config/                  # Configuration files
│   ├── agent_spec.json      # Agent specification
│   ├── env.txt              # Environment variables
│   └── nginx.conf           # Nginx configuration
├── core/                    # Core system files
│   ├── AgentOrchestrationSystem.js
│   ├── ArchitectAgent.js
│   ├── BaseAgent.js
│   ├── FeatureToggleSystem.js
│   └── PromptTemplateSystem.js
├── cursor_integration.js    # Cursor AI integration
├── deploy_cursor.sh         # Main deployment script
├── deploy_remote.sh         # Remote deployment script
├── docker-compose.yml       # Docker Compose configuration
├── setup_backend.js         # Backend setup script
├── setup_environment.sh     # Environment setup script
├── setup_frontend.js        # Frontend setup script
├── DEPLOYMENT.md            # This deployment guide
└── README.md                # General readme
```

## Deployment Steps

### 1. Environment Setup

First, set up your environment by running:

```bash
./setup_environment.sh
```

This script will:
- Install required dependencies
- Configure environment variables
- Set up Docker containers
- Prepare the deployment environment

### 2. Cursor AI Deployment

To deploy to Cursor AI, use the deployment script:

```bash
./deploy_cursor.sh
```

When prompted, select one of the following options:
1. **Local deployment**: Deploy to your local Cursor AI environment
2. **Remote deployment**: Deploy to a remote Cursor AI instance

For remote deployment, you'll need to provide:
- Remote host information
- SSH credentials
- Cursor AI API keys

### 3. Verify Deployment

After deployment, verify that all components are running correctly:

```bash
curl http://localhost:3000/api/status
```

You should see a JSON response with status information for all agents.

## Configuration Options

### Agent Configuration

The agent system is configured through `config/agent_spec.json`. This file defines:

- Agent capabilities and dependencies
- Workflow sequences
- Orchestration settings
- Model parameters

### Environment Variables

Environment variables are stored in `config/env.txt`. Key variables include:

- `API_KEY`: Your Cursor AI API key
- `DEPLOYMENT_ENV`: Deployment environment (development, staging, production)
- `LOG_LEVEL`: Logging verbosity
- `PORT`: Application port

## Troubleshooting

### Common Issues

1. **Deployment script fails**:
   - Check Node.js version (must be 14+)
   - Verify Docker is running
   - Ensure all dependencies are installed

2. **Agent orchestration errors**:
   - Check agent_spec.json for configuration errors
   - Verify environment variables are set correctly
   - Check logs for specific agent errors

3. **Cursor AI integration issues**:
   - Verify API keys are valid
   - Check network connectivity to Cursor AI services
   - Ensure cursor_integration.js is properly configured

### Logs

Logs are available in the following locations:

- Application logs: `./logs/app.log`
- Deployment logs: `./logs/deploy.log`
- Docker logs: `docker-compose logs`

## Advanced Configuration

### Custom Agent Development

To develop custom agents:

1. Create a new agent class that extends BaseAgent
2. Implement the executeInternal method
3. Add the agent to agent_spec.json
4. Update workflows to include your new agent

### Scaling

For high-load environments:

1. Modify docker-compose.yml to add replicas
2. Configure load balancing in nginx.conf
3. Set up database clustering if needed

## Support

For additional support:
- Check the documentation in the docs directory
- Submit issues to the project repository
- Contact the AutoLaunch Studio team

---

This deployment guide is specifically tailored for Cursor AI deployment. For other deployment options, refer to the general documentation.

#!/bin/bash
# Remote Deployment Script for AutoLaunch Studio
# This script deploys AutoLaunch Studio to a remote server

set -e

# Color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Log functions
log_info() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

# Display banner
echo "
 █████╗ ██╗   ██╗████████╗ ██████╗ ██╗      █████╗ ██╗   ██╗███╗   ██╗ ██████╗██╗  ██╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██║     ██╔══██╗██║   ██║████╗  ██║██╔════╝██║  ██║
███████║██║   ██║   ██║   ██║   ██║██║     ███████║██║   ██║██╔██╗ ██║██║     ███████║
██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══██║██║   ██║██║╚██╗██║██║     ██╔══██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║  ██║╚██████╔╝██║ ╚████║╚██████╗██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝
"
echo "Remote Deployment Script for AutoLaunch Studio"
echo "--------------------------------------------"

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${SCRIPT_DIR}/.env"

# Load environment variables if .env file exists
if [ -f "$ENV_FILE" ]; then
  log_info "Loading environment variables from $ENV_FILE"
  source "$ENV_FILE"
fi

# Prompt for remote server details if not set in environment
if [ -z "$REMOTE_HOST" ]; then
  read -p "Enter remote server hostname or IP: " REMOTE_HOST
fi

if [ -z "$REMOTE_USER" ]; then
  read -p "Enter remote server username (default: ubuntu): " REMOTE_USER
  REMOTE_USER=${REMOTE_USER:-ubuntu}
fi

if [ -z "$REMOTE_KEY" ]; then
  read -p "Enter path to SSH private key: " REMOTE_KEY
fi

if [ -z "$REMOTE_HOST" ] || [ -z "$REMOTE_KEY" ]; then
  log_error "Remote host and SSH key are required."
  exit 1
fi

# Test SSH connection
log_info "Testing SSH connection to $REMOTE_HOST..."
if ! ssh -i "$REMOTE_KEY" -o ConnectTimeout=5 "$REMOTE_USER@$REMOTE_HOST" "echo SSH connection successful"; then
  log_error "Failed to connect to the remote server. Please check your SSH key and server details."
  exit 1
fi

# Create deployment directory
log_info "Creating deployment directory on remote server..."
ssh -i "$REMOTE_KEY" "$REMOTE_USER@$REMOTE_HOST" "mkdir -p ~/autolaunch_studio"

# Copy deployment files
log_info "Copying deployment files to remote server..."
scp -i "$REMOTE_KEY" -r "../../deployment" "$REMOTE_USER@$REMOTE_HOST:~/autolaunch_studio/"

# Copy scripts
log_info "Copying scripts to remote server..."
scp -i "$REMOTE_KEY" -r "../../scripts" "$REMOTE_USER@$REMOTE_HOST:~/autolaunch_studio/"

# Setup remote server
log_info "Setting up remote server..."
ssh -i "$REMOTE_KEY" "$REMOTE_USER@$REMOTE_HOST" "cd ~/autolaunch_studio && chmod +x scripts/setup/setup_environment.sh && ./scripts/setup/setup_environment.sh"

# Deploy AutoLaunch Studio
log_info "Deploying AutoLaunch Studio on remote server..."
ssh -i "$REMOTE_KEY" "$REMOTE_USER@$REMOTE_HOST" "cd ~/autolaunch_studio/deployment/docker && chmod +x deploy.sh && ./deploy.sh"

# Check deployment status
log_info "Checking deployment status..."
ssh -i "$REMOTE_KEY" "$REMOTE_USER@$REMOTE_HOST" "cd ~/autolaunch_studio/deployment/docker && chmod +x status.sh && ./status.sh"

log_info "Remote deployment completed successfully!"
echo "You can access AutoLaunch Studio at: http://$REMOTE_HOST:3000"
echo ""
echo "Useful commands:"
echo "- View status: ssh -i $REMOTE_KEY $REMOTE_USER@$REMOTE_HOST \"cd ~/autolaunch_studio/deployment/docker && ./status.sh\""
echo "- View logs: ssh -i $REMOTE_KEY $REMOTE_USER@$REMOTE_HOST \"cd ~/autolaunch_studio/deployment/docker && ./logs.sh\""
echo "- Stop application: ssh -i $REMOTE_KEY $REMOTE_USER@$REMOTE_HOST \"cd ~/autolaunch_studio/deployment/docker && ./stop.sh\""
echo "- Start application: ssh -i $REMOTE_KEY $REMOTE_USER@$REMOTE_HOST \"cd ~/autolaunch_studio/deployment/docker && ./deploy.sh\""
